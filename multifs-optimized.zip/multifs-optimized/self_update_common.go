package main

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"time"
)

func sha256Hex(data []byte) string {
	sum := sha256.Sum256(data)
	return hex.EncodeToString(sum[:])
}

func writeVerifiedUpdateFile(exePath string, data []byte, expectedSHA string) (string, string, error) {
	if len(data) == 0 {
		return "", "", fmt.Errorf("empty update payload")
	}
	expectedSHA = strings.ToLower(strings.TrimSpace(expectedSHA))
	actualSHA := sha256Hex(data)
	if expectedSHA != "" && actualSHA != expectedSHA {
		return "", actualSHA, fmt.Errorf("sha256 mismatch: expected %s, got %s", expectedSHA, actualSHA)
	}
	if exePath == "" {
		var err error
		exePath, err = os.Executable()
		if err != nil {
			return "", actualSHA, err
		}
	}
	if real, err := filepath.EvalSymlinks(exePath); err == nil && real != "" {
		exePath = real
	}
	dir := filepath.Dir(exePath)
	base := filepath.Base(exePath)
	stage := filepath.Join(dir, fmt.Sprintf(".%s.update.%d.new", base, time.Now().UnixNano()))
	if err := os.WriteFile(stage, data, 0o755); err != nil {
		return "", actualSHA, err
	}
	check, err := os.ReadFile(stage)
	if err != nil {
		_ = os.Remove(stage)
		return "", actualSHA, err
	}
	if sha256Hex(check) != actualSHA {
		_ = os.Remove(stage)
		return "", actualSHA, fmt.Errorf("staged file verification failed")
	}
	_ = os.Chmod(stage, 0o755)
	return stage, actualSHA, nil
}

func scheduleSelfReplaceAndRestart(currentExe, stagedExe string, args []string) error {
	if currentExe == "" {
		var err error
		currentExe, err = os.Executable()
		if err != nil {
			return err
		}
	}
	if real, err := filepath.EvalSymlinks(currentExe); err == nil && real != "" {
		currentExe = real
	}
	dir := filepath.Dir(currentExe)
	stamp := time.Now().UnixNano()
	if runtime.GOOS == "windows" {
		script := filepath.Join(dir, fmt.Sprintf(".%s.self-update.%d.cmd", filepath.Base(currentExe), stamp))
		content := buildWindowsUpdateScript(currentExe, stagedExe, args)
		if err := os.WriteFile(script, []byte(content), 0o700); err != nil {
			return err
		}
		cmd := exec.Command("cmd", "/C", "start", "", "/MIN", "cmd", "/C", script)
		return cmd.Start()
	}
	script := filepath.Join(dir, fmt.Sprintf(".%s.self-update.%d.sh", filepath.Base(currentExe), stamp))
	content := buildUnixUpdateScript(currentExe, stagedExe, args)
	if err := os.WriteFile(script, []byte(content), 0o700); err != nil {
		return err
	}
	cmd := exec.Command("sh", script)
	cmd.Stdout = nil
	cmd.Stderr = nil
	cmd.Stdin = nil
	return cmd.Start()
}

func buildWindowsUpdateScript(currentExe, stagedExe string, args []string) string {
	var b strings.Builder
	b.WriteString("@echo off\r\n")
	b.WriteString("setlocal\r\n")
	b.WriteString("ping 127.0.0.1 -n 2 >nul\r\n")
	b.WriteString("copy /Y ")
	b.WriteString(winQuote(stagedExe))
	b.WriteString(" ")
	b.WriteString(winQuote(currentExe))
	b.WriteString(" >nul\r\n")
	b.WriteString("if errorlevel 1 exit /b 1\r\n")
	b.WriteString("del /Q ")
	b.WriteString(winQuote(stagedExe))
	b.WriteString(" >nul 2>nul\r\n")
	b.WriteString("start \"\" ")
	b.WriteString(winQuote(currentExe))
	for _, arg := range args {
		b.WriteByte(' ')
		b.WriteString(winQuote(arg))
	}
	b.WriteString("\r\n")
	b.WriteString("del /Q \"%~f0\" >nul 2>nul\r\n")
	return b.String()
}

func buildUnixUpdateScript(currentExe, stagedExe string, args []string) string {
	var b strings.Builder
	b.WriteString("#!/bin/sh\n")
	b.WriteString("sleep 1\n")
	b.WriteString("mv -f ")
	b.WriteString(shQuote(stagedExe))
	b.WriteByte(' ')
	b.WriteString(shQuote(currentExe))
	b.WriteString(" || exit 1\n")
	b.WriteString("chmod +x ")
	b.WriteString(shQuote(currentExe))
	b.WriteString("\n")
	b.WriteString("exec ")
	b.WriteString(shQuote(currentExe))
	for _, arg := range args {
		b.WriteByte(' ')
		b.WriteString(shQuote(arg))
	}
	b.WriteString("\n")
	return b.String()
}

func winQuote(s string) string {
	s = strings.ReplaceAll(s, `"`, `\"`)
	return `"` + s + `"`
}

func shQuote(s string) string {
	return "'" + strings.ReplaceAll(s, "'", "'\\''") + "'"
}
