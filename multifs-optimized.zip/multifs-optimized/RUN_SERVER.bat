@echo off
setlocal
cd /d "%~dp0"
if exist "dist\server.exe" (
  set "SERVER=dist\server.exe"
) else (
  set "SERVER=server.exe"
)
echo Starting MultiFS server...
echo If 8080 is already used, the server automatically tries the next free port.
echo Login defaults are in RELIABLE_LAN_README.txt.
echo.
"%SERVER%" -listen 0.0.0.0:8080
pause
