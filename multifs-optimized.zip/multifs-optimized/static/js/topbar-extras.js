/*
 * topbar-extras.js — shared top-bar widgets injected into every page.
 *
 *   - Theme toggle (Dark / Auto / Light), persisted in localStorage.
 *   - Live server-latency pill that polls /api/server-info and shows the
 *     round-trip time in ms with a colored health dot.
 *
 * Pure client-side. No backend changes — /api/server-info already exists.
 */

(function () {
  'use strict';

  const THEME_KEY = 'multifs.theme.v1';
  const LATENCY_POLL_MS = 12000;
  let latencyTimer = null;

  document.addEventListener('DOMContentLoaded', init);

  function init() {
    applyStoredTheme();
    injectTopBarWidgets();
  }

  // ── Theme ────────────────────────────────────────────────────────────────────

  function applyStoredTheme() {
    const t = readTheme();
    setThemeOnDocument(t);
    // React to OS-level changes when the user is on Auto.
    if (window.matchMedia) {
      const mq = window.matchMedia('(prefers-color-scheme: light)');
      try {
        mq.addEventListener('change', () => { if (readTheme() === 'auto') setThemeOnDocument('auto'); });
      } catch (_) { /* older browsers */ }
    }
  }

  function readTheme() {
    try { return localStorage.getItem(THEME_KEY) || 'dark'; } catch (_) { return 'dark'; }
  }

  function writeTheme(t) {
    try { localStorage.setItem(THEME_KEY, t); } catch (_) {}
  }

  function setThemeOnDocument(t) {
    const html = document.documentElement;
    const resolved =
      t === 'light' ? 'light' :
      t === 'auto'  ? (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark') :
      'dark';
    html.dataset.theme = resolved;
    html.dataset.themePref = t;
  }

  function cycleTheme() {
    const order = ['dark', 'auto', 'light'];
    const cur = readTheme();
    const next = order[(order.indexOf(cur) + 1) % order.length];
    writeTheme(next);
    setThemeOnDocument(next);
    const labelEl = document.getElementById('themeToggleLabel');
    if (labelEl) labelEl.textContent = capitalize(next);
    showLocalNotification(`Theme: ${capitalize(next)}`, 'info');
  }

  // ── Top-bar widget injection ────────────────────────────────────────────────

  function injectTopBarWidgets() {
    const right = document.querySelector('.top-bar .top-bar-right');
    if (!right) return;

    // Latency pill (left of theme toggle).
    if (!document.getElementById('latencyPill')) {
      const pill = document.createElement('span');
      pill.id = 'latencyPill';
      pill.className = 'latency-pill latency-unknown';
      pill.title = 'Server health (polls /api/server-info)';
      pill.innerHTML = '<i class="fas fa-circle latency-dot"></i><span class="latency-text">—</span>';
      right.insertBefore(pill, right.firstChild);
    }

    // Theme toggle button.
    if (!document.getElementById('themeToggleBtn')) {
      const btn = document.createElement('button');
      btn.id = 'themeToggleBtn';
      btn.type = 'button';
      btn.className = 'btn btn-secondary btn-sm theme-toggle';
      btn.title = 'Cycle theme: Dark → Auto → Light';
      btn.innerHTML = `<i class="fas fa-circle-half-stroke"></i><span id="themeToggleLabel">${capitalize(readTheme())}</span>`;
      btn.addEventListener('click', cycleTheme);
      // Insert before the existing Logout link if any.
      const logout = right.querySelector('a[href="/logout"]');
      if (logout) right.insertBefore(btn, logout);
      else right.appendChild(btn);
    }

    // Begin polling latency.
    pollLatency();
    if (!latencyTimer) latencyTimer = setInterval(pollLatency, LATENCY_POLL_MS);
  }

  async function pollLatency() {
    const pill = document.getElementById('latencyPill');
    if (!pill) return;
    const dot = pill.querySelector('.latency-dot');
    const text = pill.querySelector('.latency-text');
    const t0 = performance.now();
    try {
      const r = await fetch('/api/server-info', { cache: 'no-store' });
      const elapsed = Math.round(performance.now() - t0);
      const ok = r.ok;
      let agents = 0;
      try { const j = await r.json(); agents = (j.agents_online ?? j.online_agents ?? 0); }
      catch (_) {}
      setLatencyState(pill, dot, text, ok ? classifyLatency(elapsed) : 'down', elapsed, agents, ok);
    } catch (_) {
      setLatencyState(pill, dot, text, 'down', null, 0, false);
    }
  }

  function classifyLatency(ms) {
    if (ms < 80) return 'great';
    if (ms < 200) return 'ok';
    if (ms < 600) return 'slow';
    return 'bad';
  }

  function setLatencyState(pill, dot, text, state, ms, agents, ok) {
    pill.classList.remove('latency-great', 'latency-ok', 'latency-slow', 'latency-bad', 'latency-down', 'latency-unknown');
    pill.classList.add('latency-' + state);
    if (!ok) {
      text.textContent = 'offline';
      pill.title = 'Server unreachable';
      return;
    }
    text.textContent = `${ms} ms`;
    pill.title = `Server ${ms}ms · ${agents} agent(s) online`;
  }

  // ── tiny utilities ───────────────────────────────────────────────────────────

  function capitalize(s) { return String(s).charAt(0).toUpperCase() + String(s).slice(1); }

  function showLocalNotification(message, type) {
    if (window.showNotification) return window.showNotification(message, type);
    // Minimal fallback toast (used on pages that don't define showNotification).
    const n = document.createElement('div');
    n.className = `notification notification-${type || 'info'}`;
    n.innerHTML = `<i class="fas fa-info-circle"></i><span>${message}</span>`;
    document.body.appendChild(n);
    requestAnimationFrame(() => n.classList.add('show'));
    setTimeout(() => { n.classList.remove('show'); setTimeout(() => n.remove(), 300); }, 2000);
  }

})();
