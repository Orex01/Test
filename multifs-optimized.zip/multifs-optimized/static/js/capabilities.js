// Shared capability-aware UI gating for MultiFS pages.
// Full Go agents advertise every control capability. Native Lite agents advertise only
// the small set they implement. Legacy full agents with no capability list are still
// treated as full-capable; legacy Lite agents are detected from their build/name/key.
(function () {
  const LITE_DEFAULT_CAPABILITIES = ['files_read', 'files_write', 'remote_update'];
  const LIVE_FEATURES = new Set([
    'files_read', 'files_write', 'archive', 'power', 'fun', 'messagebox', 'screen',
    'remote_input', 'processes', 'registry', 'shell', 'startup', 'logs', 'cmstp',
    'agent_control', 'remote_update'
  ]);

  function textOf(agent, field) {
    return String(agent && agent[field] ? agent[field] : '').toLowerCase();
  }

  function looksLikeLite(agent) {
    if (!agent) return false;
    return [textOf(agent, 'build'), textOf(agent, 'version'), textOf(agent, 'name'), textOf(agent, 'display_name'), textOf(agent, 'key')]
      .some(value => value.includes('lite'));
  }

  function normalizeCaps(agent) {
    if (!agent) return [];
    if (Array.isArray(agent.capabilities) && agent.capabilities.length > 0) {
      return agent.capabilities.map(c => String(c).trim()).filter(Boolean);
    }
    if (looksLikeLite(agent)) return LITE_DEFAULT_CAPABILITIES.slice();
    // null means: legacy full-capable agent. [] means: no selected/live agent.
    return null;
  }

  function capsOf(agent) {
    const caps = normalizeCaps(agent);
    if (caps === null) return null;
    return new Set(caps);
  }

  function supports(agent, feature) {
    feature = String(feature || '').trim();
    if (!feature) return true;
    if (!agent) return false;
    if (LIVE_FEATURES.has(feature) && agent.online === false) return false;

    const caps = capsOf(agent);
    if (caps === null) {
      // Backward compatibility for older full Go agents. Remote update still needs
      // an explicit capability because old agents cannot safely replace themselves.
      return feature !== 'remote_update';
    }
    if (caps.has(feature)) return true;
    if (caps.has('files') && (feature.startsWith('files_') || feature === 'archive')) return true;
    return false;
  }

  function supportsAny(agent, list) {
    if (!list || list.length === 0) return true;
    return list.some(feature => supports(agent, String(feature || '').trim()));
  }

  function reasonFor(el) {
    return el?.dataset?.disabledReason || el?.closest?.('[data-disabled-reason]')?.dataset?.disabledReason || 'This feature is not supported by the selected agent.';
  }

  function storeOriginalState(ctrl) {
    if (!ctrl.dataset.capOriginalStateSaved) {
      ctrl.dataset.capOriginalStateSaved = 'true';
      if ('disabled' in ctrl) ctrl.dataset.capOriginalDisabled = ctrl.disabled ? 'true' : 'false';
      if (ctrl.tagName === 'A') ctrl.dataset.enabledHref = ctrl.dataset.enabledHref || ctrl.getAttribute('href') || '';
      if (ctrl.hasAttribute('tabindex')) ctrl.dataset.capOriginalTabindex = ctrl.getAttribute('tabindex');
    }
  }

  function setControlDisabled(ctrl, disabled, reason) {
    storeOriginalState(ctrl);
    ctrl.classList.toggle('cap-disabled', !!disabled);
    ctrl.toggleAttribute('data-cap-disabled', !!disabled);
    ctrl.setAttribute('aria-disabled', disabled ? 'true' : 'false');
    if (reason && disabled) ctrl.setAttribute('title', reason);

    if ('disabled' in ctrl) {
      const originallyDisabled = ctrl.dataset.capOriginalDisabled === 'true';
      ctrl.disabled = !!disabled || originallyDisabled;
    }

    if (ctrl.tagName === 'A') {
      if (disabled) {
        ctrl.setAttribute('href', '#');
        ctrl.setAttribute('tabindex', '-1');
      } else {
        const enabledHref = ctrl.dataset.enabledHref;
        if (enabledHref) ctrl.setAttribute('href', enabledHref);
        if (ctrl.dataset.capOriginalTabindex !== undefined) ctrl.setAttribute('tabindex', ctrl.dataset.capOriginalTabindex);
        else ctrl.removeAttribute('tabindex');
      }
    }
  }

  function disableElement(el, disabled) {
    const reason = reasonFor(el);
    storeOriginalState(el);
    el.classList.toggle('cap-disabled', !!disabled);
    el.toggleAttribute('data-cap-disabled', !!disabled);
    el.setAttribute('aria-disabled', disabled ? 'true' : 'false');
    if (reason && disabled) el.setAttribute('title', reason);

    setControlDisabled(el, disabled, reason);
    el.querySelectorAll('button,input,select,textarea,a').forEach(ctrl => setControlDisabled(ctrl, disabled, reason));
  }

  function capabilityBlocker(ev) {
    const blocked = ev.target && ev.target.closest && ev.target.closest('[data-cap-disabled="true"]');
    if (!blocked) return;
    ev.preventDefault();
    ev.stopImmediatePropagation();
    const msg = reasonFor(blocked);
    if (typeof window.showNotification === 'function') window.showNotification(msg, 'warning');
  }

  async function currentAgent() {
    if (window.currentAgent) return window.currentAgent;
    try {
      const response = await fetch('/api/current-agent', { cache: 'no-store' });
      const data = await response.json();
      if (data.agent) window.currentAgent = data.agent;
      return data.agent || null;
    } catch (_) {
      return null;
    }
  }

  async function apply(agent) {
    const activeAgent = agent || await currentAgent();
    const caps = normalizeCaps(activeAgent);
    const lite = !!(activeAgent && looksLikeLite(activeAgent));

    document.querySelectorAll('[data-feature]').forEach(el => {
      const disabled = !supports(activeAgent, el.dataset.feature);
      disableElement(el, disabled);
    });

    document.querySelectorAll('[data-any-feature]').forEach(el => {
      const features = (el.dataset.anyFeature || '').split(',').map(s => s.trim()).filter(Boolean);
      const disabled = !supportsAny(activeAgent, features);
      disableElement(el, disabled);
    });

    document.body.classList.toggle('lite-agent-selected', lite);
    document.body.classList.toggle('no-agent-selected', !activeAgent);
    document.body.classList.toggle('offline-agent-selected', !!(activeAgent && activeAgent.online === false));
    document.body.dataset.agentCapabilities = caps === null ? 'legacy-full' : (caps || []).join(',');
    return activeAgent;
  }

  function ensureAllowed(feature, reason) {
    if (supports(window.currentAgent, feature)) return true;
    if (typeof window.showNotification === 'function') {
      window.showNotification(reason || `This action requires ${feature}.`, 'warning');
    }
    return false;
  }

  window.MultiFSCaps = { apply, supports, supportsAny, capsOf, normalizeCaps, looksLikeLite, ensureAllowed };
  document.addEventListener('click', capabilityBlocker, true);
  document.addEventListener('submit', capabilityBlocker, true);
  document.addEventListener('keydown', function (ev) {
    if ((ev.key === 'Enter' || ev.key === ' ') && ev.target?.closest?.('[data-cap-disabled="true"]')) capabilityBlocker(ev);
  }, true);
  document.addEventListener('DOMContentLoaded', () => apply());
})();
