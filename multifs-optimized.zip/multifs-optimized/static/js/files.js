// File Manager JavaScript — capability-aware, dynamically updated UI.
let currentAgent = null;
let agents = [];
let currentSort = { key: 'name', dir: 1 };

document.addEventListener('DOMContentLoaded', function () {
  bindFileManagerEvents();
  loadCurrentAgent();
  loadAgents();
  initializeUploadDropzone();
  // Bind checkbox events and prime the counter immediately.
  bindSelectionInputs();
  initializeFilePolishFeatures();
  updateSelectionSummary();
});

// Re-prime after bfcache restore.
window.addEventListener('pageshow', () => {
  bindSelectionInputs();
  initializeFilePolishFeatures();
  updateSelectionSummary();
});

// ── Agent loading ─────────────────────────────────────────────────────────────

async function loadCurrentAgent() {
  try {
    const response = await fetch('/api/current-agent', { cache: 'no-store' });
    const data = await response.json();
    if (data.agent) {
      currentAgent = data.agent;
      window.currentAgent = data.agent;
      updateAgentSelect(data.agent.key);
      applyFileCapabilities();
      if (window.MultiFSCaps) await window.MultiFSCaps.apply(data.agent);
    }
  } catch (error) {
    console.error('Error loading current agent:', error);
  } finally {
    updateSelectionSummary();
  }
}

async function loadAgents() {
  try {
    const response = await fetch('/api/agents', { cache: 'no-store' });
    const data = await response.json();
    agents = data.agents || [];
    populateAgentSelect();
  } catch (error) {
    console.error('Error loading agents:', error);
  }
}

function populateAgentSelect() {
  const select = document.getElementById('agentSelect');
  if (!select) return;
  select.innerHTML = '<option value="">Select a system...</option>';
  agents.forEach(agent => {
    const option = document.createElement('option');
    option.value = agent.key;
    option.textContent = `${agent.display_name || agent.name} (${agent.online ? 'Online' : 'Offline'})${agent.build ? ' · ' + agent.build : ''}`;
    option.selected = currentAgent && agent.key === currentAgent.key;
    select.appendChild(option);
  });
}

function updateAgentSelect(key) {
  const select = document.getElementById('agentSelect');
  if (select) select.value = key || '';
}

async function selectAgent(key) {
  if (!key) return;
  try {
    const response = await fetch('/api/select-agent', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key })
    });
    if (!response.ok) throw new Error(await response.text());
    const data = await response.json();
    currentAgent = agents.find(a => a.key === key) || null;
    window.currentAgent = currentAgent;
    applyFileCapabilities();
    if (window.MultiFSCaps) await window.MultiFSCaps.apply(currentAgent);
    showNotification('System selected: ' + (currentAgent?.display_name || currentAgent?.name || key), 'success');
    window.location.href = '/browse' + (data.homePath ? '?path=' + encodeURIComponent(data.homePath) : '');
  } catch (error) {
    console.error('Error selecting agent:', error);
    showNotification('Failed to select system: ' + error.message, 'error');
  }
}

function refreshPage() { window.location.reload(); }

// ── Event delegation ──────────────────────────────────────────────────────────

function bindFileManagerEvents() {
  // Checkbox changes — delegated so they survive DOM moves (sort reorder, etc.)
  document.addEventListener('change', event => {
    const t = event.target;
    if (!t) return;
    if (t.id === 'selectAll') { toggleSelectAll(); return; }
    if (t.classList?.contains('file-checkbox')) {
      t.closest('.file-row')?.classList.toggle('selected', !!t.checked);
      updateSelectionSummary();
    }
  });

  // Click delegation for sort headers, per-file actions, bulk selection actions.
  document.addEventListener('click', event => {
    const sortHead = event.target.closest('[data-sort-key]');
    if (sortHead) { sortFileTable(sortHead.dataset.sortKey); return; }

    const fileButton = event.target.closest('[data-file-action]');
    if (fileButton) {
      event.preventDefault();
      if (fileButton.disabled || fileButton.classList.contains('cap-disabled') ||
          fileButton.getAttribute('aria-disabled') === 'true') return;
      handleFileAction(fileButton);
      return;
    }

    const selBtn = event.target.closest('[data-selection-action]');
    if (selBtn) {
      event.preventDefault();
      if (selBtn.disabled || selBtn.classList.contains('cap-disabled') ||
          selBtn.getAttribute('aria-disabled') === 'true') return;
      handleSelectionAction(selBtn.dataset.selectionAction);
    }
  });
}

// Attach explicit change listeners to each checkbox (backup path for older
// browsers or custom components).  Uses a data attribute to avoid double-binding.
function bindSelectionInputs() {
  document.querySelectorAll('#fileTable .file-checkbox, #selectAll').forEach(input => {
    if (input.dataset.selectionBound === '1') return;
    input.dataset.selectionBound = '1';
    input.addEventListener('change', () => updateSelectionSummary());
  });
}

// ── Upload dropzone ───────────────────────────────────────────────────────────

function initializeUploadDropzone() {
  const dropzone = document.getElementById('uploadDropzone');
  const input = document.getElementById('uploadInput');
  if (!dropzone || !input) return;
  dropzone.addEventListener('click', () => input.click());
  ['dragenter', 'dragover'].forEach(evt => dropzone.addEventListener(evt, e => {
    e.preventDefault(); dropzone.classList.add('drag-over');
  }));
  ['dragleave', 'drop'].forEach(evt => dropzone.addEventListener(evt, e => {
    e.preventDefault(); dropzone.classList.remove('drag-over');
  }));
  dropzone.addEventListener('drop', e => {
    if (e.dataTransfer?.files.length) {
      input.files = e.dataTransfer.files;
      showNotification(`${e.dataTransfer.files.length} file(s) ready to upload`, 'info');
    }
  });
}

// ── Row / path helpers ────────────────────────────────────────────────────────

const fileRows = () => Array.from(document.querySelectorAll('#fileTable tbody tr.file-row'));
const selectedRows = () => fileRows().filter(r => !!r.querySelector('.file-checkbox')?.checked);
const selectedPaths = () =>
  selectedRows()
    .map(r => r.dataset.path || r.querySelector('.file-checkbox')?.dataset.path || '')
    .filter(Boolean);

function toggleSelectAll() {
  const selectAll = document.getElementById('selectAll');
  const checked = !!selectAll?.checked;
  fileRows().forEach(row => {
    const cb = row.querySelector('.file-checkbox');
    if (cb && !cb.disabled) { cb.checked = checked; row.classList.toggle('selected', checked); }
  });
  updateSelectionSummary();
}

// ── Selection counter (the authoritative function) ────────────────────────────
// Called any time checkboxes change, sort rerenders, or capabilities update.

function updateSelectionSummary() {
  const rows = fileRows();
  const count = rows.filter(r => !!r.querySelector('.file-checkbox')?.checked).length;

  // 1. Update pill text and state class.
  const summary = document.getElementById('selectionSummary');
  if (summary) {
    summary.textContent = count === 1 ? '1 selected' : `${count} selected`;
    summary.dataset.count = String(count);
    summary.classList.toggle('has-selection', count > 0);
  }

  // 1b. Show selected byte total for regular files. Directories are counted as 0
  // because their recursive size would require expensive remote scanning.
  const selectedBytes = rows.reduce((sum, r) => {
    if (!r.querySelector('.file-checkbox')?.checked) return sum;
    if (r.dataset.type === 'dir') return sum;
    return sum + (Number(r.dataset.size) || 0);
  }, 0);
  const sizeSummary = document.getElementById('selectedSizeSummary');
  if (sizeSummary) {
    sizeSummary.textContent = count > 0 ? humanBytesJS(selectedBytes) : '0 B';
    sizeSummary.classList.toggle('has-selection', count > 0);
  }

  // 2. Mirror .selected class on rows (ensures CSS highlight is always in sync).
  rows.forEach(r => r.classList.toggle('selected', !!r.querySelector('.file-checkbox')?.checked));

  // 3. Keep the "select all" header checkbox in the right tri-state.
  const selectAll = document.getElementById('selectAll');
  if (selectAll) {
    const selectable = rows.filter(r => !r.querySelector('.file-checkbox')?.disabled);
    const checked = selectable.filter(r => r.querySelector('.file-checkbox')?.checked);
    selectAll.checked = selectable.length > 0 && checked.length === selectable.length;
    selectAll.indeterminate = checked.length > 0 && checked.length < selectable.length;
  }

  // 4. Sync action-bar buttons.
  syncSelectionButton('zipSelectedBtn',    count > 0 && fileSupports('files_read'));
  syncSelectionButton('copySelectedBtn',   count > 0);
  syncSelectionButton('deleteSelectedBtn', count > 0 && fileSupports('files_write'));
}

function syncSelectionButton(id, shouldEnable) {
  const btn = document.getElementById(id);
  if (!btn) return;
  // Respect capability-level disabling set by capabilities.js / applyFileCapabilities.
  const capBlocked = btn.classList.contains('cap-disabled') ||
                     btn.getAttribute('aria-disabled') === 'true';
  btn.disabled = capBlocked || !shouldEnable;
}

// ── Per-file and bulk actions ─────────────────────────────────────────────────

function handleFileAction(button) {
  const action = button.dataset.fileAction;
  const path   = button.dataset.path || button.closest('.file-row')?.dataset.path || '';
  if (!path) return showNotification('Missing file path', 'error');
  switch (action) {
    case 'zip':    return zipOne(path);
    case 'copy':   return copyPath(path);
    case 'rename': return showRenameModal(button.dataset.name || remoteBaseJS(path), path);
    case 'delete': return deleteItem(path, button.dataset.isDir === 'true');
    default:       return;
  }
}

function handleSelectionAction(action) {
  switch (action) {
    case 'zip':    return bulkZipSelected();
    case 'copy':   return copySelectedPaths();
    case 'delete': return bulkDeleteSelected();
    default:       return;
  }
}

// ── Modal helpers ─────────────────────────────────────────────────────────────

function showUploadModal() { const m = document.getElementById('uploadModal'); if (m) m.style.display = 'flex'; }
function hideUploadModal() { const m = document.getElementById('uploadModal'); if (m) m.style.display = 'none'; }

function showRenameModal(name, path) {
  const oldPath = document.getElementById('renameOldPath');
  const newPath = document.getElementById('renameNewPath');
  if (oldPath) oldPath.value = path;
  if (newPath) newPath.value = path;
  const m = document.getElementById('renameModal');
  if (m) m.style.display = 'flex';
  setTimeout(() => newPath?.focus(), 50);
}
function hideRenameModal() { const m = document.getElementById('renameModal'); if (m) m.style.display = 'none'; }

// ── System-wide search ────────────────────────────────────────────────────────
// The search button itself is NOT capability-disabled so the modal always opens.
// The capability check happens inside runSystemSearch() so the user gets a clear
// message rather than a silently dead button.

function showSearchModal() {
  const m = document.getElementById('searchModal');
  if (m) m.style.display = 'flex';
  setTimeout(() => document.getElementById('systemSearchQuery')?.focus(), 50);
}
function hideSearchModal() { const m = document.getElementById('searchModal'); if (m) m.style.display = 'none'; }
function handleSearchKey(e) { if (e.key === 'Enter') runSystemSearch(); }

async function runSystemSearch() {
  const q = (document.getElementById('systemSearchQuery')?.value || '').trim();
  if (!q) return showNotification('Enter a filename, extension, or pattern first', 'warning');

  // Guard: agent must be selected and support file reads.
  if (!currentAgent) {
    return showNotification('Select a system first, then search.', 'warning');
  }
  if (!fileSupports('files_read')) {
    return showNotification('The selected agent does not support file search.', 'warning');
  }

  const scope   = document.getElementById('systemSearchScope')?.value || 'current';
  const root    = currentBrowsePath();
  const results = document.getElementById('searchResults');
  if (!results) return;

  results.innerHTML = '<div class="search-loading"><i class="fas fa-spinner fa-spin"></i> Searching…</div>';

  try {
    const params = new URLSearchParams({ q, scope, max: '500' });
    if (root) params.set('root', root);
    const response = await fetch('/api/files/search?' + params.toString(), { cache: 'no-store' });
    if (!response.ok) {
      const errText = await response.text();
      throw new Error(errText || `HTTP ${response.status}`);
    }
    const data = await response.json();
    renderSearchResults(data);
  } catch (error) {
    results.innerHTML = `<div class="error-banner">
      <i class="fas fa-exclamation-triangle"></i>
      <span>${escapeHtml(error.message)}</span>
    </div>`;
  }
}

function renderSearchResults(data) {
  const box = document.getElementById('searchResults');
  if (!box) return;
  const hits = data.results || [];
  if (!hits.length) {
    box.innerHTML = `<div class="empty-state">
      <i class="fas fa-search"></i>
      <p>No results — scanned ${data.scanned || 0} folder(s).</p>
    </div>`;
    return;
  }
  const warning = data.truncated
    ? '<div class="search-hint warning"><i class="fas fa-triangle-exclamation"></i> Results capped by safety limit — refine your query.</div>'
    : '';
  box.innerHTML = `${warning}<div class="search-summary">${hits.length} result(s) across ${data.scanned || 0} folder(s)</div>` +
    hits.map(hit => {
      const browse = hit.is_dir ? hit.path : parentPath(hit.path);
      const icon   = hit.is_dir ? 'fa-folder file-icon-folder' : 'fa-file';
      const size   = hit.is_dir ? '—' : humanBytesJS(hit.size || 0);
      return `<div class="search-result-item">
        <i class="fas ${icon} search-result-icon"></i>
        <div class="search-result-main">
          <div class="search-result-name">${escapeHtml(hit.name)}</div>
          <div class="search-result-path">${escapeHtml(hit.path)}</div>
        </div>
        <div class="search-result-size">${size}</div>
        <div class="btn-group search-result-actions">
          <a class="btn btn-sm btn-secondary btn-icon" href="/browse?path=${encodeURIComponent(browse)}"
             title="Open folder"><i class="fas fa-folder-open"></i></a>
          ${hit.is_dir ? '' : `<a class="btn btn-sm btn-secondary btn-icon"
             href="/download?path=${encodeURIComponent(hit.path)}" title="Download"><i class="fas fa-download"></i></a>`}
          <button type="button" class="btn btn-sm btn-secondary btn-icon"
            data-file-action="zip" data-path="${escapeAttr(hit.path)}" title="Download as ZIP">
            <i class="fas fa-file-archive"></i></button>
          <button type="button" class="btn btn-sm btn-secondary btn-icon"
            data-file-action="copy" data-path="${escapeAttr(hit.path)}" title="Copy path">
            <i class="fas fa-copy"></i></button>
        </div>
      </div>`;
    }).join('');
}

// ── File operations ───────────────────────────────────────────────────────────

function deleteItem(path, isDir) {
  if (!confirm(`Delete this ${isDir ? 'folder' : 'file'}?`)) return;
  const form = document.createElement('form');
  form.method = 'POST'; form.action = '/delete';
  const input = document.createElement('input');
  input.type = 'hidden'; input.name = 'path'; input.value = path;
  form.appendChild(input); document.body.appendChild(form); form.submit();
}

async function bulkDeleteSelected() {
  const paths = selectedPaths();
  if (!paths.length) return showNotification('Select files or folders first', 'warning');
  if (!confirm(`Delete ${paths.length} selected item(s)?`)) return;
  try {
    const r = await fetch('/bulk-delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ paths })
    });
    if (!r.ok) throw new Error(await r.text());
    const data = await r.json();
    showNotification(`Deleted ${data.success} of ${data.total} item(s)`, 'success');
    setTimeout(refreshPage, 500);
  } catch (e) {
    showNotification('Bulk delete failed: ' + e.message, 'error');
  }
}

async function bulkZipSelected() {
  const paths = selectedPaths();
  if (!paths.length) return showNotification('Select files or folders first', 'warning');
  await downloadZip(paths);
}

async function zipOne(path) {
  if (!path) return showNotification('Missing path', 'error');
  await downloadZip([path]);
}

async function downloadZip(paths) {
  const clean = (paths || []).filter(Boolean);
  if (!clean.length) return showNotification('Select files or folders first', 'warning');
  try {
    showNotification('Preparing ZIP…', 'info');
    const r = await fetch('/bulk-zip', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ paths: clean })
    });
    if (!r.ok) throw new Error((await r.text()) || r.statusText);
    const blob = await r.blob();
    if (!blob.size) throw new Error('Server returned an empty ZIP');
    const disposition = r.headers.get('Content-Disposition') || '';
    const filename = filenameFromDisposition(disposition) ||
      (clean.length === 1 ? `${remoteBaseJS(clean[0]) || 'selected'}.zip` : 'selected-files.zip');
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
    showNotification('ZIP download started', 'success');
  } catch (e) {
    showNotification('ZIP failed: ' + e.message, 'error');
  }
}

function filenameFromDisposition(d) {
  let m = d.match(/filename\*=UTF-8''([^;]+)/i);
  if (m) { try { return decodeURIComponent(m[1].replace(/"/g, '')); } catch (_) { return m[1]; } }
  m = d.match(/filename="?([^";]+)"?/i);
  return m ? m[1] : '';
}

async function copyPath(path) {
  if (!path) return showNotification('Missing path', 'error');
  await copyText(path, 'Path copied');
}

async function copySelectedPaths() {
  const paths = selectedPaths();
  if (!paths.length) return showNotification('Select files or folders first', 'warning');
  await copyText(paths.join('\n'), `${paths.length} path(s) copied`);
}

async function copyText(text, okMsg) {
  try {
    if (navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(text);
    else fallbackCopy(text);
    showNotification(okMsg || 'Copied', 'success');
  } catch (_) {
    try { fallbackCopy(text); showNotification(okMsg || 'Copied', 'success'); }
    catch (e) { showNotification('Copy failed: ' + e.message, 'error'); }
  }
}

function fallbackCopy(text) {
  const ta = document.createElement('textarea');
  ta.value = text; ta.setAttribute('readonly', '');
  ta.style.cssText = 'position:fixed;left:-9999px;top:0';
  document.body.appendChild(ta); ta.focus(); ta.select();
  const ok = document.execCommand('copy');
  ta.remove();
  if (!ok) throw new Error('Browser denied clipboard access');
}


// ── UI polish / navigation features ──────────────────────────────────────────

function initializeFilePolishFeatures() {
  restoreFileDensity();
  rememberCurrentPath();
  renderRecentPaths();
  const input = document.getElementById('pathJumpInput');
  if (input && input.dataset.bound !== '1') {
    input.dataset.bound = '1';
    input.addEventListener('keydown', e => { if (e.key === 'Enter') goToPathInput(); });
  }
  const recent = document.getElementById('recentPathSelect');
  if (recent && recent.dataset.bound !== '1') {
    recent.dataset.bound = '1';
    recent.addEventListener('change', () => {
      if (recent.value) window.location.href = '/browse?path=' + encodeURIComponent(recent.value);
    });
  }
}

function goToPathInput() {
  const input = document.getElementById('pathJumpInput');
  const path = (input?.value || '').trim();
  if (!path) return showNotification('Enter a path first', 'warning');
  window.location.href = '/browse?path=' + encodeURIComponent(path);
}

function copyCurrentPath() {
  const path = currentBrowsePath();
  if (!path) return showNotification('No current path to copy', 'warning');
  return copyText(path, 'Current folder path copied');
}

const RECENT_PATHS_KEY = 'multifs.recentPaths.v1';
const DENSITY_KEY = 'multifs.fileDensity.v1';

function recentPaths() {
  try { return JSON.parse(localStorage.getItem(RECENT_PATHS_KEY) || '[]').filter(Boolean); }
  catch (_) { return []; }
}

function rememberCurrentPath() {
  const path = currentBrowsePath();
  if (!path) return;
  const paths = [path, ...recentPaths().filter(p => p !== path)].slice(0, 10);
  try { localStorage.setItem(RECENT_PATHS_KEY, JSON.stringify(paths)); } catch (_) {}
}

function renderRecentPaths() {
  const select = document.getElementById('recentPathSelect');
  if (!select) return;
  const current = currentBrowsePath();
  const paths = recentPaths().filter(p => p !== current);
  select.innerHTML = '<option value="">Recent folders</option>' + paths.map(p =>
    `<option value="${escapeAttr(p)}">${escapeHtml(shortPathLabel(p))}</option>`
  ).join('');
  select.disabled = paths.length === 0;
}

function shortPathLabel(path) {
  path = String(path || '');
  if (path.length <= 58) return path;
  return path.slice(0, 18) + '…' + path.slice(-34);
}

function restoreFileDensity() {
  const compact = localStorage.getItem(DENSITY_KEY) === 'compact';
  document.body.classList.toggle('compact-files', compact);
}

function toggleFileDensity() {
  const compact = !document.body.classList.contains('compact-files');
  document.body.classList.toggle('compact-files', compact);
  try { localStorage.setItem(DENSITY_KEY, compact ? 'compact' : 'comfortable'); } catch (_) {}
  showNotification(compact ? 'Compact table enabled' : 'Comfortable table enabled', 'info');
}

// ── Sort ──────────────────────────────────────────────────────────────────────

function sortFileTable(key) {
  const tbody = document.querySelector('#fileTable tbody');
  if (!tbody || !key) return;
  if (currentSort.key === key) currentSort.dir *= -1;
  else currentSort = { key, dir: 1 };
  const rows = Array.from(tbody.querySelectorAll('.file-row'));
  rows.sort((a, b) => {
    if (key === 'name') {
      if (a.dataset.type !== b.dataset.type) return a.dataset.type === 'dir' ? -1 : 1;
      return a.dataset.name.localeCompare(b.dataset.name, undefined, { sensitivity: 'base', numeric: true }) * currentSort.dir;
    }
    return ((Number(a.dataset[key]) || 0) - (Number(b.dataset[key]) || 0)) * currentSort.dir;
  });
  rows.forEach(r => tbody.appendChild(r));
  updateSortIndicators(key);
  // Re-bind selection inputs after DOM reorder, then recount.
  bindSelectionInputs();
  updateSelectionSummary();
}

function updateSortIndicators(activeKey) {
  document.querySelectorAll('[data-sort-key] i').forEach(i => { i.className = 'fas fa-sort'; });
  const icon = document.querySelector(`[data-sort-key="${activeKey}"] i`);
  if (icon) icon.className = currentSort.dir > 0 ? 'fas fa-sort-up' : 'fas fa-sort-down';
}

// ── Path utilities ────────────────────────────────────────────────────────────

function currentBrowsePath() {
  return new URLSearchParams(window.location.search).get('path') ||
         document.querySelector('.file-manager')?.dataset.currentPath || '';
}

function parentPath(path) {
  const norm = String(path || '').replace(/\\/g, '/');
  const idx  = norm.lastIndexOf('/');
  if (idx <= 0) return path;
  const parent = norm.substring(0, idx);
  return /^[A-Za-z]:/.test(path) ? parent.replace(/\//g, '\\') : parent || '/';
}

function remoteBaseJS(path) {
  const parts = String(path || '').replace(/\\/g, '/').split('/').filter(Boolean);
  return parts.length ? parts[parts.length - 1] : 'selected';
}

function humanBytesJS(n) {
  const units = ['B','KB','MB','GB','TB'];
  let i = 0; n = Number(n) || 0;
  while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
  return `${n.toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}

function escapeHtml(text) {
  const d = document.createElement('div');
  d.textContent = text == null ? '' : String(text);
  return d.innerHTML;
}

function escapeAttr(text) {
  return escapeHtml(text).replace(/`/g, '&#96;');
}

// ── Notifications ─────────────────────────────────────────────────────────────

function showNotification(message, type = 'info') {
  const icons = { success: 'check-circle', error: 'exclamation-circle', warning: 'exclamation-triangle', info: 'info-circle' };
  const n = document.createElement('div');
  n.className = `notification notification-${type}`;
  n.innerHTML = `<i class="fas fa-${icons[type] || 'info-circle'}"></i><span>${escapeHtml(message)}</span>`;
  document.body.appendChild(n);
  requestAnimationFrame(() => n.classList.add('show'));
  setTimeout(() => { n.classList.remove('show'); setTimeout(() => n.remove(), 300); }, 3500);
}

// Close any open modal by clicking its backdrop.
window.onclick = e => { if (e.target.classList.contains('modal')) e.target.style.display = 'none'; };

// ── Capability helpers ────────────────────────────────────────────────────────

function fileCaps() {
  if (!currentAgent || !Array.isArray(currentAgent.capabilities) || !currentAgent.capabilities.length) return null;
  return new Set(currentAgent.capabilities);
}

function fileSupports(feature) {
  const caps = fileCaps();
  if (!caps) return feature !== 'remote_update';
  if (caps.has(feature)) return true;
  if (caps.has('files') && (feature.startsWith('files_') || feature === 'archive')) return true;
  return false;
}

function applyFileCapabilities() {
  document.querySelectorAll('[data-feature]').forEach(el => {
    const feature = el.dataset.feature;
    const enabled = fileSupports(feature);
    // Do NOT set disabled on the search-modal opener — it should always be
    // clickable so the modal can open and show a meaningful message.
    if ('disabled' in el && !el.id?.includes('SelectedBtn') && !el.id?.includes('searchBtn')) {
      // Skip elements that handle their own capability check internally.
      if (!el.classList.contains('search-trigger')) {
        el.disabled = !enabled;
      }
    }
    el.classList.toggle('cap-disabled', !enabled);
    el.setAttribute('aria-disabled', enabled ? 'false' : 'true');
  });
  updateSelectionSummary();
}
