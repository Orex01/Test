/*
 * file-power-features.js — power-user features for the file manager.
 *
 * Layered on top of files.js so it can be loaded after the page has rendered.
 * Everything here is purely client-side; the server endpoints (/bulk-zip,
 * /bulk-delete, /download, /rename) are already in place.
 *
 * Features implemented:
 *   1. Keyboard shortcuts (arrows + j/k, Space, Enter, Backspace, Delete,
 *                          Ctrl+A, Ctrl+L, Ctrl+D, F2, F5, Z, C, /, ?, Esc)
 *   2. Shift+click range selection on file checkboxes
 *   3. Right-click context menu per file row
 *   4. Bulk delete confirmation modal (replaces native confirm)
 *   5. Auto-refresh toggle (off / 10s / 30s / 60s, persisted)
 *   6. File properties popover (anchored to the row, anywhere on the page)
 *   7. Keyboard-help modal
 */

(function () {
  'use strict';

  const AUTO_REFRESH_KEY = 'multifs.autoRefresh.v1';
  let autoRefreshTimer = null;
  let focusedRowIndex = -1;
  let lastShiftAnchor = null; // last checkbox toggled, used as shift+click anchor

  document.addEventListener('DOMContentLoaded', initPowerFeatures);
  window.addEventListener('pageshow', initPowerFeatures);

  function initPowerFeatures() {
    initKeyboard();
    initShiftClick();
    initContextMenu();
    initAutoRefresh();
    initBulkDeleteModal();
    initPropertiesPopover();
  }

  // ── Keyboard shortcuts ───────────────────────────────────────────────────────

  function initKeyboard() {
    if (window.__multifs_kb_bound) return;
    window.__multifs_kb_bound = true;

    document.addEventListener('keydown', onKey);
  }

  function onKey(e) {
    // Never intercept keys when the user is typing into an input/textarea/select.
    const tag = (e.target && e.target.tagName || '').toLowerCase();
    const editing = tag === 'input' || tag === 'textarea' || tag === 'select' ||
                    (e.target && e.target.isContentEditable);

    // Ctrl+L always focuses the path jump input, even inside fields.
    if (e.ctrlKey && !e.shiftKey && !e.altKey && e.key.toLowerCase() === 'l') {
      const pj = document.getElementById('pathJumpInput');
      if (pj) { e.preventDefault(); pj.focus(); pj.select(); }
      return;
    }

    // Esc closes modals / clears selection / hides context menu.
    if (e.key === 'Escape') {
      if (closeAnyOpenModal()) return;
      if (hideContextMenu()) return;
      if (clearAllSelection()) return;
    }

    if (editing) return; // remaining shortcuts only when not typing

    const rows = fileRows();
    if (!rows.length && !['?', '/'].includes(e.key)) return;

    switch (e.key) {
      case 'ArrowDown': case 'j': moveFocus(+1, rows); e.preventDefault(); break;
      case 'ArrowUp':   case 'k': moveFocus(-1, rows); e.preventDefault(); break;
      case ' ': toggleFocusedSelection(rows); e.preventDefault(); break;
      case 'Enter': openFocused(rows); e.preventDefault(); break;
      case 'Backspace': goToParent(); e.preventDefault(); break;
      case 'Delete':
        if (selectedRows().length) maybeBulkDelete();
        else deleteFocused(rows);
        e.preventDefault();
        break;
      case 'F2': renameFocused(rows); e.preventDefault(); break;
      case 'F5': location.reload(); e.preventDefault(); break;
      case '/': if (window.showSearchModal) { window.showSearchModal(); e.preventDefault(); } break;
      case '?': toggleKeyboardHelp(); e.preventDefault(); break;
      case 'z': case 'Z':
        if (selectedRows().length && window.bulkZipSelected) {
          window.bulkZipSelected(); e.preventDefault();
        }
        break;
      case 'c': case 'C':
        if (selectedRows().length && window.copySelectedPaths) {
          window.copySelectedPaths(); e.preventDefault();
        }
        break;
      case 'a': case 'A':
        if (e.ctrlKey || e.metaKey) {
          const sel = document.getElementById('selectAll');
          if (sel) { sel.checked = true; if (window.toggleSelectAll) window.toggleSelectAll(); e.preventDefault(); }
        }
        break;
      case 'd': case 'D':
        if (e.ctrlKey || e.metaKey) {
          downloadFocused(rows); e.preventDefault();
        }
        break;
    }
  }

  function moveFocus(delta, rows) {
    if (!rows.length) return;
    if (focusedRowIndex < 0) focusedRowIndex = delta > 0 ? 0 : rows.length - 1;
    else focusedRowIndex = Math.max(0, Math.min(rows.length - 1, focusedRowIndex + delta));
    setFocusedRow(rows[focusedRowIndex]);
  }

  function setFocusedRow(row) {
    document.querySelectorAll('#fileTable tbody tr.file-row.kb-focus').forEach(r => r.classList.remove('kb-focus'));
    if (!row) return;
    row.classList.add('kb-focus');
    row.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  }

  function focusedRow(rows) {
    if (focusedRowIndex >= 0 && focusedRowIndex < rows.length) return rows[focusedRowIndex];
    return rows[0] || null;
  }

  function toggleFocusedSelection(rows) {
    const row = focusedRow(rows);
    if (!row) return;
    const cb = row.querySelector('.file-checkbox');
    if (cb && !cb.disabled) {
      cb.checked = !cb.checked;
      cb.dispatchEvent(new Event('change', { bubbles: true }));
      lastShiftAnchor = cb;
    }
  }

  function openFocused(rows) {
    const row = focusedRow(rows);
    if (!row) return;
    const link = row.querySelector('.file-name');
    if (link) link.click();
  }

  function deleteFocused(rows) {
    const row = focusedRow(rows);
    if (!row) return;
    const btn = row.querySelector('[data-file-action="delete"]');
    if (btn) btn.click();
  }

  function renameFocused(rows) {
    const row = focusedRow(rows);
    if (!row) return;
    const btn = row.querySelector('[data-file-action="rename"]');
    if (btn) btn.click();
  }

  function downloadFocused(rows) {
    const row = focusedRow(rows);
    if (!row) return;
    const link = row.querySelector('a[href*="/download?path="]');
    if (link) link.click();
  }

  function goToParent() {
    const up = document.querySelector('.file-toolbar-left a[title="Parent Directory"]');
    if (up) up.click();
  }

  function clearAllSelection() {
    const checked = document.querySelectorAll('#fileTable .file-checkbox:checked');
    if (!checked.length) return false;
    checked.forEach(cb => {
      cb.checked = false;
      cb.dispatchEvent(new Event('change', { bubbles: true }));
    });
    return true;
  }

  function closeAnyOpenModal() {
    const m = document.querySelector('.modal[style*="display: flex"], .modal[style*="display:flex"]');
    if (m) { m.style.display = 'none'; return true; }
    return false;
  }

  function toggleKeyboardHelp() {
    const m = document.getElementById('keyboardHelpModal');
    if (!m) return;
    m.style.display = (m.style.display === 'flex') ? 'none' : 'flex';
  }
  window.showKeyboardHelp = function () {
    const m = document.getElementById('keyboardHelpModal');
    if (m) m.style.display = 'flex';
  };
  window.hideKeyboardHelp = function () {
    const m = document.getElementById('keyboardHelpModal');
    if (m) m.style.display = 'none';
  };

  // ── Shift+click range selection ──────────────────────────────────────────────

  function initShiftClick() {
    document.addEventListener('click', e => {
      const cb = e.target.closest('.file-checkbox');
      if (!cb) return;
      if (e.shiftKey && lastShiftAnchor && lastShiftAnchor !== cb) {
        const all = Array.from(document.querySelectorAll('#fileTable .file-checkbox'));
        const a = all.indexOf(lastShiftAnchor);
        const b = all.indexOf(cb);
        if (a >= 0 && b >= 0) {
          const [lo, hi] = a < b ? [a, b] : [b, a];
          const targetState = cb.checked; // post-click state
          for (let i = lo; i <= hi; i++) {
            const c = all[i];
            if (c && !c.disabled) {
              c.checked = targetState;
              c.dispatchEvent(new Event('change', { bubbles: true }));
            }
          }
        }
      }
      lastShiftAnchor = cb;
    });
  }

  // ── Right-click context menu ─────────────────────────────────────────────────

  function initContextMenu() {
    const menu = document.getElementById('fileContextMenu');
    if (!menu) return;

    document.addEventListener('contextmenu', e => {
      const row = e.target.closest('.file-row');
      if (!row) return;
      e.preventDefault();

      // Make sure the right-clicked row is selected/focused for visual feedback.
      const rows = fileRows();
      focusedRowIndex = rows.indexOf(row);
      setFocusedRow(row);

      menu.dataset.path = row.dataset.path || '';
      menu.dataset.name = row.dataset.name || '';
      menu.dataset.type = row.dataset.type || 'file';

      // Position with viewport clamping so it never overflows.
      const w = menu.offsetWidth || 220;
      const h = menu.offsetHeight || 280;
      const x = Math.min(e.clientX, window.innerWidth  - w - 8);
      const y = Math.min(e.clientY, window.innerHeight - h - 8);
      menu.style.left = x + 'px';
      menu.style.top  = y + 'px';
      menu.hidden = false;

      // Update enabled state based on file type.
      const isDir = menu.dataset.type === 'dir';
      menu.querySelector('[data-context-action="open"]')?.classList.toggle('hidden-item', false);
      const dl = menu.querySelector('[data-context-action="download"]');
      if (dl) dl.classList.toggle('hidden-item', isDir);
    });

    document.addEventListener('click', e => {
      if (!menu.contains(e.target)) hideContextMenu();
    });
    document.addEventListener('scroll', hideContextMenu, true);
    window.addEventListener('resize', hideContextMenu);

    menu.addEventListener('click', e => {
      const item = e.target.closest('[data-context-action]');
      if (!item) return;
      const action = item.dataset.contextAction;
      const path = menu.dataset.path;
      const name = menu.dataset.name;
      const isDir = menu.dataset.type === 'dir';
      hideContextMenu();
      runContextAction(action, path, name, isDir);
    });
  }

  function hideContextMenu() {
    const m = document.getElementById('fileContextMenu');
    if (m && !m.hidden) { m.hidden = true; return true; }
    return false;
  }

  function runContextAction(action, path, name, isDir) {
    switch (action) {
      case 'open':
        if (isDir) location.href = '/browse?path=' + encodeURIComponent(path);
        else       location.href = '/view?path=' + encodeURIComponent(path);
        break;
      case 'download':
        if (!isDir) location.href = '/download?path=' + encodeURIComponent(path);
        break;
      case 'zip':
        if (window.downloadZip) window.downloadZip([path]);
        break;
      case 'copy':
        if (window.copyPath) window.copyPath(path);
        break;
      case 'rename':
        if (window.showRenameModal) window.showRenameModal(name, path);
        break;
      case 'properties':
        showProperties(path, name, isDir);
        break;
      case 'delete':
        if (window.deleteItem) window.deleteItem(path, isDir);
        break;
    }
  }

  // ── Bulk delete modal (replaces native confirm) ──────────────────────────────

  function initBulkDeleteModal() {
    const btn = document.getElementById('bulkDeleteConfirm');
    if (!btn || btn.dataset.bound === '1') return;
    btn.dataset.bound = '1';
    btn.addEventListener('click', performBulkDelete);

    // Intercept the existing "Delete selected" toolbar button so it pops the
    // modal instead of using window.confirm().
    document.addEventListener('click', e => {
      const action = e.target.closest('[data-selection-action="delete"]');
      if (!action) return;
      if (action.disabled || action.classList.contains('cap-disabled')) return;
      e.preventDefault();
      e.stopImmediatePropagation();
      maybeBulkDelete();
    }, true); // capture phase so we intercept before files.js
  }

  function maybeBulkDelete() {
    const paths = selectedPaths();
    if (!paths.length) {
      if (window.showNotification) window.showNotification('Select files or folders first', 'warning');
      return;
    }
    const modal = document.getElementById('bulkDeleteModal');
    const list = document.getElementById('bulkDeleteList');
    const count = document.getElementById('bulkDeleteCount');
    const cCount = document.getElementById('bulkDeleteConfirmCount');
    if (!modal || !list || !count) return;

    count.textContent = String(paths.length);
    if (cCount) cCount.textContent = String(paths.length);
    list.innerHTML = paths.slice(0, 200).map(p => `<li>${escapeHtml(p)}</li>`).join('') +
      (paths.length > 200 ? `<li class="muted">…and ${paths.length - 200} more</li>` : '');

    modal.style.display = 'flex';
  }

  window.hideBulkDeleteModal = function () {
    const m = document.getElementById('bulkDeleteModal');
    if (m) m.style.display = 'none';
  };

  async function performBulkDelete() {
    const paths = selectedPaths();
    window.hideBulkDeleteModal();
    if (!paths.length) return;
    try {
      const r = await fetch('/bulk-delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ paths })
      });
      if (!r.ok) throw new Error(await r.text());
      const data = await r.json();
      if (window.showNotification) {
        window.showNotification(`Deleted ${data.success} of ${data.total} item(s)`, 'success');
      }
      setTimeout(() => location.reload(), 500);
    } catch (err) {
      if (window.showNotification) {
        window.showNotification('Bulk delete failed: ' + err.message, 'error');
      }
    }
  }

  // ── Auto-refresh ─────────────────────────────────────────────────────────────

  function initAutoRefresh() {
    const select = document.getElementById('autoRefreshSelect');
    if (!select) return;
    const saved = parseInt(localStorage.getItem(AUTO_REFRESH_KEY) || '0', 10);
    select.value = isNaN(saved) ? '0' : String(saved);
    applyAutoRefresh(parseInt(select.value, 10));
    if (select.dataset.bound === '1') return;
    select.dataset.bound = '1';
    select.addEventListener('change', () => {
      const sec = parseInt(select.value, 10) || 0;
      try { localStorage.setItem(AUTO_REFRESH_KEY, String(sec)); } catch (_) {}
      applyAutoRefresh(sec);
      if (window.showNotification) {
        window.showNotification(sec === 0 ? 'Auto-refresh disabled' : `Auto-refresh every ${sec}s`, 'info');
      }
    });
  }

  function applyAutoRefresh(sec) {
    if (autoRefreshTimer) { clearInterval(autoRefreshTimer); autoRefreshTimer = null; }
    if (sec > 0) {
      autoRefreshTimer = setInterval(() => {
        // Skip when a modal is open, a checkbox is selected (avoids losing
        // state mid-action), or the tab isn't visible.
        if (document.hidden) return;
        if (document.querySelector('.modal[style*="display: flex"], .modal[style*="display:flex"]')) return;
        if (document.querySelectorAll('#fileTable .file-checkbox:checked').length) return;
        location.reload();
      }, sec * 1000);
    }
  }

  // ── File properties popover ──────────────────────────────────────────────────

  let _propAnchorPath = '';

  function initPropertiesPopover() {
    document.addEventListener('click', e => {
      const pop = document.getElementById('filePropertiesPopover');
      if (!pop || pop.hidden) return;
      if (!pop.contains(e.target) && !e.target.closest('[data-context-action="properties"]')) {
        hideProperties();
      }
    });
  }

  function showProperties(path, name, isDir) {
    const pop = document.getElementById('filePropertiesPopover');
    if (!pop) return;
    const row = document.querySelector(`#fileTable .file-row[data-path="${cssEscape(path)}"]`);
    const size = row?.dataset.size;
    const date = row?.dataset.date;

    document.getElementById('propName').textContent = name || (path ? path.split(/[\\/]/).pop() : '');
    document.getElementById('propType').textContent = isDir ? 'Folder' : 'File';
    document.getElementById('propSize').textContent = isDir ? '—' : humanBytes(Number(size) || 0);
    document.getElementById('propDate').textContent = date ? new Date(Number(date) * 1000).toLocaleString() : '—';
    document.getElementById('propPath').textContent = path || '—';
    _propAnchorPath = path || '';

    // Center on viewport.
    pop.hidden = false;
    const w = pop.offsetWidth || 360;
    const h = pop.offsetHeight || 260;
    pop.style.left = Math.max(8, (window.innerWidth - w) / 2) + 'px';
    pop.style.top  = Math.max(8, (window.innerHeight - h) / 2) + 'px';
  }

  window.hideProperties = function () {
    const pop = document.getElementById('filePropertiesPopover');
    if (pop) pop.hidden = true;
  };

  window.copyPropertiesPath = function () {
    if (_propAnchorPath && window.copyPath) window.copyPath(_propAnchorPath);
  };

  // ── Helpers ──────────────────────────────────────────────────────────────────

  function fileRows() {
    return Array.from(document.querySelectorAll('#fileTable tbody tr.file-row'));
  }

  function selectedRows() {
    return fileRows().filter(r => !!r.querySelector('.file-checkbox')?.checked);
  }

  function selectedPaths() {
    return selectedRows()
      .map(r => r.dataset.path || r.querySelector('.file-checkbox')?.dataset.path || '')
      .filter(Boolean);
  }

  function humanBytes(n) {
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    let i = 0;
    n = Number(n) || 0;
    while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
    return `${n.toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
  }

  function escapeHtml(text) {
    const d = document.createElement('div');
    d.textContent = text == null ? '' : String(text);
    return d.innerHTML;
  }

  function cssEscape(s) {
    if (window.CSS && CSS.escape) return CSS.escape(s);
    return String(s).replace(/(["\\\]])/g, '\\$1');
  }

})();
