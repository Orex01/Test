// Remote Control JavaScript - stability/UX build
let currentAgent = null;
let agents = [];
let streamTimer = null;
let streamQuality = 50;
let targetFps = 5;
let isStreaming = false;
let captureInFlight = false;
let screenWidth = 0;
let screenHeight = 0;
let frameCount = 0;
let lastFpsTime = Date.now();
let keyboardCaptured = false;
let lastMouseMoveSent = 0;
let inputInFlight = 0;
const MAX_INPUT_IN_FLIGHT = 4;

function qs(id) { return document.getElementById(id); }

document.addEventListener('DOMContentLoaded', function() {
  loadCurrentAgent();
  loadAgents();
  setupEventListeners();
});

function setupEventListeners() {
  const screen = qs('remoteScreen');
  if (!screen) return;

  screen.tabIndex = 0;
  screen.addEventListener('mousedown', handleMouseDown);
  screen.addEventListener('mouseup', handleMouseUp);
  screen.addEventListener('mousemove', handleMouseMove);
  screen.addEventListener('wheel', handleMouseWheel, { passive: false });
  screen.addEventListener('contextmenu', e => e.preventDefault());

  document.addEventListener('keydown', handleKeyDown);
  document.addEventListener('keyup', handleKeyUp);

  screen.addEventListener('click', () => {
    keyboardCaptured = true;
    screen.focus();
    showNotification('Keyboard captured. Press ESC to release.', 'info');
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      keyboardCaptured = false;
      showNotification('Keyboard released', 'info');
    }
  });

  document.addEventListener('fullscreenchange', handleFullscreenChange);
  document.addEventListener('webkitfullscreenchange', handleFullscreenChange);
  document.addEventListener('mozfullscreenchange', handleFullscreenChange);
  document.addEventListener('MSFullscreenChange', handleFullscreenChange);
}

async function loadCurrentAgent() {
  try {
    const response = await fetch('/api/current-agent');
    const data = await response.json();
    if (data.agent) {
      currentAgent = data.agent;
      window.currentAgent = data.agent;
      updateAgentSelect(data.agent.key);
      const nameEl = qs('systemName');
      if (nameEl) nameEl.textContent = data.agent.display_name || data.agent.name;
      applyRemoteCapabilities();
      if (window.MultiFSCaps) window.MultiFSCaps.apply(data.agent);
      if (data.agent.online && remoteSupports('screen')) startStream(); else updateStatus(false, remoteSupports('screen') ? 'Selected system is offline' : 'Remote screen unsupported by this agent');
    } else {
      updateStatus(false, 'No system selected');
    }
  } catch (error) {
    console.error('Error loading current agent:', error);
    updateStatus(false, 'Could not load selected system');
  }
}

async function loadAgents() {
  try {
    const response = await fetch('/api/agents');
    const data = await response.json();
    agents = data.agents || [];
    populateAgentSelect();
  } catch (error) {
    console.error('Error loading agents:', error);
  }
}

function populateAgentSelect() {
  const select = qs('agentSelect');
  if (!select) return;
  select.innerHTML = '<option value="">Select a system...</option>';
  agents.forEach(agent => {
    const option = document.createElement('option');
    option.value = agent.key;
    option.textContent = `${agent.display_name || agent.name || agent.hostname || 'System'} (${agent.online ? 'Online' : 'Offline'})`;
    option.selected = currentAgent && agent.key === currentAgent.key;
    select.appendChild(option);
  });
}

function updateAgentSelect(key) {
  const select = qs('agentSelect');
  if (select) select.value = key || '';
}

async function selectAgent(key) {
  if (!key) return;
  stopStream();
  try {
    const response = await fetch('/api/select-agent', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key })
    });
    if (response.ok) {
      currentAgent = agents.find(a => a.key === key);
      window.currentAgent = currentAgent;
      applyRemoteCapabilities();
      if (window.MultiFSCaps) window.MultiFSCaps.apply(currentAgent);
      const name = currentAgent?.display_name || currentAgent?.name || currentAgent?.hostname || 'System';
      const nameEl = qs('systemName');
      if (nameEl) nameEl.textContent = name;
      showNotification('System selected: ' + name, 'success');
      if (currentAgent?.online && remoteSupports('screen')) startStream(); else updateStatus(false, remoteSupports('screen') ? 'Selected system is offline' : 'Remote screen unsupported by this agent');
    } else {
      updateStatus(false, 'Failed to select system');
      showNotification('Failed to select system', 'error');
    }
  } catch (error) {
    console.error('Error selecting agent:', error);
    updateStatus(false, 'Error selecting system');
    showNotification('Error selecting system', 'error');
  }
}

function updateQuality() {
  streamQuality = parseInt(qs('streamQuality')?.value || '50', 10);
}

function updateFrameRate() {
  targetFps = parseInt(qs('streamFps')?.value || '5', 10);
  if (!Number.isFinite(targetFps) || targetFps < 1) targetFps = 1;
  if (targetFps > 15) targetFps = 15;
  if (isStreaming) scheduleNextFrame(0);
}

function startStream() {
  if (!currentAgent) return;
  stopStream();
  updateQuality();
  updateFrameRate();
  isStreaming = true;
  frameCount = 0;
  lastFpsTime = Date.now();
  updateStatus(true, 'Connecting');
  scheduleNextFrame(0);
}

function stopStream() {
  isStreaming = false;
  captureInFlight = false;
  if (streamTimer) {
    clearTimeout(streamTimer);
    streamTimer = null;
  }
  updateStatus(false, 'Stopped');
}

function scheduleNextFrame(delayMs) {
  if (!isStreaming) return;
  if (streamTimer) clearTimeout(streamTimer);
  streamTimer = setTimeout(captureScreen, Math.max(0, delayMs));
}

async function captureScreen() {
  if (!currentAgent || !isStreaming) return;
  if (captureInFlight) {
    scheduleNextFrame(Math.ceil(1000 / targetFps));
    return;
  }
  captureInFlight = true;
  const startTime = Date.now();
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);

  try {
    const response = await fetch(`/api/screen/stream?quality=${encodeURIComponent(streamQuality)}`, { signal: controller.signal });
    if (!response.ok) {
      const msg = await response.text().catch(() => 'stream failed');
      updateStatus(false, msg || 'Stream failed');
      return;
    }
    const data = await response.json();
    if (data.frame) {
      const screen = qs('remoteScreen');
      screen.src = 'data:image/jpeg;base64,' + data.frame;
      if (data.width && data.height) {
        screenWidth = data.width;
        screenHeight = data.height;
        const resEl = qs('screenResolution');
        if (resEl) resEl.textContent = `${data.width}x${data.height}`;
      }
      frameCount++;
      const now = Date.now();
      if (now - lastFpsTime >= 1000) {
        const fpsEl = qs('fpsCounter');
        if (fpsEl) fpsEl.textContent = frameCount;
        frameCount = 0;
        lastFpsTime = now;
      }
      const latencyEl = qs('latencyCounter');
      if (latencyEl) latencyEl.textContent = (Date.now() - startTime) + 'ms';
      updateStatus(true, 'Connected');
    }
  } catch (error) {
    if (error.name === 'AbortError') updateStatus(false, 'Frame timed out');
    else updateStatus(false, 'Stream error');
    console.error('Stream error:', error);
  } finally {
    clearTimeout(timeout);
    captureInFlight = false;
    const elapsed = Date.now() - startTime;
    const targetDelay = Math.max(0, Math.ceil(1000 / targetFps) - elapsed);
    scheduleNextFrame(targetDelay);
  }
}

function updateStatus(connected, msg) {
  const indicator = qs('statusIndicator');
  const text = qs('statusText');
  if (!indicator || !text) return;
  if (connected) {
    indicator.classList.remove('disconnected');
    text.textContent = msg || 'Connected';
  } else {
    indicator.classList.add('disconnected');
    text.textContent = msg || 'Disconnected';
  }
}

function coordsFromEvent(e) {
  if (!screenWidth || !screenHeight) return null;
  const rect = e.target.getBoundingClientRect();
  if (!rect.width || !rect.height) return null;
  let x = Math.round((e.clientX - rect.left) * (screenWidth / rect.width));
  let y = Math.round((e.clientY - rect.top) * (screenHeight / rect.height));
  x = Math.max(0, Math.min(screenWidth - 1, x));
  y = Math.max(0, Math.min(screenHeight - 1, y));
  return { x, y, screenW: screenWidth, screenH: screenHeight };
}

function handleMouseDown(e) {
  if (!currentAgent) return;
  e.preventDefault();
  const c = coordsFromEvent(e);
  if (!c) return;
  sendRemoteInput('mousedown', { ...c, button: e.button });
}

function handleMouseUp(e) {
  if (!currentAgent) return;
  e.preventDefault();
  const c = coordsFromEvent(e);
  if (!c) return;
  sendRemoteInput('mouseup', { ...c, button: e.button });
}

function handleMouseMove(e) {
  if (!currentAgent) return;
  const now = Date.now();
  if (now - lastMouseMoveSent < 50) return; // 20 Hz cap for stability
  lastMouseMoveSent = now;
  const c = coordsFromEvent(e);
  if (!c) return;
  sendRemoteInput('mousemove', c);
}

function handleMouseWheel(e) {
  if (!currentAgent) return;
  e.preventDefault();
  const c = coordsFromEvent(e) || { screenW: screenWidth, screenH: screenHeight };
  const delta = e.deltaY > 0 ? -120 : 120;
  sendRemoteInput('wheel', { ...c, delta });
}

function handleKeyDown(e) {
  if (!keyboardCaptured || !currentAgent) return;
  if (e.key === 'Escape') return;
  if (e.key === 'F5' || e.key === 'F12' || (e.ctrlKey && e.key.toLowerCase() === 'r')) return;
  if (['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName)) return;
  e.preventDefault();
  sendRemoteInput('keydown', { keyCode: e.keyCode || e.which, key: e.key });
}

function handleKeyUp(e) {
  if (!keyboardCaptured || !currentAgent) return;
  if (e.key === 'Escape') return;
  if (e.key === 'F5' || e.key === 'F12' || (e.ctrlKey && e.key.toLowerCase() === 'r')) return;
  if (['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName)) return;
  e.preventDefault();
  sendRemoteInput('keyup', { keyCode: e.keyCode || e.which, key: e.key });
}

async function sendRemoteInput(type, data) {
  if (!currentAgent) return;
  if (inputInFlight >= MAX_INPUT_IN_FLIGHT) return;
  inputInFlight++;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 2500);
  try {
    await fetch('/api/remote/input', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type, ...data }),
      signal: controller.signal
    });
  } catch (_) {
    // Input is best-effort; do not spam the UI for transient dropped events.
  } finally {
    clearTimeout(timeout);
    inputInFlight--;
  }
}

function toggleFullscreen() {
  const container = qs('screenContainer');
  const remoteContainer = qs('remoteContainer');
  if (!container || !remoteContainer) return;
  if (!document.fullscreenElement && !document.webkitFullscreenElement && !document.mozFullScreenElement && !document.msFullscreenElement) {
    if (container.requestFullscreen) container.requestFullscreen();
    else if (container.webkitRequestFullscreen) container.webkitRequestFullscreen();
    else if (container.mozRequestFullScreen) container.mozRequestFullScreen();
    else if (container.msRequestFullscreen) container.msRequestFullscreen();
    container.classList.add('fullscreen');
    remoteContainer.classList.add('fullscreen');
  } else {
    if (document.exitFullscreen) document.exitFullscreen();
    else if (document.webkitExitFullscreen) document.webkitExitFullscreen();
    else if (document.mozCancelFullScreen) document.mozCancelFullScreen();
    else if (document.msExitFullscreen) document.msExitFullscreen();
    container.classList.remove('fullscreen');
    remoteContainer.classList.remove('fullscreen');
  }
}

function handleFullscreenChange() {
  const container = qs('screenContainer');
  const remoteContainer = qs('remoteContainer');
  if (!container || !remoteContainer) return;
  if (!document.fullscreenElement && !document.webkitFullscreenElement && !document.mozFullScreenElement && !document.msFullscreenElement) {
    container.classList.remove('fullscreen');
    remoteContainer.classList.remove('fullscreen');
  }
}

function showNotification(message, type = 'info') {
  const notification = document.createElement('div');
  notification.className = `notification notification-${type}`;
  notification.innerHTML = `<i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : type === 'warning' ? 'exclamation-triangle' : 'info-circle'}"></i><span>${message}</span>`;
  document.body.appendChild(notification);
  requestAnimationFrame(() => notification.classList.add('show'));
  setTimeout(() => {
    notification.classList.remove('show');
    setTimeout(() => notification.remove(), 300);
  }, 3000);
}

window.addEventListener('beforeunload', () => stopStream());


function remoteCaps() {
  if (!currentAgent || !Array.isArray(currentAgent.capabilities) || currentAgent.capabilities.length === 0) return null;
  return new Set(currentAgent.capabilities);
}
function remoteSupports(feature) {
  const caps = remoteCaps();
  if (!caps) return true;
  return caps.has(feature);
}
function applyRemoteCapabilities() {
  const screenOK = remoteSupports('screen');
  const inputOK = remoteSupports('remote_input');
  document.querySelectorAll('.screen-container, .remote-controls').forEach(el => el.classList.toggle('cap-disabled', !screenOK));
  if (!screenOK) stopStream();
  if (!inputOK) keyboardCaptured = false;
}
