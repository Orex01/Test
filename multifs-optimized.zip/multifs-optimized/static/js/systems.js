// Systems JavaScript
let agents = [];
let renameKey = null;
let selfUpdateKey = null;

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
  loadAgents();
});

// Load all agents
async function loadAgents() {
  try {
    const response = await fetch('/api/agents');
    const data = await response.json();
    agents = data.agents || [];
    renderSystems();
  } catch (error) {
    console.error('Error loading agents:', error);
    document.getElementById('systemsGrid').innerHTML = `
      <div class="empty-state">
        <i class="fas fa-exclamation-circle"></i>
        <p>Failed to load systems</p>
      </div>
    `;
  }
}

// Refresh systems
function refreshSystems() {
  document.getElementById('systemsGrid').innerHTML = `
    <div class="empty-state">
      <i class="fas fa-spinner fa-spin"></i>
      <p>Loading systems...</p>
    </div>
  `;
  loadAgents();
}

// Render systems grid
function renderSystems() {
  const grid = document.getElementById('systemsGrid');
  
  if (agents.length === 0) {
    grid.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-server"></i>
        <p>No systems connected yet</p>
        <p class="text-muted">Install the agent on a system to see it here</p>
      </div>
    `;
    return;
  }
  
  grid.innerHTML = agents.map(agent => {
    const lastSeen = agent.last_seen_utc ? new Date(agent.last_seen_utc * 1000).toLocaleString() : 'Never';
    const statusClass = agent.online ? 'online' : 'offline';
    const statusText = agent.online ? 'Online' : 'Offline';
    const canWrite = agentSupports(agent, 'files_write');
    const canRemoteUpdate = agentSupports(agent, 'remote_update');
    const versionLine = `${agent.version || 'unknown'}${agent.build ? ' · ' + agent.build : ''}`;
    
    return `
      <div class="system-card ${statusClass}">
        <div class="system-header">
          <div class="system-name">${escapeHtml(agent.display_name || agent.name)}</div>
          <div class="system-status ${statusClass}">
            <i class="fas fa-circle"></i>
            ${statusText}
          </div>
        </div>
        <div class="system-info">
          <div class="system-info-item">
            <i class="fas fa-desktop"></i> <span>${escapeHtml(agent.hostname || 'Unknown')}</span>
          </div>
          <div class="system-info-item">
            <i class="fab fa-windows"></i> <span>${escapeHtml(agent.os || 'Unknown')}</span>
          </div>
          <div class="system-info-item">
            <i class="fas fa-microchip"></i> <span>${escapeHtml(agent.arch || 'Unknown')}</span>
          </div>
          <div class="system-info-item">
            <i class="fas fa-user"></i> <span>${escapeHtml(agent.user || 'Unknown')}</span>
          </div>
          <div class="system-info-item">
            <i class="fas fa-code-branch"></i> <span>${escapeHtml(versionLine)}</span>
          </div>
        </div>
        <div class="system-actions">
          <button class="btn btn-sm btn-primary" onclick="selectSystem('${agent.key}')">
            <i class="fas fa-check-circle"></i> Select
          </button>
          <button class="btn btn-sm btn-secondary" onclick="showRenameModal('${agent.key}', '${escapeHtml(agent.display_name || agent.name)}')">
            <i class="fas fa-edit"></i> Rename
          </button>
          <button class="btn btn-sm btn-secondary" ${agent.online && canWrite ? '' : 'disabled'} onclick="showUpdateFileModal('${agent.key}')" title="Upload and verify a replacement file on this agent">
            <i class="fas fa-file-upload"></i> Update File
          </button>
          <button class="btn btn-sm btn-warning" ${agent.online && canRemoteUpdate ? '' : 'disabled'} onclick="showAgentSelfUpdateModal('${agent.key}')" title="Replace and restart the agent binary using SHA-256 verification">
            <i class="fas fa-rotate"></i> Self Update
          </button>
          <button class="btn btn-sm btn-danger" onclick="removeSystem('${agent.key}')">
            <i class="fas fa-trash"></i>
          </button>
        </div>
      </div>
    `;
  }).join('');
}


function agentSupports(agent, feature) {
  const caps = agent && Array.isArray(agent.capabilities) ? agent.capabilities : [];
  if (!caps.length) return feature !== 'remote_update';
  if (caps.includes(feature)) return true;
  if (caps.includes('files') && (feature.startsWith('files_') || feature === 'archive')) return true;
  return false;
}

// Select system
async function selectSystem(key) {
  try {
    const response = await fetch('/api/select-agent', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key: key })
    });
    
    if (response.ok) {
      const agent = agents.find(a => a.key === key);
      showNotification('System selected: ' + (agent?.display_name || agent?.name), 'success');
      // Highlight the selected card
      document.querySelectorAll('.system-card').forEach(card => {
        card.style.border = '1px solid var(--border-color)';
      });
      event.target.closest('.system-card').style.border = '2px solid var(--accent-primary)';
    } else {
      showNotification('Failed to select system', 'error');
    }
  } catch (error) {
    console.error('Error selecting system:', error);
    showNotification('Error selecting system', 'error');
  }
}

// Show rename modal
function showRenameModal(key, currentName) {
  renameKey = key;
  document.getElementById('renameName').value = currentName;
  document.getElementById('renameModal').style.display = 'flex';
}

// Hide rename modal
function hideRenameModal() {
  document.getElementById('renameModal').style.display = 'none';
  renameKey = null;
}

// Confirm rename
async function confirmRename() {
  if (!renameKey) return;
  
  const newName = document.getElementById('renameName').value.trim();
  if (!newName) {
    showNotification('Please enter a name', 'warning');
    return;
  }
  
  try {
    const response = await fetch('/api/rename-agent', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key: renameKey, name: newName })
    });
    
    if (response.ok) {
      showNotification('System renamed successfully', 'success');
      hideRenameModal();
      loadAgents();
    } else {
      showNotification('Failed to rename system', 'error');
    }
  } catch (error) {
    console.error('Error renaming system:', error);
    showNotification('Error renaming system', 'error');
  }
}

// Remove system. Surfaces a strong-warning modal that also makes the
// uninstall behavior explicit: deleting from this panel issues a silent
// uninstall on the target machine (removes the autostart entry, schedules
// the running EXE for deletion via a hidden cmd.exe — no visible CMD
// window, no "batch file cannot be found" popup), then removes the system
// from the server registry.
function removeSystem(key) {
  const agent = agents.find(a => a.key === key);
  const name = agent ? (agent.display_name || agent.name || key) : key;
  const online = !!(agent && agent.online);
  openDeleteSystemModal(key, name, online);
}

function openDeleteSystemModal(key, name, online) {
  const modal = document.getElementById('deleteSystemModal');
  const nameEl = document.getElementById('deleteSystemName');
  const noteEl = document.getElementById('deleteSystemNote');
  const confirmBtn = document.getElementById('deleteSystemConfirm');
  if (!modal || !confirmBtn) return;

  if (nameEl) nameEl.textContent = name;
  if (noteEl) {
    noteEl.textContent = online
      ? 'The agent is online. A silent uninstall will be dispatched first; the agent removes its autostart entry and schedules its EXE for deletion on the target machine before the system is unlinked here.'
      : 'The agent is offline. It will be unlinked from this server now. The next time it connects it will receive no further commands, but its files on the target machine will remain until you uninstall it manually.';
  }

  // Replace handler so repeated open/close doesn't stack listeners.
  const newBtn = confirmBtn.cloneNode(true);
  confirmBtn.parentNode.replaceChild(newBtn, confirmBtn);
  newBtn.addEventListener('click', () => confirmRemoveSystem(key, name));

  modal.style.display = 'flex';
}

function hideDeleteSystemModal() {
  const modal = document.getElementById('deleteSystemModal');
  if (modal) modal.style.display = 'none';
}

async function confirmRemoveSystem(key, name) {
  hideDeleteSystemModal();
  try {
    const response = await fetch('/api/remove-agent', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key: key, uninstall: true })
    });

    if (!response.ok) {
      showNotification('Failed to remove ' + name, 'error');
      return;
    }
    const data = await response.json().catch(() => ({}));
    if (data.uninstall_dispatched) {
      showNotification(`${name} removed and uninstall dispatched`, 'success');
    } else if (data.uninstall_requested) {
      showNotification(`${name} removed (agent was offline, uninstall not delivered)`, 'warning');
    } else {
      showNotification(`${name} removed`, 'success');
    }
    loadAgents();
  } catch (error) {
    console.error('Error removing system:', error);
    showNotification('Error removing system', 'error');
  }
}

// Escape HTML helper
function escapeHtml(text) {
  if (!text) return '';
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Notification helper
function showNotification(message, type = 'info') {
  const notification = document.createElement('div');
  notification.className = `notification notification-${type}`;
  notification.innerHTML = `
    <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : type === 'warning' ? 'exclamation-triangle' : 'info-circle'}"></i>
    <span>${message}</span>
  `;
  
  document.body.appendChild(notification);
  
  requestAnimationFrame(() => {
    notification.classList.add('show');
  });
  
  setTimeout(() => {
    notification.classList.remove('show');
    setTimeout(() => notification.remove(), 300);
  }, 3000);
}

// Close modals on outside click
window.onclick = function(event) {
  if (event.target.classList.contains('modal')) {
    event.target.style.display = 'none';
  }
};


let updateKey = null;
function showUpdateFileModal(key) {
  updateKey = key;
  const result = document.getElementById('updateFileResult');
  if (result) result.textContent = '';
  const modal = document.getElementById('updateFileModal');
  if (modal) modal.style.display = 'flex';
}
function hideUpdateFileModal() {
  updateKey = null;
  const modal = document.getElementById('updateFileModal');
  if (modal) modal.style.display = 'none';
}
async function submitAgentFileUpdate() {
  if (!updateKey) return;
  const target = (document.getElementById('updateTargetPath')?.value || '').trim();
  const input = document.getElementById('updateFileInput');
  const file = input?.files?.[0];
  const result = document.getElementById('updateFileResult');
  if (!target) return showNotification('Enter a target path on the agent', 'warning');
  if (!file) return showNotification('Choose a replacement file', 'warning');
  const fd = new FormData();
  fd.append('key', updateKey);
  fd.append('target', target);
  fd.append('file', file);
  if (result) result.textContent = 'Uploading and verifying...';
  try {
    const response = await fetch('/api/agent/update-file', { method: 'POST', body: fd });
    if (!response.ok) throw new Error(await response.text());
    const data = await response.json();
    if (result) result.textContent = `Verified ${data.bytes} bytes at ${data.target}; SHA-256 ${data.sha256}`;
    showNotification('Agent file updated and verified', 'success');
  } catch (error) {
    if (result) result.textContent = 'Update failed: ' + error.message;
    showNotification('Agent file update failed: ' + error.message, 'error');
  }
}


function showAgentSelfUpdateModal(key) {
  selfUpdateKey = key;
  const result = document.getElementById('agentSelfUpdateResult');
  if (result) result.textContent = '';
  const input = document.getElementById('agentSelfUpdateFile');
  if (input) input.value = '';
  const modal = document.getElementById('agentSelfUpdateModal');
  if (modal) modal.style.display = 'flex';
}
function hideAgentSelfUpdateModal() {
  selfUpdateKey = null;
  const modal = document.getElementById('agentSelfUpdateModal');
  if (modal) modal.style.display = 'none';
}
async function submitAgentSelfUpdate() {
  if (!selfUpdateKey) return;
  const input = document.getElementById('agentSelfUpdateFile');
  const file = input?.files?.[0];
  const version = (document.getElementById('agentSelfUpdateVersion')?.value || '').trim();
  const result = document.getElementById('agentSelfUpdateResult');
  if (!file) return showNotification('Choose a replacement agent executable', 'warning');
  if (!confirm('Update and restart this agent now?')) return;
  const fd = new FormData();
  fd.append('key', selfUpdateKey);
  fd.append('file', file);
  fd.append('version', version);
  if (result) result.textContent = 'Uploading, verifying, staging, and restarting agent...';
  try {
    const response = await fetch('/api/agent/self-update', { method: 'POST', body: fd });
    if (!response.ok) throw new Error(await response.text());
    const data = await response.json();
    if (result) result.textContent = `Agent update staged. ${data.bytes} bytes, SHA-256 ${data.sha256}. The system may disconnect briefly while it restarts.`;
    showNotification('Agent self-update started', 'success');
    setTimeout(loadAgents, 2500);
  } catch (error) {
    if (result) result.textContent = 'Agent self-update failed: ' + error.message;
    showNotification('Agent self-update failed: ' + error.message, 'error');
  }
}

function showServerSelfUpdateModal() {
  const result = document.getElementById('serverSelfUpdateResult');
  if (result) result.textContent = '';
  const input = document.getElementById('serverSelfUpdateFile');
  if (input) input.value = '';
  const modal = document.getElementById('serverSelfUpdateModal');
  if (modal) modal.style.display = 'flex';
}
function hideServerSelfUpdateModal() {
  const modal = document.getElementById('serverSelfUpdateModal');
  if (modal) modal.style.display = 'none';
}
async function submitServerSelfUpdate() {
  const input = document.getElementById('serverSelfUpdateFile');
  const file = input?.files?.[0];
  const version = (document.getElementById('serverSelfUpdateVersion')?.value || '').trim();
  const sha = (document.getElementById('serverSelfUpdateSha')?.value || '').trim();
  const result = document.getElementById('serverSelfUpdateResult');
  if (!file) return showNotification('Choose a replacement server binary', 'warning');
  if (!confirm('Update and restart the server now? Connected agents will reconnect after the server restarts.')) return;
  const fd = new FormData();
  fd.append('file', file);
  fd.append('version', version);
  fd.append('sha256', sha);
  if (result) result.textContent = 'Uploading, verifying, staging, and restarting server...';
  try {
    const response = await fetch('/api/server/self-update', { method: 'POST', body: fd });
    if (!response.ok) throw new Error(await response.text());
    const data = await response.json();
    if (result) result.textContent = `Server update staged. ${data.bytes} bytes, SHA-256 ${data.sha256}. Refresh this page after restart.`;
    showNotification('Server self-update staged; refresh after restart', 'success');
  } catch (error) {
    if (result) result.textContent = 'Server self-update failed: ' + error.message;
    showNotification('Server self-update failed: ' + error.message, 'error');
  }
}
