// Control Room JavaScript
let currentAgent = null;
let agents = [];
let processManagerExpanded = true;
let registryManagerExpanded = true;
let currentRegistryPath = 'HKLM';

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
  loadCurrentAgent();
  loadAgents();
  bindControlUpdateForms();
});

// Load current selected agent from session
async function loadCurrentAgent() {
  try {
    const response = await fetch('/api/current-agent');
    const data = await response.json();
    if (data.agent) {
      currentAgent = data.agent;
      window.currentAgent = data.agent;
      updateAgentSelect(data.agent.key);
      applyCapabilities();
      if (window.MultiFSCaps) window.MultiFSCaps.apply(data.agent);
      refreshCtrlUpdateAgentBadge(data.agent);
      refreshSetupControlAgentBadge(data.agent);
    } else {
      currentAgent = null;
      window.currentAgent = null;
      applyCapabilities();
      refreshCtrlUpdateAgentBadge(null);
      refreshSetupControlAgentBadge(null);
    }
  } catch (error) {
    console.error('Error loading current agent:', error);
  }
}

// Load all agents
async function loadAgents() {
  try {
    const response = await fetch('/api/agents');
    const data = await response.json();
    agents = data.agents || [];
    populateAgentSelect();
  } catch (error) {
    console.error('Error loading agents:', error);
  }
}

// Populate agent select dropdown
function populateAgentSelect() {
  const select = document.getElementById('agentSelect');
  select.innerHTML = '<option value="">Select a system...</option>';
  
  agents.forEach(agent => {
    const option = document.createElement('option');
    option.value = agent.key;
    option.textContent = `${agent.display_name || agent.name} (${agent.online ? 'Online' : 'Offline'})`;
    option.selected = currentAgent && agent.key === currentAgent.key;
    select.appendChild(option);
  });
}

// Update agent select value
function updateAgentSelect(key) {
  const select = document.getElementById('agentSelect');
  select.value = key || '';
}

// Select an agent
async function selectAgent(key) {
  if (!key) return;
  
  try {
    const response = await fetch('/api/select-agent', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key: key })
    });
    
    if (response.ok) {
      const data = await response.json();
      currentAgent = data.agent || agents.find(a => a.key === key) || null;
      window.currentAgent = currentAgent;
      applyCapabilities();
      if (window.MultiFSCaps) window.MultiFSCaps.apply(currentAgent);
      refreshCtrlUpdateAgentBadge(currentAgent);
      refreshSetupControlAgentBadge(currentAgent);
      showNotification('System selected: ' + (currentAgent?.display_name || currentAgent?.name), 'success');
    } else {
      showNotification('Failed to select system', 'error');
    }
  } catch (error) {
    console.error('Error selecting agent:', error);
    showNotification('Error selecting system', 'error');
  }
}

function requireFeature(feature, message) {
  if (!checkAgent()) return false;
  if (window.MultiFSCaps && !window.MultiFSCaps.supports(currentAgent, feature)) {
    showNotification(message || `The selected agent does not support ${feature}.`, 'warning');
    if (window.MultiFSCaps) window.MultiFSCaps.apply(currentAgent);
    return false;
  }
  return true;
}

// Power actions
async function powerAction(action) {
  if (!requireFeature('power', 'Power control is not supported by the selected Lite agent.')) return;
  
  if (!confirm(`Are you sure you want to ${action} the selected system?`)) return;
  
  try {
    const response = await fetch('/api/power', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: action })
    });
    
    if (response.ok) {
      showNotification(`Power action '${action}' sent successfully`, 'success');
    } else {
      const error = await response.text();
      showNotification('Failed: ' + error, 'error');
    }
  } catch (error) {
    console.error('Error:', error);
    showNotification('Error sending power action', 'error');
  }
}

// Fun menu actions
async function funAction(action) {
  if (!requireFeature('fun', 'Fun menu is not supported by the selected Lite agent.')) return;
  
  if (action === 'bluescreen' && !confirm('WARNING: This will trigger a bluescreen. Continue?')) return;
  
  try {
    const response = await fetch('/api/fun', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: action })
    });
    
    if (response.ok) {
      showNotification(`Fun action '${action}' sent successfully`, 'success');
    } else {
      const error = await response.text();
      showNotification('Failed: ' + error, 'error');
    }
  } catch (error) {
    console.error('Error:', error);
    showNotification('Error sending fun action', 'error');
  }
}

// Message box
async function sendMessageBox() {
  if (!requireFeature('messagebox', 'Message boxes are not supported by the selected Lite agent.')) return;
  
  const title = document.getElementById('msgTitle').value || 'Message';
  const message = document.getElementById('msgBody').value || 'Hello from MultiFS!';
  const type = document.getElementById('msgType').value;
  
  try {
    const response = await fetch('/api/messagebox', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, message, type })
    });
    
    if (response.ok) {
      showNotification('Message box sent successfully', 'success');
      document.getElementById('msgBody').value = '';
    } else {
      const error = await response.text();
      showNotification('Failed: ' + error, 'error');
    }
  } catch (error) {
    console.error('Error:', error);
    showNotification('Error sending message box', 'error');
  }
}

// Screen capture
async function refreshScreen() {
  if (!requireFeature('screen', 'Screen capture is not supported by the selected Lite agent.')) return;
  
  const preview = document.getElementById('screenPreview');
  const placeholder = document.getElementById('screenPlaceholder');
  
  try {
    const response = await fetch('/api/screen/capture');
    
    if (response.ok) {
      const data = await response.json();
      if (data.frame) {
        preview.src = 'data:image/jpeg;base64,' + data.frame;
        preview.style.display = 'block';
        placeholder.style.display = 'none';
      }
    } else {
      const error = await response.text();
      showNotification('Failed to capture screen: ' + error, 'error');
    }
  } catch (error) {
    console.error('Error:', error);
    showNotification('Error capturing screen', 'error');
  }
}

// Process Manager - Toggle expand/collapse
function toggleProcessManager() {
  const body = document.getElementById('processManagerBody');
  const icon = document.getElementById('processToggleIcon');
  
  processManagerExpanded = !processManagerExpanded;
  
  if (processManagerExpanded) {
    body.style.display = 'block';
    icon.classList.remove('fa-chevron-up');
    icon.classList.add('fa-chevron-down');
  } else {
    body.style.display = 'none';
    icon.classList.remove('fa-chevron-down');
    icon.classList.add('fa-chevron-up');
  }
}

// Refresh processes
async function refreshProcesses() {
  if (!requireFeature('processes', 'Process management is not supported by the selected Lite agent.')) return;
  
  const tbody = document.getElementById('processList');
  tbody.innerHTML = '<tr><td colspan="5" class="loading-state"><i class="fas fa-spinner fa-spin"></i> Loading...</td></tr>';
  
  try {
    const response = await fetch('/api/processes');
    
    if (response.ok) {
      const data = await response.json();
      renderProcesses(data.processes || []);
    } else {
      const error = await response.text();
      tbody.innerHTML = `<tr><td colspan="5" class="error-state">Error: ${error}</td></tr>`;
    }
  } catch (error) {
    console.error('Error:', error);
    tbody.innerHTML = '<tr><td colspan="5" class="error-state">Failed to load processes</td></tr>';
  }
}

// Render process list
function renderProcesses(processes) {
  const tbody = document.getElementById('processList');
  
  if (processes.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5" class="empty-state">No processes found</td></tr>';
    return;
  }
  
  tbody.innerHTML = processes.map(proc => `
    <tr>
      <td>${proc.pid}</td>
      <td>${escapeHtml(proc.name)}</td>
      <td>${escapeHtml(proc.username || 'N/A')}</td>
      <td>${proc.memory_mb ? proc.memory_mb.toFixed(2) + ' MB' : 'N/A'}</td>
      <td>
        <button class="btn btn-sm btn-danger" data-feature="processes" data-disabled-reason="Process management is not supported by the selected Lite agent." onclick="killProcess(${proc.pid})" title="Kill">
          <i class="fas fa-times"></i>
        </button>
      </td>
    </tr>
  `).join('');
  applyCapabilities();
}

// Kill process
async function killProcess(pid) {
  if (!requireFeature('processes', 'Process management is not supported by the selected Lite agent.')) return;
  if (!confirm(`Are you sure you want to kill process ${pid}?`)) return;
  
  try {
    const response = await fetch('/api/processes/kill', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pid: pid })
    });
    
    if (response.ok) {
      showNotification(`Process ${pid} killed successfully`, 'success');
      refreshProcesses();
    } else {
      const error = await response.text();
      showNotification('Failed: ' + error, 'error');
    }
  } catch (error) {
    console.error('Error:', error);
    showNotification('Error killing process', 'error');
  }
}

// Run process
async function runProcess() {
  if (!requireFeature('processes', 'Process management is not supported by the selected Lite agent.')) return;
  
  const command = document.getElementById('runCommand').value;
  const args = document.getElementById('runArgs').value;
  
  if (!command) {
    showNotification('Please enter a command', 'warning');
    return;
  }
  
  try {
    const response = await fetch('/api/processes/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ command, args })
    });
    
    if (response.ok) {
      showNotification('Process started successfully', 'success');
      document.getElementById('runCommand').value = '';
      document.getElementById('runArgs').value = '';
    } else {
      const error = await response.text();
      showNotification('Failed: ' + error, 'error');
    }
  } catch (error) {
    console.error('Error:', error);
    showNotification('Error starting process', 'error');
  }
}

// Registry Manager - Toggle expand/collapse
function toggleRegistryManager() {
  const body = document.getElementById('registryManagerBody');
  const icon = document.getElementById('registryToggleIcon');
  
  registryManagerExpanded = !registryManagerExpanded;
  
  if (registryManagerExpanded) {
    body.style.display = 'block';
    icon.classList.remove('fa-chevron-up');
    icon.classList.add('fa-chevron-down');
  } else {
    body.style.display = 'none';
    icon.classList.remove('fa-chevron-down');
    icon.classList.add('fa-chevron-up');
  }
}

// Refresh registry
async function refreshRegistry() {
  if (!requireFeature('registry', 'Registry management is not supported by the selected Lite agent.')) return;
  await navigateRegistry(currentRegistryPath);
}

// Navigate to registry path
async function navigateRegistry(path) {
  if (!requireFeature('registry', 'Registry management is not supported by the selected Lite agent.')) return;
  
  currentRegistryPath = path;
  document.getElementById('registryPath').value = path;
  
  const keysList = document.getElementById('registryKeysList');
  const valuesList = document.getElementById('registryValuesList');
  
  keysList.innerHTML = '<li class="loading-item"><i class="fas fa-spinner fa-spin"></i> Loading...</li>';
  valuesList.innerHTML = '<tr><td colspan="3" class="loading-state"><i class="fas fa-spinner fa-spin"></i> Loading...</td></tr>';
  
  try {
    const response = await fetch(`/api/registry?path=${encodeURIComponent(path)}`);
    
    if (response.ok) {
      const data = await response.json();
      renderRegistry(data);
    } else {
      const error = await response.text();
      keysList.innerHTML = `<li class="error-item">Error: ${error}</li>`;
      valuesList.innerHTML = `<tr><td colspan="3" class="error-state">Error: ${error}</td></tr>`;
    }
  } catch (error) {
    console.error('Error:', error);
    keysList.innerHTML = '<li class="error-item">Failed to load registry</li>';
    valuesList.innerHTML = '<tr><td colspan="3" class="error-state">Failed to load registry</td></tr>';
  }
}

// Navigate up in registry
function navigateRegistryUp() {
  if (currentRegistryPath === 'HKLM' || currentRegistryPath === 'HKCU' || 
      currentRegistryPath === 'HKCR' || currentRegistryPath === 'HKU' || 
      currentRegistryPath === 'HKCC') {
    return; // Can't go up from root
  }
  
  const parts = currentRegistryPath.split('\\');
  if (parts.length > 1) {
    parts.pop();
    navigateRegistry(parts.join('\\'));
  } else {
    // Go to root hive
    navigateRegistry(parts[0]);
  }
}

// Render registry data
function renderRegistry(data) {
  const keysList = document.getElementById('registryKeysList');
  const valuesList = document.getElementById('registryValuesList');
  
  // Render keys
  if (data.sub_keys && data.sub_keys.length > 0) {
    keysList.innerHTML = data.sub_keys.map(key => `
      <li onclick="navigateRegistry('${escapeHtml(data.path)}\\${escapeHtml(key)}')">
        <i class="fas fa-folder"></i> ${escapeHtml(key)}
      </li>
    `).join('');
  } else {
    keysList.innerHTML = '<li class="empty-item">No subkeys</li>';
  }
  
  // Render values
  if (data.values && data.values.length > 0) {
    valuesList.innerHTML = data.values.map(val => `
      <tr>
        <td>${escapeHtml(val.name || '(Default)')}</td>
        <td>${escapeHtml(val.type)}</td>
        <td class="registry-value" title="${escapeHtml(val.value)}">${escapeHtml(truncateString(val.value, 50))}</td>
      </tr>
    `).join('');
  } else {
    valuesList.innerHTML = '<tr><td colspan="3" class="empty-state">No values</td></tr>';
  }
}

// Shell
async function executeShell() {
  if (!requireFeature('shell', 'Shell execution is not supported by the selected Lite agent.')) return;
  
  const command = document.getElementById('shellCommand').value;
  if (!command) return;
  
  const output = document.getElementById('shellOutput');
  
  // Add command to output
  const cmdLine = document.createElement('div');
  cmdLine.className = 'shell-line shell-command';
  cmdLine.textContent = '$ ' + command;
  output.appendChild(cmdLine);
  
  document.getElementById('shellCommand').value = '';
  
  try {
    const response = await fetch('/api/shell', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ command })
    });
    
    if (response.ok) {
      const data = await response.json();
      
      if (data.output) {
        const outLines = data.output.split('\n');
        outLines.forEach(line => {
          if (line.trim()) {
            const outLine = document.createElement('div');
            outLine.className = 'shell-line shell-output';
            outLine.textContent = line;
            output.appendChild(outLine);
          }
        });
      }
      
      if (data.error) {
        const errLine = document.createElement('div');
        errLine.className = 'shell-line shell-error';
        errLine.textContent = 'Error: ' + data.error;
        output.appendChild(errLine);
      }
    } else {
      const errLine = document.createElement('div');
      errLine.className = 'shell-line shell-error';
      errLine.textContent = 'Error: Failed to execute command';
      output.appendChild(errLine);
    }
  } catch (error) {
    console.error('Error:', error);
    const errLine = document.createElement('div');
    errLine.className = 'shell-line shell-error';
    errLine.textContent = 'Error: ' + error.message;
    output.appendChild(errLine);
  }
  
  output.scrollTop = output.scrollHeight;
}

function handleShellKey(event) {
  if (event.key === 'Enter') {
    executeShell();
  }
}

// Startup Manager
async function refreshStartup() {
  if (!requireFeature('startup', 'Startup management is not supported by the selected Lite agent.')) return;
  
  const tbody = document.getElementById('startupList');
  tbody.innerHTML = '<tr><td colspan="4" class="loading-state"><i class="fas fa-spinner fa-spin"></i> Loading...</td></tr>';
  
  try {
    const response = await fetch('/api/startup');
    
    if (response.ok) {
      const data = await response.json();
      renderStartup(data.items || []);
    } else {
      const error = await response.text();
      tbody.innerHTML = `<tr><td colspan="4" class="error-state">Error: ${error}</td></tr>`;
    }
  } catch (error) {
    console.error('Error:', error);
    tbody.innerHTML = '<tr><td colspan="4" class="error-state">Failed to load startup items</td></tr>';
  }
}

function renderStartup(items) {
  const tbody = document.getElementById('startupList');
  
  if (items.length === 0) {
    tbody.innerHTML = '<tr><td colspan="4" class="empty-state">No startup items found</td></tr>';
    return;
  }
  
  tbody.innerHTML = items.map(item => `
    <tr>
      <td>${escapeHtml(item.name)}</td>
      <td class="startup-path" title="${escapeHtml(item.path)}">${escapeHtml(truncateString(item.path, 40))}</td>
      <td>${escapeHtml(item.location)}</td>
      <td>
        <button class="btn btn-sm btn-danger" data-feature="startup" data-disabled-reason="Startup management is not supported by the selected Lite agent." onclick="removeStartup('${escapeHtml(item.name)}')" title="Remove">
          <i class="fas fa-trash"></i>
        </button>
      </td>
    </tr>
  `).join('');
  applyCapabilities();
}

async function removeStartup(name) {
  if (!requireFeature('startup', 'Startup management is not supported by the selected Lite agent.')) return;
  if (!confirm(`Remove '${name}' from startup?`)) return;
  
  try {
    const response = await fetch('/api/startup/remove', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name })
    });
    
    if (response.ok) {
      showNotification('Startup item removed successfully', 'success');
      refreshStartup();
    } else {
      const error = await response.text();
      showNotification('Failed: ' + error, 'error');
    }
  } catch (error) {
    console.error('Error:', error);
    showNotification('Error removing startup item', 'error');
  }
}

// CMSTP
async function cmstpAction(action) {
  if (!requireFeature('cmstp', 'CMSTP actions are not supported by the selected Lite agent.')) return;
  
  try {
    const response = await fetch('/api/cmstp', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action })
    });
    
    if (response.ok) {
      showNotification(`CMSTP ${action} completed successfully`, 'success');
    } else {
      const error = await response.text();
      showNotification('Failed: ' + error, 'error');
    }
  } catch (error) {
    console.error('Error:', error);
    showNotification('Error with CMSTP action', 'error');
  }
}

// System Logs
async function refreshLogs() {
  if (!requireFeature('logs', 'System logs are not supported by the selected Lite agent.')) return;
  
  const source = document.getElementById('logSource').value;
  const level = document.getElementById('logLevel').value;
  const container = document.getElementById('logsContainer');
  
  container.innerHTML = '<div class="loading-state"><i class="fas fa-spinner fa-spin"></i> Loading logs...</div>';
  
  try {
    const response = await fetch(`/api/logs?source=${encodeURIComponent(source)}&level=${encodeURIComponent(level)}`);
    
    if (response.ok) {
      const data = await response.json();
      renderLogs(data.logs || []);
    } else {
      const error = await response.text();
      container.innerHTML = `<div class="error-state">Error: ${error}</div>`;
    }
  } catch (error) {
    console.error('Error:', error);
    container.innerHTML = '<div class="error-state">Failed to load logs</div>';
  }
}

function renderLogs(logs) {
  const container = document.getElementById('logsContainer');
  
  if (logs.length === 0) {
    container.innerHTML = '<div class="empty-state">No logs found</div>';
    return;
  }
  
  container.innerHTML = logs.map(log => {
    const date = new Date(log.timestamp * 1000);
    const levelClass = log.level?.toLowerCase() || 'info';
    return `
      <div class="log-entry log-${levelClass}">
        <div class="log-header">
          <span class="log-time">${date.toLocaleString()}</span>
          <span class="log-level">${escapeHtml(log.level || 'INFO')}</span>
          <span class="log-source">${escapeHtml(log.source || 'System')}</span>
        </div>
        <div class="log-message">${escapeHtml(log.message)}</div>
      </div>
    `;
  }).join('');
}

// Agent Control
async function agentAction(action) {
  if (!requireFeature('agent_control', 'Agent control actions are not supported by the selected Lite agent.')) return;
  
  if (!confirm(`Are you sure you want to ${action} the agent?`)) return;
  
  try {
    const response = await fetch(`/api/agent/${action}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    });
    
    if (response.ok) {
      showNotification(`Agent ${action} initiated`, 'success');
    } else {
      const error = await response.text();
      showNotification('Failed: ' + error, 'error');
    }
  } catch (error) {
    console.error('Error:', error);
    showNotification('Error with agent action', 'error');
  }
}

// ── Startup Control ───────────────────────────────────────────────────────────
// The Startup Control panel exposes a single concrete capability: toggle the
// agent's autostart persistence (HKCU\...\Run\MultiFS Agent) on the selected
// remote machine. It never copies/moves/deletes the agent binary.

function toggleStartupControl() {
  const panel = document.getElementById('startupControlPanel');
  if (!panel) return;
  panel.hidden = !panel.hidden;
  if (!panel.hidden) {
    refreshSetupControlAgentBadge(currentAgent);
    refreshStartupStatus();
  }
}

function refreshSetupControlAgentBadge(agent) {
  const badge = document.getElementById('startupSelectedAgent');
  if (!badge) return;
  if (!agent) {
    badge.textContent = 'no system selected';
    return;
  }
  const name = agent.display_name || agent.name || agent.key || 'selected system';
  const build = agent.build ? ` · ${agent.build}` : '';
  badge.textContent = `${name}${build}`;
}

function setStartupStatusUI(state, message) {
  const wrap = document.getElementById('startupControlStatus');
  if (!wrap) return;
  const dot = wrap.querySelector('.status-dot');
  const text = wrap.querySelector('.status-text');
  if (dot) {
    dot.classList.remove('status-on', 'status-off', 'status-unknown', 'status-busy');
    dot.classList.add(`status-${state}`);
  }
  if (text) text.textContent = message;
}

async function refreshStartupStatus() {
  if (!requireFeature('agent_control', 'Startup control is not supported by the selected Lite agent.')) return;
  setStartupStatusUI('busy', 'Checking startup status…');
  try {
    const response = await fetch('/api/agent/startup/status', { method: 'POST' });
    if (!response.ok) {
      const error = await response.text();
      setStartupStatusUI('unknown', `Could not read status: ${error}`);
      return;
    }
    const data = await response.json();
    if (data.installed) {
      setStartupStatusUI('on', `Startup is INSTALLED → ${data.path || 'unknown path'}`);
    } else {
      setStartupStatusUI('off', 'Startup is NOT installed on this system.');
    }
  } catch (error) {
    console.error('Startup status failed:', error);
    setStartupStatusUI('unknown', 'Could not reach the agent.');
  }
}

async function startupAction(action) {
  if (!requireFeature('agent_control', 'Startup control is not supported by the selected Lite agent.')) return;
  const verb = action === 'install' ? 'install' : 'uninstall';
  if (!confirm(`Are you sure you want to ${verb} the agent's startup persistence on the selected system?`)) return;

  setStartupStatusUI('busy', `${verb === 'install' ? 'Installing' : 'Uninstalling'} startup persistence…`);
  try {
    const response = await fetch(`/api/agent/startup/${verb}`, { method: 'POST' });
    if (!response.ok) {
      const error = await response.text();
      setStartupStatusUI('unknown', `${verb} failed: ${error}`);
      showNotification(`Startup ${verb} failed`, 'error');
      return;
    }
    const data = await response.json();
    if (verb === 'install') {
      setStartupStatusUI('on', `Startup INSTALLED → ${data.path || 'unknown path'}`);
      showNotification('Startup persistence installed', 'success');
    } else {
      setStartupStatusUI('off', 'Startup persistence removed.');
      showNotification('Startup persistence removed', 'success');
    }
  } catch (error) {
    console.error(`Startup ${verb} failed:`, error);
    setStartupStatusUI('unknown', `${verb} failed: ${error.message}`);
    showNotification(`Startup ${verb} failed`, 'error');
  }
}

// Helper functions
function checkAgent() {
  if (!currentAgent) {
    showNotification('Please select a system first', 'warning');
    return false;
  }
  return true;
}

function showNotification(message, type = 'info') {
  const notification = document.createElement('div');
  notification.className = `notification notification-${type}`;
  notification.innerHTML = `
    <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : type === 'warning' ? 'exclamation-triangle' : 'info-circle'}"></i>
    <span>${message}</span>
  `;
  
  document.body.appendChild(notification);
  
  // Animate in
  requestAnimationFrame(() => {
    notification.classList.add('show');
  });
  
  // Remove after delay
  setTimeout(() => {
    notification.classList.remove('show');
    setTimeout(() => notification.remove(), 300);
  }, 3000);
}

function escapeHtml(text) {
  if (!text) return '';
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function truncateString(str, maxLength) {
  if (!str) return '';
  if (str.length <= maxLength) return str;
  return str.substring(0, maxLength) + '...';
}

// Capability-aware UI gating is centralized in static/js/capabilities.js.
// Keep this wrapper for existing page initialization calls.
function applyCapabilities() {
  window.currentAgent = currentAgent;
  if (window.MultiFSCaps) window.MultiFSCaps.apply(currentAgent);
}

// ── Control Room update area ──────────────────────────────────────────────────

function bindControlUpdateForms() {
  const srv = document.getElementById('ctrlUpdateServerForm');
  if (srv) srv.addEventListener('submit', e =>
    submitCtrlUpdate(e, '/api/server/self-update', 'ctrlUpdateServerResult', 'Server'));
  const agent = document.getElementById('ctrlUpdateAgentForm');
  if (agent) agent.addEventListener('submit', e =>
    submitCtrlUpdate(e, '/api/agent/self-update', 'ctrlUpdateAgentResult', 'Agent'));
}

async function submitCtrlUpdate(event, endpoint, resultId, label) {
  event.preventDefault();
  const form      = event.currentTarget;
  const resultEl  = document.getElementById(resultId);
  const submitBtn = form.querySelector('button[type="submit"]');
  if (!resultEl) return;

  resultEl.classList.remove('show', 'error');
  resultEl.textContent = '';
  if (label === 'Agent' && !requireFeature('remote_update', 'The selected agent does not advertise remote_update.')) return;
  if (submitBtn) submitBtn.disabled = true;

  try {
    const fd       = new FormData(form);
    const response = await fetch(endpoint, { method: 'POST', body: fd });
    const text     = await response.text();
    let data;
    try { data = JSON.parse(text); } catch (_) { data = { raw: text }; }

    if (!response.ok) {
      resultEl.classList.add('show', 'error');
      resultEl.textContent = `${label} update failed (HTTP ${response.status}): ${data.raw || data.error || response.statusText}`;
      showCtrlNotification(`${label} update failed`, 'error');
    } else {
      resultEl.classList.add('show');
      const sha   = (data.sha256 || '').slice(0, 16);
      const bytes = data.bytes ? `${data.bytes.toLocaleString()} bytes` : '';
      resultEl.textContent = `${label} update accepted. ${bytes}${sha ? ', sha256=' + sha + '…' : ''}. ${data.message || 'A restart will follow.'}`;
      showCtrlNotification(`${label} update accepted`, 'success');
    }
  } catch (err) {
    resultEl.classList.add('show', 'error');
    resultEl.textContent = `${label} update failed: ${err.message}`;
    showCtrlNotification(`${label} update failed`, 'error');
  } finally {
    if (submitBtn) submitBtn.disabled = false;
    applyCapabilities();
  }
}

function refreshCtrlUpdateAgentBadge(agent) {
  const badge = document.getElementById('ctrlUpdateAgentBadge');
  if (!badge) return;
  if (!agent) { badge.textContent = 'no system selected'; return; }
  const v = agent.version || 'unknown';
  const b = agent.build ? ` · ${agent.build}` : '';
  badge.textContent = `${v}${b}`;
}

function showCtrlNotification(message, type = 'info') {
  // Reuse the global showNotification if present (defined in control.js already),
  // otherwise fall back to a simple inline version.
  if (typeof showNotification === 'function') { showNotification(message, type); return; }
  const icons = { success: 'check-circle', error: 'exclamation-circle', warning: 'exclamation-triangle', info: 'info-circle' };
  const n = document.createElement('div');
  n.className = `notification notification-${type}`;
  n.innerHTML = `<i class="fas fa-${icons[type] || 'info-circle'}"></i><span>${message}</span>`;
  document.body.appendChild(n);
  requestAnimationFrame(() => n.classList.add('show'));
  setTimeout(() => { n.classList.remove('show'); setTimeout(() => n.remove(), 300); }, 3500);
}
