// Settings JavaScript — single source of truth for client-side preferences.
//
// All keys are namespaced "multifs.*" with versioned suffixes to make
// migrations easy. The Appearance panel writes the same key as
// topbar-extras.js (multifs.theme.v1) so the theme toggle in the top-bar
// and the Settings dropdown stay synchronized.

const STORAGE_KEYS = {
  theme:               'multifs.theme.v1',
  density:             'multifs.density.v1',
  reduceMotion:        'multifs.reduceMotion.v1',
  showHidden:          'multifs.showHidden.v1',
  confirmBulkDelete:   'multifs.confirmBulkDelete.v1',
  rememberLastFolder:  'multifs.rememberLastFolder.v1',
  defaultSort:         'multifs.defaultSort.v1',
  autoRefreshInterval: 'multifs.autoRefresh.v1', // matches file-power-features.js
  recentPaths:         'multifs.recentPaths.v1',
};

const DEFAULTS = {
  theme:               'dark',
  density:             'comfortable',
  reduceMotion:        false,
  showHidden:          false,
  confirmBulkDelete:   true,
  rememberLastFolder:  true,
  defaultSort:         'name',
  autoRefreshInterval: '0',
};

document.addEventListener('DOMContentLoaded', () => {
  loadPreferences();
  bindAppearance();
  bindFileManager();
  bindResetButtons();
  bindUpdateForms();
  refreshUpdateAgentBadge();
  refreshAdvancedInfo();
  bindAdvancedRefresh();
  // Auto-poll the Advanced Info card every 15 s while the page is open.
  setInterval(refreshAdvancedInfo, 15000);
});

// ── Load + bind ─────────────────────────────────────────────────────────

function getPref(key) {
  try { return localStorage.getItem(STORAGE_KEYS[key]); } catch (_) { return null; }
}
function setPref(key, val) {
  try { localStorage.setItem(STORAGE_KEYS[key], String(val)); } catch (_) {}
}

function loadPreferences() {
  const setVal = (id, key) => {
    const el = document.getElementById(id);
    if (!el) return;
    const v = getPref(key);
    if (v != null) el.value = v;
    else el.value = DEFAULTS[key];
  };
  const setChecked = (id, key) => {
    const el = document.getElementById(id);
    if (!el) return;
    const v = getPref(key);
    el.checked = v != null ? v === 'true' : !!DEFAULTS[key];
  };

  setVal('themeSelect',         'theme');
  setVal('densitySelect',       'density');
  setVal('defaultSort',         'defaultSort');
  setVal('autoRefreshInterval', 'autoRefreshInterval');

  setChecked('reduceMotion',        'reduceMotion');
  setChecked('showHidden',          'showHidden');
  setChecked('confirmBulkDelete',   'confirmBulkDelete');
  setChecked('rememberLastFolder',  'rememberLastFolder');

  applyAppearanceFromPrefs();
}

function bindAppearance() {
  const theme   = document.getElementById('themeSelect');
  const density = document.getElementById('densitySelect');
  const motion  = document.getElementById('reduceMotion');

  if (theme)   theme.addEventListener('change',   () => { setPref('theme', theme.value);     applyTheme(theme.value);   syncTopbarLabel(); showNotification('Theme updated', 'success'); });
  if (density) density.addEventListener('change', () => { setPref('density', density.value); applyDensity(density.value); showNotification('Density updated', 'success'); });
  if (motion)  motion.addEventListener('change',  () => { setPref('reduceMotion', motion.checked); applyReduceMotion(motion.checked); });
}

function bindFileManager() {
  const wire = (id, key) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.addEventListener('change', () => {
      setPref(key, el.type === 'checkbox' ? el.checked : el.value);
      showNotification('File Manager preference saved', 'success');
    });
  };
  wire('showHidden',          'showHidden');
  wire('confirmBulkDelete',   'confirmBulkDelete');
  wire('rememberLastFolder',  'rememberLastFolder');
  wire('defaultSort',         'defaultSort');
  wire('autoRefreshInterval', 'autoRefreshInterval');
}

function bindResetButtons() {
  const clr = document.getElementById('clearRecentBtn');
  if (clr) clr.addEventListener('click', () => {
    try { localStorage.removeItem(STORAGE_KEYS.recentPaths); } catch (_) {}
    showNotification('Recent folders cleared', 'success');
  });
  const reset = document.getElementById('resetPrefsBtn');
  if (reset) reset.addEventListener('click', () => {
    if (!confirm('Reset all File Manager preferences to defaults?')) return;
    Object.values(STORAGE_KEYS).forEach(k => { try { localStorage.removeItem(k); } catch (_) {} });
    loadPreferences();
    syncTopbarLabel();
    showNotification('Preferences reset', 'success');
  });
}

// ── Appearance application (must match topbar-extras.js) ────────────────

function applyAppearanceFromPrefs() {
  const theme   = getPref('theme')   || DEFAULTS.theme;
  const density = getPref('density') || DEFAULTS.density;
  applyTheme(theme);
  applyDensity(density);
  applyReduceMotion(getPref('reduceMotion') === 'true');
}

function applyTheme(theme) {
  const resolved =
    theme === 'light' ? 'light' :
    theme === 'auto'  ? (matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark') :
    'dark';
  document.documentElement.dataset.theme = resolved;
  document.documentElement.dataset.themePref = theme;
}

function applyDensity(density) {
  const root = document.documentElement;
  root.classList.remove('density-compact', 'density-comfortable', 'density-spacious');
  root.classList.add(`density-${density}`);
  // The file manager has its own compact-files body class for table density.
  document.body.classList.toggle('compact-files', density === 'compact');
}

function applyReduceMotion(on) {
  document.documentElement.classList.toggle('reduce-motion', !!on);
}

// Keep the top-bar's theme-toggle label in sync if it exists.
function syncTopbarLabel() {
  const label = document.getElementById('themeToggleLabel');
  const pref  = getPref('theme') || DEFAULTS.theme;
  if (label) label.textContent = pref.charAt(0).toUpperCase() + pref.slice(1);
}

// ── Advanced System Information ─────────────────────────────────────────

function bindAdvancedRefresh() {
  const btn = document.getElementById('advRefreshBtn');
  if (btn) btn.addEventListener('click', () => {
    btn.classList.add('fa-spin');
    refreshAdvancedInfo().finally(() => btn.classList.remove('fa-spin'));
  });
}

async function refreshAdvancedInfo() {
  try {
    const r = await fetch('/api/server-info', { cache: 'no-store' });
    if (!r.ok) return;
    const d = await r.json();
    const set = (id, val) => {
      const el = document.getElementById(id);
      if (el) el.textContent = val == null ? '—' : String(val);
    };
    set('advVersion',    d.version || '—');
    set('advHostname',   d.hostname || '—');
    set('advOSArch',     d.os && d.arch ? `${d.os}/${d.arch}` : '—');
    set('advGoVer',      d.go_version || '—');
    set('advPID',        d.pid != null ? d.pid : '—');
    set('advUptime',     d.uptime_human || '—');
    set('advListen',     d.listen_addr || window.location.host);
    set('advSessions',   d.sessions != null ? d.sessions : '—');
    set('advAgents',     (d.agents_online != null && d.agents_total != null)
                          ? `${d.agents_online} / ${d.agents_total}` : '—');
    set('advSockets',    d.live_sockets != null ? d.live_sockets : '—');
    set('advGoroutines', d.goroutines != null ? d.goroutines : '—');
    set('advCPU',        d.cpu_cores != null ? d.cpu_cores : '—');
    set('advMemAlloc',   d.memory_alloc != null ? humanBytes(d.memory_alloc) : '—');
    set('advMemSys',     d.memory_sys   != null ? humanBytes(d.memory_sys)   : '—');
    set('advMemHeap',    d.memory_heap  != null ? humanBytes(d.memory_heap)  : '—');
    set('advGC',         d.gc_count != null ? d.gc_count : '—');
    set('advFrameCap',   d.frame_cap_bytes != null ? humanBytes(d.frame_cap_bytes) : '—');
    set('advLAN',        Array.isArray(d.lan_ips) && d.lan_ips.length ? d.lan_ips.join(', ') : '—');
  } catch (err) {
    console.warn('Could not refresh advanced info:', err);
  }
}

function humanBytes(n) {
  if (n == null) return '—';
  const u = ['B', 'KiB', 'MiB', 'GiB', 'TiB'];
  let i = 0;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return `${n.toFixed(i === 0 ? 0 : 1)} ${u[i]}`;
}

// ── Modals + notifications ──────────────────────────────────────────────

function showUninstallModal() { const m = document.getElementById('uninstallModal'); if (m) m.style.display = 'flex'; }
function hideUninstallModal() { const m = document.getElementById('uninstallModal'); if (m) m.style.display = 'none'; }

function showNotification(message, type = 'info') {
  const n = document.createElement('div');
  n.className = `notification notification-${type}`;
  n.innerHTML = `<i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : type === 'warning' ? 'exclamation-triangle' : 'info-circle'}"></i><span>${message}</span>`;
  document.body.appendChild(n);
  requestAnimationFrame(() => n.classList.add('show'));
  setTimeout(() => { n.classList.remove('show'); setTimeout(() => n.remove(), 300); }, 2400);
}

window.onclick = function (event) {
  if (event.target.classList.contains('modal')) event.target.style.display = 'none';
};

// ── Update area (kept from original settings.js) ────────────────────────

function bindUpdateForms() {
  const srv = document.getElementById('updateServerForm');
  if (srv) srv.addEventListener('submit', e => submitUpdate(e, '/api/server/self-update', 'updateServerResult', 'Server'));
  const agent = document.getElementById('updateAgentForm');
  if (agent) agent.addEventListener('submit', e => submitUpdate(e, '/api/agent/self-update', 'updateAgentResult', 'Agent'));
}

async function submitUpdate(event, endpoint, resultId, label) {
  event.preventDefault();
  const form = event.currentTarget;
  const result = document.getElementById(resultId);
  const submitBtn = form.querySelector('button[type="submit"]');
  if (!result) return;
  result.classList.remove('show', 'error');
  result.textContent = '';
  if (submitBtn) submitBtn.disabled = true;
  try {
    const fd = new FormData(form);
    const response = await fetch(endpoint, { method: 'POST', body: fd });
    const text = await response.text();
    let data; try { data = JSON.parse(text); } catch (_) { data = { raw: text }; }
    if (!response.ok) {
      result.classList.add('show', 'error');
      result.textContent = `${label} update failed (${response.status}): ${data.raw || data.error || response.statusText}`;
      showNotification(`${label} update failed`, 'error');
    } else {
      result.classList.add('show');
      const sha = (data.sha256 || '').slice(0, 16);
      const bytes = data.bytes || 0;
      result.textContent = `${label} update staged. ${bytes} bytes, sha256=${sha}…. ${data.message || 'A restart will follow.'}`;
      showNotification(`${label} update accepted`, 'success');
    }
  } catch (err) {
    result.classList.add('show', 'error');
    result.textContent = `${label} update failed: ${err.message}`;
    showNotification(`${label} update failed`, 'error');
  } finally {
    if (submitBtn) submitBtn.disabled = false;
  }
}

async function refreshUpdateAgentBadge() {
  const badge = document.getElementById('updateAgentBadge');
  if (!badge) return;
  try {
    const response = await fetch('/api/current-agent', { cache: 'no-store' });
    const data = await response.json();
    if (data.agent) {
      const v = data.agent.version || 'unknown';
      const b = data.agent.build ? ` · ${data.agent.build}` : '';
      badge.textContent = `${v}${b}`;
    } else {
      badge.textContent = 'no system selected';
    }
  } catch (_) {
    badge.textContent = 'unknown';
  }
}
