#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build dist

if ! command -v go >/dev/null 2>&1; then
  echo "ERROR: Go was not found. Install Go 1.21+ and rerun this script." >&2
  exit 1
fi

echo "Building Windows server.exe..."
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -buildvcs=false -ldflags='-s -w -buildid=' -o build/multifs-server.exe .
cp build/multifs-server.exe dist/server.exe

echo "Building Windows Full agent.exe..."
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -tags=agent -trimpath -buildvcs=false -ldflags='-s -w -buildid=' -o build/multifs-agent-full-go.exe .
cp build/multifs-agent-full-go.exe dist/agent.exe

echo "Building Windows Full agent no-console EXE (-H=windowsgui)..."
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -tags=agent -trimpath -buildvcs=false -ldflags='-s -w -buildid= -H=windowsgui' -o build/multifs-agent-full-go-windowsgui.exe .
cp build/multifs-agent-full-go-windowsgui.exe dist/agent-windowsgui.exe

echo "Building Windows native Lite agent.exe..."
if bash tools/build_native_lite_windows.sh; then
  :
else
  status=$?
  if [ -f build/multifs-agent-lite-native.exe ] && [ -f build/multifs-agent-lite-native-stripped.exe ]; then
    echo "WARNING: Native Lite rebuild failed with status $status; using existing prebuilt Lite EXEs from build/." >&2
    cp build/multifs-agent-lite-native.exe dist/multifs-agent-lite-native.exe
    cp build/multifs-agent-lite-native-stripped.exe dist/multifs-agent-lite-native-stripped.exe
  else
    echo "ERROR: Native Lite build failed and no prebuilt Lite EXE exists." >&2
    exit "$status"
  fi
fi

if command -v sha256sum >/dev/null 2>&1; then
  sha256sum build/multifs-server.exe build/multifs-agent-full-go.exe build/multifs-agent-full-go-windowsgui.exe build/multifs-agent-lite-native.exe build/multifs-agent-lite-native-stripped.exe build/multifs-agent-lite-native-windowsgui.exe build/multifs-agent-lite-native-windowsgui-stripped.exe > build/SHA256SUMS.txt
  cp build/SHA256SUMS.txt dist/SHA256SUMS.txt
fi

echo ""
echo "Done. Windows EXEs:"
ls -lh build/multifs-server.exe build/multifs-agent-full-go.exe build/multifs-agent-full-go-windowsgui.exe build/multifs-agent-lite-native.exe build/multifs-agent-lite-native-stripped.exe build/multifs-agent-lite-native-windowsgui.exe build/multifs-agent-lite-native-windowsgui-stripped.exe dist/server.exe dist/agent.exe dist/agent-windowsgui.exe dist/multifs-agent-lite-native.exe dist/multifs-agent-lite-native-stripped.exe dist/multifs-agent-lite-native-windowsgui.exe dist/multifs-agent-lite-native-windowsgui-stripped.exe
