/*
 * MultiFS Lite Native Windows Agent
 *
 * Explicit-run agent for authorized LAN file management.
 * Built without CRT to keep the PE under 100 KB.
 *
 * 2026-05-24 revision (b): feature parity pass with the Full Go agent.
 * The Lite agent previously only implemented filesystem ops; the Full
 * agent's recent additions (Startup Control, Agent Control, Shell, chunked
 * downloads) were advertised to clients but never reached the wire.
 *
 * This revision adds, to the existing filesystem ops:
 *   - read_chunk         streaming-download companion to `read`
 *   - shell              cmd.exe /c with temp-file output capture
 *   - agent_close        graceful exit
 *   - agent_relaunch     hidden self-restart preserving --server/--key/...
 *   - agent_uninstall    silent self-uninstall (same "(goto)" idiom as the
 *                        Full agent's uninstall_windows.go uninstallSelf)
 *   - agent_startup_install / _uninstall / _status
 *                        toggle HKCU Run\MultiFS Agent
 *
 * Earlier shrink pass kept intact: stack-allocated JSON key patterns, the
 * single `out()` diagnostic helper, and the trimmed help/verbose text.
 *
 * Hello advertises: files_read, files_write, remote_update, agent_control,
 * shell — matching what the agent really implements end-to-end. The server's
 * apiAgentStartup and apiAgentControl handlers gate on agent_control; the
 * shell handler gates on shell.
 */
#ifndef NULL
#define NULL ((void*)0)
#endif
#define WINAPI __stdcall
#define INVALID_SOCKET (~0ULL)
#define SOCKET_ERROR (-1)
#define AF_UNSPEC 0
#define AF_INET 2
#define SOCK_STREAM 1
#define IPPROTO_TCP 6
#define SD_BOTH 2
#define INVALID_HANDLE_VALUE ((void*)(-1))
#define TRUE 1
#define FALSE 0
#define FILE_ATTRIBUTE_DIRECTORY 0x10u
#define FILE_ATTRIBUTE_NORMAL 0x80u
#define GENERIC_READ 0x80000000u
#define GENERIC_WRITE 0x40000000u
#define FILE_SHARE_READ 1u
#define FILE_SHARE_WRITE 2u
#define OPEN_EXISTING 3u
#define CREATE_ALWAYS 2u
#define FILE_BEGIN 0u
#define MOVEFILE_REPLACE_EXISTING 1u
#define MAX_PATH_LITE 1024u
#define MFS_MAX_FRAME (32u*1024u*1024u)
#define MFS_MAX_FILE  (8u*1024u*1024u)
#define MFS_MAX_CHUNK (16u*1024u*1024u)
#define MFS_DEFAULT_CHUNK (4u*1024u*1024u)
#define MFS_MAX_UPDATE (24u*1024u*1024u)
#define PROV_RSA_AES 24u
#define CRYPT_VERIFYCONTEXT 0xF0000000u
#define CALG_SHA_256 0x0000800cu
#define HP_HASHVAL 0x0002u
#define SW_HIDE 0
#define STD_OUTPUT_HANDLE ((DWORD)-11)
#define HKEY_CURRENT_USER ((HKEY)(ULONG_PTR)0x80000001UL)
#define KEY_QUERY_VALUE 0x0001u
#define KEY_SET_VALUE 0x0002u
#define REG_SZ 1u
#define STARTF_USESHOWWINDOW 0x00000001u
#define CREATE_NO_WINDOW 0x08000000u
#define WAIT_TIMEOUT 0x00000102u
#define INFINITE 0xFFFFFFFFu

typedef unsigned long DWORD;
typedef int BOOL;
typedef unsigned short WORD;
typedef unsigned char BYTE;
typedef unsigned long long QWORD;
typedef long long I64;
typedef unsigned long long U64;
typedef unsigned int UINT;
typedef unsigned long long SIZE_T;
typedef unsigned long long ULONG_PTR;
typedef ULONG_PTR SOCKET;
typedef void *HANDLE;
typedef ULONG_PTR HCRYPTPROV;
typedef ULONG_PTR HCRYPTHASH;
typedef ULONG_PTR HKEY;
typedef HKEY *PHKEY;
typedef unsigned int ALG_ID;
typedef const char *LPCSTR;
typedef char *LPSTR;
typedef long LONG;
typedef LONG *PLONG;

typedef struct {
    DWORD  cb;
    LPSTR  lpReserved;
    LPSTR  lpDesktop;
    LPSTR  lpTitle;
    DWORD  dwX, dwY, dwXSize, dwYSize;
    DWORD  dwXCountChars, dwYCountChars;
    DWORD  dwFillAttribute;
    DWORD  dwFlags;
    WORD   wShowWindow;
    WORD   cbReserved2;
    BYTE  *lpReserved2;
    HANDLE hStdInput, hStdOutput, hStdError;
} STARTUPINFOA;

typedef struct {
    HANDLE hProcess;
    HANDLE hThread;
    DWORD  dwProcessId;
    DWORD  dwThreadId;
} PROCESS_INFORMATION;

typedef struct { DWORD dwLowDateTime; DWORD dwHighDateTime; } FILETIME;
typedef struct { DWORD dwFileAttributes; FILETIME ftCreationTime; FILETIME ftLastAccessTime; FILETIME ftLastWriteTime; DWORD nFileSizeHigh; DWORD nFileSizeLow; DWORD dwReserved0; DWORD dwReserved1; char cFileName[260]; char cAlternateFileName[14]; DWORD dwFileType; DWORD dwCreatorType; WORD wFinderFlags; } WIN32_FIND_DATAA;
typedef struct { DWORD dwFileAttributes; FILETIME ftCreationTime; FILETIME ftLastAccessTime; FILETIME ftLastWriteTime; DWORD nFileSizeHigh; DWORD nFileSizeLow; } WIN32_FILE_ATTRIBUTE_DATA;
typedef struct sockaddr { WORD sa_family; char sa_data[14]; } SOCKADDR;
typedef struct addrinfoA { int ai_flags; int ai_family; int ai_socktype; int ai_protocol; SIZE_T ai_addrlen; char *ai_canonname; struct sockaddr *ai_addr; struct addrinfoA *ai_next; } ADDRINFOA;
typedef struct { WORD wVersion; WORD wHighVersion; char szDescription[257]; char szSystemStatus[129]; unsigned short iMaxSockets; unsigned short iMaxUdpDg; char *lpVendorInfo; } WSADATA;
typedef struct { unsigned int fd_count; SOCKET fd_array[64]; } FD_SET_LITE;
typedef struct { long tv_sec; long tv_usec; } TIMEVAL_LITE;

__declspec(dllimport) void WINAPI ExitProcess(UINT);
__declspec(dllimport) void WINAPI Sleep(DWORD);
__declspec(dllimport) DWORD WINAPI GetTickCount(void);
__declspec(dllimport) DWORD WINAPI GetCurrentProcessId(void);
__declspec(dllimport) HANDLE WINAPI GetStdHandle(DWORD);
__declspec(dllimport) DWORD WINAPI GetLastError(void);
__declspec(dllimport) HANDLE WINAPI GetProcessHeap(void);
__declspec(dllimport) void *WINAPI HeapAlloc(HANDLE,DWORD,SIZE_T);
__declspec(dllimport) void *WINAPI HeapReAlloc(HANDLE,DWORD,void*,SIZE_T);
__declspec(dllimport) BOOL WINAPI HeapFree(HANDLE,DWORD,void*);
__declspec(dllimport) DWORD WINAPI GetEnvironmentVariableA(LPCSTR,LPSTR,DWORD);
__declspec(dllimport) BOOL WINAPI GetComputerNameA(LPSTR,DWORD*);
__declspec(dllimport) DWORD WINAPI GetCurrentDirectoryA(DWORD,LPSTR);
__declspec(dllimport) DWORD WINAPI GetFullPathNameA(LPCSTR,DWORD,LPSTR,LPSTR*);
__declspec(dllimport) DWORD WINAPI GetLogicalDrives(void);
__declspec(dllimport) BOOL WINAPI GetFileAttributesExA(LPCSTR,int,void*);
__declspec(dllimport) HANDLE WINAPI FindFirstFileA(LPCSTR,WIN32_FIND_DATAA*);
__declspec(dllimport) BOOL WINAPI FindNextFileA(HANDLE,WIN32_FIND_DATAA*);
__declspec(dllimport) BOOL WINAPI FindClose(HANDLE);
__declspec(dllimport) HANDLE WINAPI CreateFileA(LPCSTR,DWORD,DWORD,void*,DWORD,DWORD,HANDLE);
__declspec(dllimport) BOOL WINAPI ReadFile(HANDLE,void*,DWORD,DWORD*,void*);
__declspec(dllimport) BOOL WINAPI WriteFile(HANDLE,const void*,DWORD,DWORD*,void*);
__declspec(dllimport) DWORD WINAPI SetFilePointer(HANDLE,LONG,PLONG,DWORD);
__declspec(dllimport) BOOL WINAPI CloseHandle(HANDLE);
__declspec(dllimport) BOOL WINAPI CreateDirectoryA(LPCSTR,void*);
__declspec(dllimport) BOOL WINAPI DeleteFileA(LPCSTR);
__declspec(dllimport) BOOL WINAPI RemoveDirectoryA(LPCSTR);
__declspec(dllimport) BOOL WINAPI MoveFileExA(LPCSTR,LPCSTR,DWORD);
__declspec(dllimport) DWORD WINAPI GetModuleFileNameA(HANDLE,LPSTR,DWORD);
__declspec(dllimport) UINT WINAPI WinExec(LPCSTR,UINT);
__declspec(dllimport) char *WINAPI GetCommandLineA(void);
__declspec(dllimport) DWORD WINAPI GetFileSize(HANDLE,DWORD*);
__declspec(dllimport) BOOL WINAPI CreateProcessA(LPCSTR,LPSTR,void*,void*,BOOL,DWORD,void*,LPCSTR,STARTUPINFOA*,PROCESS_INFORMATION*);
__declspec(dllimport) DWORD WINAPI WaitForSingleObject(HANDLE,DWORD);
__declspec(dllimport) BOOL WINAPI GetExitCodeProcess(HANDLE,DWORD*);

__declspec(dllimport) int WINAPI WSAStartup(WORD,WSADATA*);
__declspec(dllimport) int WINAPI WSACleanup(void);
__declspec(dllimport) SOCKET WINAPI socket(int,int,int);
__declspec(dllimport) int WINAPI connect(SOCKET,const SOCKADDR*,int);
__declspec(dllimport) int WINAPI send(SOCKET,const char*,int,int);
__declspec(dllimport) int WINAPI recv(SOCKET,char*,int,int);
__declspec(dllimport) int WINAPI select(int,FD_SET_LITE*,FD_SET_LITE*,FD_SET_LITE*,const TIMEVAL_LITE*);
__declspec(dllimport) int WINAPI closesocket(SOCKET);
__declspec(dllimport) int WINAPI shutdown(SOCKET,int);
__declspec(dllimport) int WINAPI getaddrinfo(const char*,const char*,const ADDRINFOA*,ADDRINFOA**);
__declspec(dllimport) void WINAPI freeaddrinfo(ADDRINFOA*);

__declspec(dllimport) BOOL WINAPI CryptAcquireContextA(HCRYPTPROV*,LPCSTR,LPCSTR,DWORD,DWORD);
__declspec(dllimport) BOOL WINAPI CryptCreateHash(HCRYPTPROV,ALG_ID,HCRYPTPROV,DWORD,HCRYPTHASH*);
__declspec(dllimport) BOOL WINAPI CryptHashData(HCRYPTHASH,const BYTE*,DWORD,DWORD);
__declspec(dllimport) BOOL WINAPI CryptGetHashParam(HCRYPTHASH,DWORD,BYTE*,DWORD*,DWORD);
__declspec(dllimport) BOOL WINAPI CryptDestroyHash(HCRYPTHASH);
__declspec(dllimport) BOOL WINAPI CryptReleaseContext(HCRYPTPROV,DWORD);
__declspec(dllimport) LONG WINAPI RegOpenKeyExA(HKEY,LPCSTR,DWORD,DWORD,PHKEY);
__declspec(dllimport) LONG WINAPI RegSetValueExA(HKEY,LPCSTR,DWORD,DWORD,const BYTE*,DWORD);
__declspec(dllimport) LONG WINAPI RegDeleteValueA(HKEY,LPCSTR);
__declspec(dllimport) LONG WINAPI RegQueryValueExA(HKEY,LPCSTR,DWORD*,DWORD*,BYTE*,DWORD*);
__declspec(dllimport) LONG WINAPI RegCloseKey(HKEY);

static HANDLE g_heap;
static char g_server[384] = "ws://127.0.0.1:8080/ws/agent";
static char g_host[192] = "127.0.0.1";
static char g_port[16] = "8080";
static char g_path[160] = "/ws/agent";
static char g_password[192] = "mlan-wtsKrrx9caxjVPLo";
static char g_key[128] = "";
static char g_name[128] = "";
static char g_root[MAX_PATH_LITE] = "";
static int g_once = 0;
static int g_quiet = 0;
static DWORD g_retry_ms = 30000u;
static int g_exit_after_resp = 0;
static unsigned int g_rng = 0x31415926u;

/* ── tiny string / mem helpers ──────────────────────────────────────────── */
static SIZE_T m_len(const char *s){ SIZE_T n=0; if(!s) return 0; while(s[n]) n++; return n; }
static void m_copy(char *d,const char*s,SIZE_T cap){ SIZE_T i=0; if(!d||cap==0)return; if(!s)s=""; for(;i+1<cap&&s[i];i++)d[i]=s[i]; d[i]=0; }
static int m_eq(const char*a,const char*b){ SIZE_T i=0; if(!a||!b)return 0; for(;a[i]&&b[i];i++) if(a[i]!=b[i]) return 0; return a[i]==b[i]; }
static int m_starts(const char*s,const char*p){ SIZE_T i=0; if(!s||!p)return 0; for(;p[i];i++) if(s[i]!=p[i]) return 0; return 1; }
static char lowerc(char c){ return (c>='A'&&c<='Z')?(char)(c+32):c; }
static const char *m_strstr(const char*h,const char*n){ SIZE_T nl=m_len(n); if(!nl)return h; for(;h&&*h;h++){ SIZE_T i=0; while(i<nl && h[i]==n[i]) i++; if(i==nl)return h; } return NULL; }
static void *m_memcpy(void*d,const void*s,SIZE_T n){ BYTE*dd=(BYTE*)d; const BYTE*ss=(const BYTE*)s; while(n--)*dd++=*ss++; return d; }
static void *m_memset(void*d,int v,SIZE_T n){ BYTE*dd=(BYTE*)d; while(n--)*dd++=(BYTE)v; return d; }
static void *xalloc(SIZE_T n){ return HeapAlloc(g_heap,0,n?n:1); }
static void *xrealloc(void*p,SIZE_T n){ if(!p)return HeapAlloc(g_heap,0,n?n:1); return HeapReAlloc(g_heap,0,p,n?n:1); }
static void xfree(void*p){ if(p) HeapFree(g_heap,0,p); }

/* ── growable byte buffer ──────────────────────────────────────────────── */
typedef struct { char *p; SIZE_T n, cap; } buf_t;
static int b_res(buf_t*b,SIZE_T add){ SIZE_T need=b->n+add+1; if(need<=b->cap)return 1; SIZE_T nc=b->cap?b->cap*2:512; while(nc<need)nc*=2; char*np=(char*)xrealloc(b->p,nc); if(!np)return 0; b->p=np; b->cap=nc; return 1; }
static int b_addn(buf_t*b,const char*s,SIZE_T n){ if(!b_res(b,n))return 0; m_memcpy(b->p+b->n,s,n); b->n+=n; b->p[b->n]=0; return 1; }
static int b_add(buf_t*b,const char*s){ return b_addn(b,s,m_len(s)); }
static int b_ch(buf_t*b,char c){ return b_addn(b,&c,1); }
static void b_free(buf_t*b){ xfree(b->p); b->p=NULL; b->n=b->cap=0; }
static void b_u64(buf_t*b,U64 v){ char tmp[32]; int i=0; if(!v){b_ch(b,'0'); return;} while(v){ tmp[i++]=(char)('0'+(v%10)); v/=10; } while(i--) b_ch(b,tmp[i]); }
static void b_i64(buf_t*b,I64 v){ if(v<0){ b_ch(b,'-'); b_u64(b,(U64)(-v)); } else b_u64(b,(U64)v); }
static void b_hex8(buf_t*b,DWORD v){ const char*h="0123456789abcdef"; int i; for(i=28;i>=0;i-=4) b_ch(b,h[(v>>i)&15]); }
static void json_str(buf_t*b,const char*s){ b_ch(b,'\"'); if(!s)s=""; while(*s){ unsigned char c=(unsigned char)*s++; if(c=='\"')b_add(b,"\\\""); else if(c=='\\')b_add(b,"\\\\"); else if(c=='\n')b_add(b,"\\n"); else if(c=='\r')b_add(b,"\\r"); else if(c=='\t')b_add(b,"\\t"); else if(c<32){ b_add(b,"\\u00"); b_ch(b,"0123456789abcdef"[(c>>4)&15]); b_ch(b,"0123456789abcdef"[c&15]); } else b_ch(b,(char)c); } b_ch(b,'\"'); }

static unsigned int rnd(void){ unsigned int x=g_rng; x^=x<<13; x^=x>>17; x^=x<<5; g_rng=x?x:0x12345678u; return g_rng; }

/* ── output (one consolidated path) ────────────────────────────────────── */
static void out(const char*s){ if(g_quiet||!s)return; DWORD wr=0; HANDLE h=GetStdHandle(STD_OUTPUT_HANDLE); if(h&&h!=INVALID_HANDLE_VALUE){ WriteFile(h,s,(DWORD)m_len(s),&wr,NULL); WriteFile(h,"\r\n",2,&wr,NULL); } }

/* ── URL / argv parsing ────────────────────────────────────────────────── */
static void parse_url(void){
    const char*u=g_server; if(m_starts(u,"ws://"))u+=5; else if(m_starts(u,"http://"))u+=7;
    char hp[256]; SIZE_T i=0; while(u[i] && u[i]!='/' && i+1<sizeof(hp)){ hp[i]=u[i]; i++; } hp[i]=0;
    char *colon=NULL; for(SIZE_T j=0;hp[j];j++) if(hp[j]==':') colon=&hp[j];
    if(colon){ *colon=0; m_copy(g_host,hp,sizeof(g_host)); m_copy(g_port,colon+1,sizeof(g_port)); } else { m_copy(g_host,hp,sizeof(g_host)); m_copy(g_port,"80",sizeof(g_port)); }
    if(u[i]=='/') m_copy(g_path,u+i,sizeof(g_path)); else m_copy(g_path,"/ws/agent",sizeof(g_path));
    if(!g_path[0] || m_eq(g_path,"/") || m_eq(g_path,"/ws")) m_copy(g_path,"/ws/agent",sizeof(g_path));
}

static char *next_arg(char **pp,char*out,SIZE_T cap){
    char*p=*pp; SIZE_T n=0; while(*p==' '||*p=='\t')p++; if(!*p){*pp=p;return NULL;} if(*p=='\"'){ p++; while(*p&&*p!='\"'&&n+1<cap)out[n++]=*p++; if(*p=='\"')p++; } else { while(*p&&*p!=' '&&*p!='\t'&&n+1<cap)out[n++]=*p++; } out[n]=0; *pp=p; return out;
}
static void parse_cmd(void){
    char *cmd=GetCommandLineA(); char tok[512]; char *p=cmd; next_arg(&p,tok,sizeof(tok));
    while(next_arg(&p,tok,sizeof(tok))){
        if(m_eq(tok,"--server") && next_arg(&p,tok,sizeof(tok))) m_copy(g_server,tok,sizeof(g_server));
        else if(m_eq(tok,"--password") && next_arg(&p,tok,sizeof(tok))) m_copy(g_password,tok,sizeof(g_password));
        else if(m_eq(tok,"--key") && next_arg(&p,tok,sizeof(tok))) m_copy(g_key,tok,sizeof(g_key));
        else if(m_eq(tok,"--name") && next_arg(&p,tok,sizeof(tok))) m_copy(g_name,tok,sizeof(g_name));
        else if(m_eq(tok,"--root") && next_arg(&p,tok,sizeof(tok))) m_copy(g_root,tok,sizeof(g_root));
        else if(m_eq(tok,"--once")) g_once=1;
        else if(m_eq(tok,"--quiet")) g_quiet=1;
        else if(m_eq(tok,"--retry") && next_arg(&p,tok,sizeof(tok))){ int v=0; for(char*q=tok;*q;q++){ if(*q<'0'||*q>'9'){v=0;break;} v=v*10+(*q-'0'); } if(v>=5&&v<=3600) g_retry_ms=(DWORD)v*1000u; }
        /* --verbose / --help / -h are accepted silently for backward compat. */
    }
}
static void env_default(const char*k,char*out,SIZE_T cap){ char tmp[512]; DWORD n=GetEnvironmentVariableA(k,tmp,(DWORD)sizeof(tmp)); if(n>0 && n<sizeof(tmp)) m_copy(out,tmp,cap); }
static void init_config(void){
    DWORD n=(DWORD)sizeof(g_name); GetComputerNameA(g_name,&n);
    env_default("MULTIFS_SERVER",g_server,sizeof(g_server)); env_default("MULTIFS_PASSWORD",g_password,sizeof(g_password)); env_default("MULTIFS_KEY",g_key,sizeof(g_key));
    parse_cmd(); parse_url();
    if(!g_name[0]) m_copy(g_name,"native-lite",sizeof(g_name));
    if(!g_key[0]){ buf_t b={0}; b_add(&b,"lite-"); b_add(&b,g_name); b_ch(&b,'-'); b_hex8(&b,GetCurrentProcessId()); m_copy(g_key,b.p,sizeof(g_key)); b_free(&b); }
    if(!g_root[0]){ DWORD got=GetEnvironmentVariableA("USERPROFILE",g_root,(DWORD)sizeof(g_root)); if(got==0||got>=sizeof(g_root)) GetCurrentDirectoryA((DWORD)sizeof(g_root),g_root); }
    char full[MAX_PATH_LITE]; if(GetFullPathNameA(g_root,(DWORD)sizeof(full),full,NULL)>0) m_copy(g_root,full,sizeof(g_root));
}

/* ── path allow-list ───────────────────────────────────────────────────── */
static int drive_index(char c){ c=lowerc(c); if(c<'a'||c>'z')return -1; return (int)(c-'a'); }
static int is_drive_abs_path(const char*p){ return p && ((p[0]>='A'&&p[0]<='Z')||(p[0]>='a'&&p[0]<='z')) && p[1]==':' && (p[2]=='\\'||p[2]=='/'||p[2]==0); }
static int drive_exists_char(char c){ int i=drive_index(c); if(i<0)return 0; return (GetLogicalDrives() & (1u<<i))!=0; }
static int allowed_path(const char*in,char*out,SIZE_T cap){
    char fixed[MAX_PATH_LITE]; const char*p=(in&&in[0])?in:g_root;
    if(p && ((p[0]>='A'&&p[0]<='Z')||(p[0]>='a'&&p[0]<='z')) && p[1]==':' && p[2]==0){ fixed[0]=p[0]; fixed[1]=':'; fixed[2]='\\'; fixed[3]=0; p=fixed; }
    char full[MAX_PATH_LITE]; if(GetFullPathNameA(p,(DWORD)sizeof(full),full,NULL)==0) return 0;
    m_copy(out,full,cap);
    if(is_drive_abs_path(out) && drive_exists_char(out[0])) return 1;
    /* prefix match against g_root with case-folding (inlined m_istarts) */
    SIZE_T rl=m_len(g_root); SIZE_T i; int ok=1;
    for(i=0;i<rl && out[i];i++) if(lowerc(out[i])!=lowerc(g_root[i])){ ok=0; break; }
    if(ok && i==rl){ char c=out[rl]; if(c==0||c=='\\'||c=='/') return 1; }
    if(rl==3 && g_root[1]==':' && (g_root[2]=='\\'||g_root[2]=='/') && lowerc(out[0])==lowerc(g_root[0]) && out[1]==':') return 1;
    return 0;
}
static I64 filetime_unix(FILETIME ft){ U64 t=((U64)ft.dwHighDateTime<<32)|(U64)ft.dwLowDateTime; if(t<116444736000000000ULL)return 0; return (I64)((t-116444736000000000ULL)/10000000ULL); }
static U64 fsize_hi_low(DWORD hi,DWORD lo){ return ((U64)hi<<32)|(U64)lo; }

/* ── base64 ────────────────────────────────────────────────────────────── */
static const char b64t[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
static char *b64enc(const BYTE*src,SIZE_T len,SIZE_T*outn){ SIZE_T olen=((len+2)/3)*4; char*out=(char*)xalloc(olen+1); if(!out)return NULL; SIZE_T i=0,j=0; while(i<len){ unsigned a=i<len?src[i++]:0,b=i<len?src[i++]:0,c=i<len?src[i++]:0; unsigned t=(a<<16)|(b<<8)|c; out[j++]=b64t[(t>>18)&63]; out[j++]=b64t[(t>>12)&63]; out[j++]=b64t[(t>>6)&63]; out[j++]=b64t[t&63]; } if(len%3){ out[olen-1]='='; if(len%3==1)out[olen-2]='='; } out[olen]=0; if(outn)*outn=olen; return out; }
static int b64v(char c){ if(c>='A'&&c<='Z')return c-'A'; if(c>='a'&&c<='z')return c-'a'+26; if(c>='0'&&c<='9')return c-'0'+52; if(c=='+')return 62; if(c=='/')return 63; if(c=='=')return -2; return -1; }
static BYTE *b64dec(const char*s,SIZE_T*outn){ SIZE_T len=m_len(s), cap=(len/4)*3+4; BYTE*out=(BYTE*)xalloc(cap); if(!out)return NULL; int q[4],qi=0; SIZE_T j=0; for(SIZE_T i=0;i<len;i++){ int v=b64v(s[i]); if(v==-1)continue; q[qi++]=v; if(qi==4){ unsigned t=((unsigned)q[0]<<18)|((unsigned)q[1]<<12)|((unsigned)(q[2]<0?0:q[2])<<6)|(unsigned)(q[3]<0?0:q[3]); out[j++]=(BYTE)((t>>16)&255); if(q[2]!=-2)out[j++]=(BYTE)((t>>8)&255); if(q[3]!=-2)out[j++]=(BYTE)(t&255); qi=0; } } if(outn)*outn=j; return out; }


/* ── small utilities used by self_update + write ───────────────────────── */
static int write_file_all(const char*path,const BYTE*data,SIZE_T n){ HANDLE f=CreateFileA(path,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL); if(f==INVALID_HANDLE_VALUE)return 0; DWORD wr=0; int ok=WriteFile(f,data,(DWORD)n,&wr,NULL)&&wr==(DWORD)n; CloseHandle(f); return ok; }
static void cmd_quote(buf_t*b,const char*s){ b_ch(b,'"'); if(!s)s=""; while(*s){ if(*s=='"') b_add(b,"\"\""); else b_ch(b,*s); s++; } b_ch(b,'"'); }
static int append_suffix(char*out,SIZE_T cap,const char*base,const char*suf){ SIZE_T l=m_len(base), sl=m_len(suf); if(l+sl+1>cap)return 0; m_copy(out,base,cap); m_copy(out+l,suf,cap-l); return 1; }
static int hex_eq_ci(const char*a,const char*b){ if(!a||!b)return 0; for(int i=0;i<64;i++){ if(!a[i]||!b[i])return 0; if(lowerc(a[i])!=lowerc(b[i]))return 0; } return a[64]==0 || a[64]==' ' || a[64]=='"' || a[64]==',' || a[64]=='}'; }
static int sha256_hex_win(const BYTE*data,SIZE_T n,char out[65]){ HCRYPTPROV prov=0; HCRYPTHASH hash=0; BYTE digest[32]; DWORD cb=32; const char*hx="0123456789abcdef"; if(!CryptAcquireContextA(&prov,NULL,NULL,PROV_RSA_AES,CRYPT_VERIFYCONTEXT))return 0; if(!CryptCreateHash(prov,CALG_SHA_256,0,0,&hash)){CryptReleaseContext(prov,0);return 0;} if(!CryptHashData(hash,data,(DWORD)n,0)){CryptDestroyHash(hash);CryptReleaseContext(prov,0);return 0;} if(!CryptGetHashParam(hash,HP_HASHVAL,digest,&cb,0)||cb!=32){CryptDestroyHash(hash);CryptReleaseContext(prov,0);return 0;} CryptDestroyHash(hash); CryptReleaseContext(prov,0); for(int i=0;i<32;i++){ out[i*2]=hx[(digest[i]>>4)&15]; out[i*2+1]=hx[digest[i]&15]; } out[64]=0; return 1; }

/* ── JSON key lookup: stack-allocated patterns ──────────────────────────
 *
 * Previously each lookup allocated a buf_t, formatted "\"key\"" into it,
 * copied that into a stack buffer, then freed the buf_t. The new path
 * keeps the pattern on the stack and does a direct byte-fill — no heap
 * round-trip and one fewer function in the binary.
 */
static SIZE_T make_pat(char *out,SIZE_T cap,const char*key){
    SIZE_T pl=m_len(key); if(pl+3>cap){ if(cap) out[0]=0; return 0; }
    out[0]='"'; m_memcpy(out+1,key,pl); out[pl+1]='"'; out[pl+2]=0;
    return pl+2;
}
static const char *find_value_after_key(const char*js,const char*key){
    char pat[80]; SIZE_T pl=make_pat(pat,sizeof(pat),key); if(!pl)return NULL;
    const char*p=m_strstr(js,pat); if(!p)return NULL;
    p+=pl; while(*p && *p!=':') p++; if(*p!=':') return NULL; p++;
    while(*p==' '||*p=='\t'||*p=='\r'||*p=='\n') p++;
    return p;
}
static char *json_get_string(const char*js,const char*key){
    const char*p=find_value_after_key(js,key); if(!p||*p!='"')return NULL; p++;
    buf_t out={0}; while(*p && *p!='"'){ if(*p=='\\'){ p++; if(*p=='n'){b_ch(&out,'\n');p++;} else if(*p=='r'){b_ch(&out,'\r');p++;} else if(*p=='t'){b_ch(&out,'\t');p++;} else if(*p=='u'){ p+=5; b_ch(&out,'?'); } else { b_ch(&out,*p); if(*p)p++; } } else b_ch(&out,*p++); }
    return out.p;
}
static int json_get_bool(const char*js,const char*key){ const char*p=find_value_after_key(js,key); return p && m_starts(p,"true"); }
static int json_get_int(const char*js,const char*key,int def){
    const char*p=find_value_after_key(js,key); if(!p) return def;
    int v=0, neg=0; if(*p=='-'){ neg=1; p++; }
    while(*p>='0'&&*p<='9'){ v=v*10+(*p-'0'); p++; }
    return neg?-v:v;
}
/* json_get_i64 only used by read_chunk; returns 0 when key absent. */
static I64 json_get_i64(const char*js,const char*key){
    const char*p=find_value_after_key(js,key); if(!p) return 0;
    I64 v=0; int neg=0; if(*p=='-'){ neg=1; p++; }
    while(*p>='0'&&*p<='9'){ v=v*10+(*p-'0'); p++; }
    return neg?-v:v;
}

/* ── sockets / WebSocket ───────────────────────────────────────────────── */
static int send_all(SOCKET s,const char*p,int n){ int off=0; while(off<n){ int r=send(s,p+off,n-off,0); if(r<=0)return 0; off+=r; } return 1; }
static int ws_send_text(SOCKET s,const char*payload,SIZE_T len);
static int recv_all(SOCKET s,char*p,int n){ int off=0; while(off<n){ int r=recv(s,p+off,n-off,0); if(r<=0)return 0; off+=r; } return 1; }
static int socket_readable(SOCKET s,DWORD timeout_ms){ FD_SET_LITE rf; TIMEVAL_LITE tv; rf.fd_count=1; rf.fd_array[0]=s; tv.tv_sec=(long)(timeout_ms/1000); tv.tv_usec=(long)((timeout_ms%1000)*1000); return select(0,&rf,NULL,NULL,&tv); }
static int send_hb(SOCKET s){ return ws_send_text(s,"{\"type\":\"hb\"}",13); }
static SOCKET tcp_connect(void){
    WSADATA wd; if(WSAStartup(0x0202,&wd)!=0)return INVALID_SOCKET;
    ADDRINFOA hints; m_memset(&hints,0,sizeof(hints)); hints.ai_family=AF_UNSPEC; hints.ai_socktype=SOCK_STREAM; hints.ai_protocol=IPPROTO_TCP; ADDRINFOA *res=NULL;
    if(getaddrinfo(g_host,g_port,&hints,&res)!=0 || !res)return INVALID_SOCKET;
    SOCKET s=INVALID_SOCKET; for(ADDRINFOA*a=res;a;a=a->ai_next){ s=socket(a->ai_family,a->ai_socktype,a->ai_protocol); if(s==INVALID_SOCKET)continue; if(connect(s,a->ai_addr,(int)a->ai_addrlen)==0)break; closesocket(s); s=INVALID_SOCKET; }
    freeaddrinfo(res); return s;
}
static int ws_handshake(SOCKET s){
    char req[1024]; buf_t b={0}; b_add(&b,"GET "); b_add(&b,g_path); b_add(&b," HTTP/1.1\r\nHost: "); b_add(&b,g_host); b_ch(&b,':'); b_add(&b,g_port); b_add(&b,"\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Version: 13\r\nSec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\nX-LFM-Password: "); b_add(&b,g_password); b_add(&b,"\r\n\r\n");
    int ok=send_all(s,b.p,(int)b.n); b_free(&b); if(!ok)return 0; int n=0; while(n<(int)sizeof(req)-1){ int r=recv(s,req+n,1,0); if(r<=0)return 0; n+=r; req[n]=0; if(n>=4 && req[n-4]=='\r'&&req[n-3]=='\n'&&req[n-2]=='\r'&&req[n-1]=='\n')break; } return m_strstr(req," 101 ")!=NULL;
}
static int ws_send_text(SOCKET s,const char*payload,SIZE_T len){
    BYTE hdr[14]; int h=0; hdr[h++]=0x81; if(len<126){ hdr[h++]=(BYTE)(0x80|len); } else if(len<65536){ hdr[h++]=0x80|126; hdr[h++]=(BYTE)(len>>8); hdr[h++]=(BYTE)len; } else { hdr[h++]=0x80|127; for(int i=7;i>=0;i--) hdr[h++]=(BYTE)(len>>(i*8)); }
    DWORD mk=rnd(); BYTE m[4]={(BYTE)mk,(BYTE)(mk>>8),(BYTE)(mk>>16),(BYTE)(mk>>24)}; if(!send_all(s,(char*)hdr,h))return 0; if(!send_all(s,(char*)m,4))return 0;
    char *tmp=(char*)xalloc(len?len:1); if(!tmp)return 0; for(SIZE_T i=0;i<len;i++) tmp[i]=payload[i]^m[i&3]; int ok=send_all(s,tmp,(int)len); xfree(tmp); return ok;
}
static char *ws_recv_text(SOCKET s,SIZE_T*outn){
    BYTE h[2]; if(!recv_all(s,(char*)h,2))return NULL; BYTE op=h[0]&15; U64 len=h[1]&127; int masked=(h[1]&0x80)!=0; if(len==126){ BYTE e[2]; if(!recv_all(s,(char*)e,2))return NULL; len=((U64)e[0]<<8)|e[1]; } else if(len==127){ BYTE e[8]; if(!recv_all(s,(char*)e,8))return NULL; len=0; for(int i=0;i<8;i++)len=(len<<8)|e[i]; }
    BYTE mask[4]={0,0,0,0}; if(masked && !recv_all(s,(char*)mask,4))return NULL; if(len>MFS_MAX_FRAME)return NULL; char*p=(char*)xalloc((SIZE_T)len+1); if(!p)return NULL; if(!recv_all(s,p,(int)len)){xfree(p);return NULL;} if(masked) for(U64 i=0;i<len;i++)p[i]^=mask[i&3]; p[len]=0; if(op==8){xfree(p);return NULL;} if(outn)*outn=(SIZE_T)len; return p;
}

/* ── response helpers + ops ────────────────────────────────────────────── */
static void resp_ok_prefix(buf_t*b,const char*id){ b_add(b,"{\"type\":\"resp\",\"id\":"); json_str(b,id); b_add(b,",\"ok\":true,\"result\":"); }
static void resp_err(buf_t*b,const char*id,const char*err){ b_add(b,"{\"type\":\"resp\",\"id\":"); json_str(b,id); b_add(b,",\"ok\":false,\"err\":"); json_str(b,err); b_ch(b,'}'); }
static void send_resp(SOCKET s,buf_t*b){ if(b->p) ws_send_text(s,b->p,b->n); }

static void op_drives(buf_t*out,const char*id){
    resp_ok_prefix(out,id); b_add(out,"{\"drives\":["); DWORD mask=GetLogicalDrives(); int first=1;
    for(int i=0;i<26;i++){ if(!(mask&(1u<<i)))continue; char root[4]; root[0]=(char)('A'+i); root[1]=':'; root[2]='\\'; root[3]=0; if(!first)b_ch(out,','); first=0; b_add(out,"{\"label\":"); json_str(out,root); b_add(out,",\"path\":"); json_str(out,root); b_ch(out,'}'); }
    if(first){ b_add(out,"{\"label\":\"Root\",\"path\":"); json_str(out,g_root); b_ch(out,'}'); }
    b_add(out,"]}}");
}
static void op_list(buf_t*out,const char*id,const char*path){
    char abs[MAX_PATH_LITE]; if(!allowed_path(path,abs,sizeof(abs))){resp_err(out,id,"path not allowed");return;} char pat[MAX_PATH_LITE+4]; m_copy(pat,abs,sizeof(pat)); SIZE_T l=m_len(pat); if(l && pat[l-1]!='\\'&&pat[l-1]!='/'){ pat[l++]='\\'; pat[l]=0; } if(l+2<sizeof(pat)){ pat[l++]='*'; pat[l]=0; }
    WIN32_FIND_DATAA fd; HANDLE h=FindFirstFileA(pat,&fd); if(h==INVALID_HANDLE_VALUE){resp_err(out,id,"cannot list directory");return;} resp_ok_prefix(out,id); b_add(out,"{\"path\":"); json_str(out,abs); b_add(out,",\"entries\":["); int first=1; do{ if(m_eq(fd.cFileName,".")||m_eq(fd.cFileName,".."))continue; if(!first)b_ch(out,','); first=0; b_add(out,"{\"name\":"); json_str(out,fd.cFileName); b_add(out,",\"is_dir\":"); b_add(out,(fd.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)?"true":"false"); b_add(out,",\"size\":"); b_u64(out,fsize_hi_low(fd.nFileSizeHigh,fd.nFileSizeLow)); b_add(out,",\"mod_time\":"); b_i64(out,filetime_unix(fd.ftLastWriteTime)); b_ch(out,'}'); }while(FindNextFileA(h,&fd)); FindClose(h); b_add(out,"]}}");
}
static void op_read_common(buf_t*out,const char*id,const char*path,int preview,int maxb){
    char abs[MAX_PATH_LITE]; if(!allowed_path(path,abs,sizeof(abs))){resp_err(out,id,"path not allowed");return;} WIN32_FILE_ATTRIBUTE_DATA fad; if(!GetFileAttributesExA(abs,0,&fad)){resp_err(out,id,"stat failed");return;} if(fad.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY){resp_err(out,id,"is a directory");return;} U64 sz=fsize_hi_low(fad.nFileSizeHigh,fad.nFileSizeLow); if(sz>MFS_MAX_FILE) sz=MFS_MAX_FILE; if(preview){ if(maxb<=0||maxb>262144)maxb=65536; if(sz>(U64)maxb)sz=(U64)maxb; }
    HANDLE f=CreateFileA(abs,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,0,NULL); if(f==INVALID_HANDLE_VALUE){resp_err(out,id,"open failed");return;} BYTE*buf=(BYTE*)xalloc((SIZE_T)sz+1); if(!buf){CloseHandle(f);resp_err(out,id,"memory");return;} DWORD rd=0; ReadFile(f,buf,(DWORD)sz,&rd,NULL); CloseHandle(f); buf[rd]=0;
    resp_ok_prefix(out,id); if(preview){ b_add(out,"{\"path\":"); json_str(out,abs); b_add(out,",\"content\":"); json_str(out,(char*)buf); b_add(out,",\"truncated\":"); b_add(out,(fsize_hi_low(fad.nFileSizeHigh,fad.nFileSizeLow)>(U64)rd)?"true":"false"); b_add(out,"}}"); }
    else { SIZE_T e=0; char*b64=b64enc(buf,rd,&e); b_add(out,"{\"path\":"); json_str(out,abs); b_add(out,",\"data_b64\":"); json_str(out,b64?b64:""); b_add(out,",\"size\":"); b_u64(out,fsize_hi_low(fad.nFileSizeHigh,fad.nFileSizeLow)); b_add(out,",\"mod_time\":"); b_i64(out,filetime_unix(fad.ftLastWriteTime)); b_add(out,"}}"); xfree(b64); }
    xfree(buf);
}

/* ── op_read_chunk: streaming companion to op_read.
 *
 * Mirrors agent_main.go opReadChunk: reads up to `length` bytes from `offset`
 * and returns them base64-encoded with an `eof` flag. The server-side
 * /download path loops over these so the Lite agent now participates in
 * unbounded file downloads without the previous 8 MiB single-frame ceiling.
 * Memory pressure stays bounded by MFS_MAX_CHUNK regardless of file size.
 */
static void op_read_chunk(buf_t*out,const char*id,const char*path,I64 offset,I64 length){
    char abs[MAX_PATH_LITE]; if(!allowed_path(path,abs,sizeof(abs))){resp_err(out,id,"path not allowed");return;}
    WIN32_FILE_ATTRIBUTE_DATA fad; if(!GetFileAttributesExA(abs,0,&fad)){resp_err(out,id,"stat failed");return;}
    if(fad.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY){resp_err(out,id,"is a directory");return;}

    if(offset<0) offset=0;
    if(length<=0) length=(I64)MFS_DEFAULT_CHUNK;
    if((U64)length>MFS_MAX_CHUNK) length=(I64)MFS_MAX_CHUNK;

    U64 size=fsize_hi_low(fad.nFileSizeHigh,fad.nFileSizeLow);
    HANDLE f=CreateFileA(abs,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,0,NULL);
    if(f==INVALID_HANDLE_VALUE){resp_err(out,id,"open failed");return;}

    if(offset>0){
        LONG lo=(LONG)(offset & 0xFFFFFFFFu);
        LONG hi=(LONG)((U64)offset>>32);
        DWORD rc=SetFilePointer(f,lo,&hi,FILE_BEGIN);
        if(rc==(DWORD)-1){ CloseHandle(f); resp_err(out,id,"seek failed"); return; }
    }

    BYTE*buf=(BYTE*)xalloc((SIZE_T)length+1);
    if(!buf){ CloseHandle(f); resp_err(out,id,"memory"); return; }
    DWORD rd=0; ReadFile(f,buf,(DWORD)length,&rd,NULL); CloseHandle(f);

    int eof=0;
    if((U64)offset+(U64)rd >= size) eof=1;
    if(rd==0) eof=1;

    SIZE_T e=0; char*b64=b64enc(buf,rd,&e);
    resp_ok_prefix(out,id);
    b_add(out,"{\"path\":"); json_str(out,abs);
    b_add(out,",\"data_b64\":"); json_str(out,b64?b64:"");
    b_add(out,",\"offset\":"); b_i64(out,offset);
    b_add(out,",\"bytes\":"); b_u64(out,(U64)rd);
    b_add(out,",\"size\":"); b_u64(out,size);
    b_add(out,",\"mod_time\":"); b_i64(out,filetime_unix(fad.ftLastWriteTime));
    b_add(out,",\"eof\":"); b_add(out,eof?"true":"false");
    b_add(out,"}}");
    xfree(b64); xfree(buf);
}

static void make_dirs_simple(const char*p){ char tmp[MAX_PATH_LITE]; m_copy(tmp,p,sizeof(tmp)); for(SIZE_T i=3;tmp[i];i++){ if(tmp[i]=='/'||tmp[i]=='\\'){ char c=tmp[i]; tmp[i]=0; CreateDirectoryA(tmp,NULL); tmp[i]=c; } } }
static void op_write(buf_t*out,const char*id,const char*path,const char*b64,int mkdirs){ char abs[MAX_PATH_LITE]; if(!allowed_path(path,abs,sizeof(abs))){resp_err(out,id,"path not allowed");return;} if(mkdirs)make_dirs_simple(abs); SIZE_T n=0; BYTE*data=b64dec(b64?b64:"",&n); if(!data){resp_err(out,id,"decode failed");return;} HANDLE f=CreateFileA(abs,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL); if(f==INVALID_HANDLE_VALUE){xfree(data);resp_err(out,id,"open failed");return;} DWORD wr=0; BOOL ok=WriteFile(f,data,(DWORD)n,&wr,NULL); CloseHandle(f); xfree(data); if(!ok){resp_err(out,id,"write failed");return;} resp_ok_prefix(out,id); b_add(out,"{\"path\":"); json_str(out,abs); b_add(out,",\"size\":"); b_u64(out,wr); b_add(out,"}}"); }
static void op_mkdir(buf_t*out,const char*id,const char*path,int parents){ char abs[MAX_PATH_LITE]; if(!allowed_path(path,abs,sizeof(abs))){resp_err(out,id,"path not allowed");return;} if(parents)make_dirs_simple(abs); if(!CreateDirectoryA(abs,NULL) && GetLastError()!=183){resp_err(out,id,"mkdir failed");return;} resp_ok_prefix(out,id); b_add(out,"{\"path\":"); json_str(out,abs); b_add(out,"}}"); }
static void del_tree(const char*p){ WIN32_FILE_ATTRIBUTE_DATA fad; if(!GetFileAttributesExA(p,0,&fad))return; if(!(fad.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)){ DeleteFileA(p); return; } char pat[MAX_PATH_LITE+4]; m_copy(pat,p,sizeof(pat)); SIZE_T l=m_len(pat); if(l&&pat[l-1]!='\\'){pat[l++]='\\';pat[l]=0;} if(l+2<sizeof(pat)){pat[l++]='*';pat[l]=0;} WIN32_FIND_DATAA fd; HANDLE h=FindFirstFileA(pat,&fd); if(h!=INVALID_HANDLE_VALUE){ do{ if(m_eq(fd.cFileName,".")||m_eq(fd.cFileName,".."))continue; char child[MAX_PATH_LITE]; m_copy(child,p,sizeof(child)); SIZE_T cl=m_len(child); if(cl&&child[cl-1]!='\\'){child[cl++]='\\';child[cl]=0;} m_copy(child+cl,fd.cFileName,sizeof(child)-cl); del_tree(child); }while(FindNextFileA(h,&fd)); FindClose(h); } RemoveDirectoryA(p); }
static void op_rm(buf_t*out,const char*id,const char*path,int rec){ char abs[MAX_PATH_LITE]; if(!allowed_path(path,abs,sizeof(abs))){resp_err(out,id,"path not allowed");return;} if(rec)del_tree(abs); else { WIN32_FILE_ATTRIBUTE_DATA fad; if(GetFileAttributesExA(abs,0,&fad) && (fad.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)) RemoveDirectoryA(abs); else DeleteFileA(abs); } resp_ok_prefix(out,id); b_add(out,"{\"path\":"); json_str(out,abs); b_add(out,"}}"); }
static void op_rename(buf_t*out,const char*id,const char*p1,const char*p2){ char a[MAX_PATH_LITE],b[MAX_PATH_LITE]; if(!allowed_path(p1,a,sizeof(a))||!allowed_path(p2,b,sizeof(b))){resp_err(out,id,"path not allowed");return;} if(!MoveFileExA(a,b,MOVEFILE_REPLACE_EXISTING)){resp_err(out,id,"rename failed");return;} resp_ok_prefix(out,id); b_add(out,"{\"path\":"); json_str(out,b); b_add(out,"}}"); }

/* ── Agent Control ──────────────────────────────────────────────────────
 *
 * Mirrors the Full agent's opAgentClose / opAgentRelaunch / opAgentUninstall
 * ops with the silent-uninstall fix already applied (no `start ""` wrapper,
 * canonical `(goto) 2>nul & del "%~f0"` self-delete idiom).
 */

static const char RUN_KEY_PATH[] = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run";
static const char RUN_KEY_NAME[] = "MultiFS Agent";

static int run_key_delete(void){
    HKEY k;
    if(RegOpenKeyExA(HKEY_CURRENT_USER, RUN_KEY_PATH, 0, KEY_SET_VALUE, &k) != 0) return 0;
    LONG rc = RegDeleteValueA(k, RUN_KEY_NAME);
    RegCloseKey(k);
    return rc == 0;
}

static void op_agent_close(buf_t*out,const char*id){
    resp_ok_prefix(out,id); b_add(out,"{\"closing\":true}}"); g_exit_after_resp=1;
}

static void op_agent_relaunch(buf_t*out,const char*id){
    char exe[MAX_PATH_LITE];
    if(!GetModuleFileNameA(NULL,exe,(DWORD)sizeof(exe))){ resp_err(out,id,"cannot locate executable"); return; }
    /* Build a hidden relaunch with the same configuration we were started with. */
    buf_t cmd={0};
    cmd_quote(&cmd,exe);
    b_add(&cmd," --server ");   cmd_quote(&cmd,g_server);
    b_add(&cmd," --password "); cmd_quote(&cmd,g_password);
    b_add(&cmd," --key ");      cmd_quote(&cmd,g_key);
    b_add(&cmd," --name ");     cmd_quote(&cmd,g_name);
    b_add(&cmd," --root ");     cmd_quote(&cmd,g_root);
    if(g_quiet) b_add(&cmd," --quiet");
    b_add(&cmd," --retry ");    b_u64(&cmd,(U64)(g_retry_ms/1000u));
    WinExec(cmd.p,SW_HIDE);
    b_free(&cmd);
    resp_ok_prefix(out,id); b_add(out,"{\"relaunching\":true}}"); g_exit_after_resp=1;
}

static void op_agent_uninstall(buf_t*out,const char*id){
    /* Best-effort cleanup of persistence before we schedule self-delete. */
    run_key_delete();
    char idfile[MAX_PATH_LITE]; DWORD g=GetEnvironmentVariableA("USERPROFILE",idfile,(DWORD)sizeof(idfile));
    if(g>0 && g<sizeof(idfile)){
        SIZE_T l=m_len(idfile);
        if(l+24<sizeof(idfile)){ m_copy(idfile+l,"\\.multifs_agent_id",sizeof(idfile)-l); DeleteFileA(idfile); }
    }

    char exe[MAX_PATH_LITE]; if(!GetModuleFileNameA(NULL,exe,(DWORD)sizeof(exe))){ resp_err(out,id,"cannot locate executable"); return; }
    char script[MAX_PATH_LITE]; if(!append_suffix(script,sizeof(script),exe,".uninstall.bat")){ resp_err(out,id,"path too long"); return; }

    /* Same script idiom as uninstall_windows.go uninstallSelf — del the EXE,
     * then `(goto) 2>nul & del "%~f0"` so cmd.exe releases the script
     * handle before the file vanishes. No `start "" ...` wrapper anywhere:
     * `start` always spawns a fresh visible console window that ignores the
     * parent's HideWindow flag. */
    buf_t sc={0};
    b_add(&sc,"@echo off\r\n");
    b_add(&sc,":wait\r\nping -n 2 127.0.0.1 >nul\r\n");
    b_add(&sc,"del /F /Q "); cmd_quote(&sc,exe); b_add(&sc," >nul 2>&1\r\n");
    b_add(&sc,"if exist "); cmd_quote(&sc,exe); b_add(&sc," goto wait\r\n");
    b_add(&sc,"(goto) 2>nul & del /F /Q \"%~f0\"\r\n");
    if(!write_file_all(script,(const BYTE*)sc.p,sc.n)){ b_free(&sc); resp_err(out,id,"failed to write uninstall script"); return; }
    b_free(&sc);

    /* Launch the script under a hidden cmd.exe via WinExec(SW_HIDE).
     * WinExec is the smallest hidden-launch primitive we have; the visible
     * console is suppressed by SW_HIDE. */
    buf_t cmd={0};
    b_add(&cmd,"cmd.exe /c "); cmd_quote(&cmd,script);
    WinExec(cmd.p,SW_HIDE);
    b_free(&cmd);

    resp_ok_prefix(out,id); b_add(out,"{\"uninstalling\":true}}"); g_exit_after_resp=1;
}

/* ── Startup Persistence ───────────────────────────────────────────────
 *
 * Install / uninstall the autostart Run-key entry for this agent. These
 * never touch the binary itself — they only toggle the registry value
 * that makes Windows launch the agent on user logon.
 */
static void op_agent_startup_install(buf_t*out,const char*id){
    char exe[MAX_PATH_LITE];
    if(!GetModuleFileNameA(NULL,exe,(DWORD)sizeof(exe))){ resp_err(out,id,"cannot locate executable"); return; }
    HKEY k;
    if(RegOpenKeyExA(HKEY_CURRENT_USER,RUN_KEY_PATH,0,KEY_SET_VALUE,&k)!=0){ resp_err(out,id,"could not open Run key"); return; }
    DWORD el=(DWORD)(m_len(exe)+1);
    LONG rc=RegSetValueExA(k,RUN_KEY_NAME,0,REG_SZ,(const BYTE*)exe,el);
    RegCloseKey(k);
    if(rc!=0){ resp_err(out,id,"could not write Run value"); return; }
    /* `location` (informational, used by the Full agent) is omitted here —
     * the JS client only reads `installed` + `path`, and emitting the
     * backslash-laden registry path through json_str would either bloat
     * the function or risk a JSON escape bug. */
    resp_ok_prefix(out,id);
    b_add(out,"{\"installed\":true,\"path\":"); json_str(out,exe); b_add(out,"}}");
}

static void op_agent_startup_uninstall(buf_t*out,const char*id){
    int removed=run_key_delete();
    resp_ok_prefix(out,id);
    b_add(out,"{\"installed\":false,\"removed\":");
    b_add(out,removed?"true":"false");
    b_add(out,"}}");
}

static void op_agent_startup_status(buf_t*out,const char*id){
    HKEY k; char val[MAX_PATH_LITE]; DWORD vlen=(DWORD)sizeof(val); int installed=0;
    val[0]=0;
    if(RegOpenKeyExA(HKEY_CURRENT_USER,RUN_KEY_PATH,0,KEY_QUERY_VALUE,&k)==0){
        if(RegQueryValueExA(k,RUN_KEY_NAME,NULL,NULL,(BYTE*)val,&vlen)==0){
            if(vlen>0 && vlen<=sizeof(val)) val[vlen-1]=0; /* ensure NUL term */
            installed=1;
        }
        RegCloseKey(k);
    }
    resp_ok_prefix(out,id);
    b_add(out,"{\"installed\":"); b_add(out,installed?"true":"false");
    b_add(out,",\"path\":"); json_str(out,installed?val:"");
    b_add(out,"}}");
}

/* ── Shell ──────────────────────────────────────────────────────────────
 *
 * Run a single cmd.exe /c invocation. Output capture goes through a temp
 * file because CreateProcess + pipe stitching is much more code than just
 * redirecting stdout/stderr to a file and reading it back. The output is
 * capped at 1 MiB so a runaway command can't blow up agent memory.
 *
 * The process is launched hidden with CREATE_NO_WINDOW; the temp file is
 * deleted on completion (success or failure).
 */
static void op_shell(buf_t*out,const char*id,const char*command){
    if(!command||!command[0]){ resp_err(out,id,"missing command"); return; }

    /* Build %TEMP%\multifs_lite_shell_<pid>_<tick>.tmp */
    char tmpdir[MAX_PATH_LITE]; DWORD tlen=GetEnvironmentVariableA("TEMP",tmpdir,(DWORD)sizeof(tmpdir));
    if(tlen==0||tlen>=sizeof(tmpdir)){ tlen=GetEnvironmentVariableA("TMP",tmpdir,(DWORD)sizeof(tmpdir)); }
    if(tlen==0||tlen>=sizeof(tmpdir)){ m_copy(tmpdir,".",sizeof(tmpdir)); tlen=1; }
    char tmpfile[MAX_PATH_LITE];
    if(tlen+48>=sizeof(tmpfile)){ resp_err(out,id,"temp path too long"); return; }
    m_copy(tmpfile,tmpdir,sizeof(tmpfile));
    SIZE_T tl=m_len(tmpfile);
    if(tl && tmpfile[tl-1]!='\\' && tmpfile[tl-1]!='/'){ tmpfile[tl++]='\\'; tmpfile[tl]=0; }
    {
        buf_t fb={0};
        b_add(&fb,"multifs_lite_shell_"); b_hex8(&fb,GetCurrentProcessId());
        b_ch(&fb,'_'); b_hex8(&fb,GetTickCount());
        b_add(&fb,".tmp");
        m_copy(tmpfile+tl,fb.p,sizeof(tmpfile)-tl);
        b_free(&fb);
    }

    /* Build: cmd.exe /c (command) > "tmpfile" 2>&1
     * The outer parentheses keep operators within the user command from
     * confusing the redirection that follows. */
    buf_t cmd={0};
    b_add(&cmd,"cmd.exe /c ("); b_add(&cmd,command); b_add(&cmd,") > \"");
    b_add(&cmd,tmpfile); b_add(&cmd,"\" 2>&1");

    STARTUPINFOA si; m_memset(&si,0,sizeof(si));
    si.cb=(DWORD)sizeof(si);
    si.dwFlags=STARTF_USESHOWWINDOW;
    si.wShowWindow=SW_HIDE;
    PROCESS_INFORMATION pi; m_memset(&pi,0,sizeof(pi));

    /* Mutable command line buffer (CreateProcessA can modify it). */
    char *cmdline=(char*)xalloc(cmd.n+1);
    if(!cmdline){ b_free(&cmd); resp_err(out,id,"memory"); return; }
    m_memcpy(cmdline,cmd.p,cmd.n); cmdline[cmd.n]=0;
    b_free(&cmd);

    BOOL ok=CreateProcessA(NULL,cmdline,NULL,NULL,FALSE,CREATE_NO_WINDOW,NULL,NULL,&si,&pi);
    xfree(cmdline);
    if(!ok){ DeleteFileA(tmpfile); resp_err(out,id,"failed to start shell"); return; }

    DWORD wait_rc=WaitForSingleObject(pi.hProcess,30000u);
    DWORD exit_code=0;
    if(wait_rc==WAIT_TIMEOUT){
        /* Best-effort: leave it; we still return what we have so the user
         * sees partial output. Memory leak is unavoidable without
         * TerminateProcess which costs another import. */
        exit_code=0xFFFFFFFFu;
    } else {
        GetExitCodeProcess(pi.hProcess,&exit_code);
    }
    CloseHandle(pi.hProcess); CloseHandle(pi.hThread);

    /* Read the temp file (cap at 1 MiB so a runaway command can't OOM us). */
    char *output=NULL; DWORD rd=0;
    HANDLE f=CreateFileA(tmpfile,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,0,NULL);
    if(f!=INVALID_HANDLE_VALUE){
        DWORD hi=0; DWORD lo=GetFileSize(f,&hi);
        DWORD cap=lo;
        if(hi>0 || cap>(1u<<20)) cap=(1u<<20);
        output=(char*)xalloc((SIZE_T)cap+1);
        if(output){
            ReadFile(f,output,cap,&rd,NULL);
            output[rd]=0;
        }
        CloseHandle(f);
    }
    DeleteFileA(tmpfile);

    resp_ok_prefix(out,id);
    b_add(out,"{\"output\":"); json_str(out,output?output:"");
    if(exit_code!=0){
        b_add(out,",\"error\":\"exit ");
        b_u64(out,(U64)exit_code);
        b_ch(out,'"');
    }
    b_add(out,"}}");
    xfree(output);
}

static void op_self_update(buf_t*out,const char*id,const char*b64,const char*expect_sha){
    SIZE_T n=0; BYTE*data=b64dec(b64?b64:"",&n); if(!data||n==0){ xfree(data); resp_err(out,id,"invalid update payload"); return; }
    if(n>MFS_MAX_UPDATE){ xfree(data); resp_err(out,id,"update payload too large for Lite agent"); return; }
    char actual[65]; if(!sha256_hex_win(data,n,actual)){ xfree(data); resp_err(out,id,"sha256 unavailable"); return; }
    if(expect_sha&&expect_sha[0]&&!hex_eq_ci(actual,expect_sha)){ xfree(data); resp_err(out,id,"sha256 mismatch"); return; }
    char exe[MAX_PATH_LITE]; if(!GetModuleFileNameA(NULL,exe,(DWORD)sizeof(exe))){ xfree(data); resp_err(out,id,"cannot locate executable"); return; }
    char staged[MAX_PATH_LITE]; char script[MAX_PATH_LITE]; if(!append_suffix(staged,sizeof(staged),exe,".new")||!append_suffix(script,sizeof(script),exe,".update.cmd")){ xfree(data); resp_err(out,id,"path too long"); return; }
    if(!write_file_all(staged,data,n)){ xfree(data); resp_err(out,id,"failed to stage update"); return; }
    xfree(data);
    buf_t sc={0}; b_add(&sc,"@echo off\r\n"); b_add(&sc,"ping 127.0.0.1 -n 2 >nul\r\n"); b_add(&sc,"copy /Y "); cmd_quote(&sc,staged); b_ch(&sc,' '); cmd_quote(&sc,exe); b_add(&sc," >nul\r\n"); b_add(&sc,"if errorlevel 1 exit /b 1\r\n"); b_add(&sc,"del /Q "); cmd_quote(&sc,staged); b_add(&sc," >nul 2>nul\r\n"); b_add(&sc,"start \"\" "); cmd_quote(&sc,exe); b_add(&sc," --server "); cmd_quote(&sc,g_server); b_add(&sc," --password "); cmd_quote(&sc,g_password); b_add(&sc," --key "); cmd_quote(&sc,g_key); b_add(&sc," --name "); cmd_quote(&sc,g_name); b_add(&sc," --root "); cmd_quote(&sc,g_root); if(g_quiet)b_add(&sc," --quiet"); b_add(&sc," --retry "); b_u64(&sc,(U64)(g_retry_ms/1000u)); b_add(&sc,"\r\ndel /Q \"%~f0\" >nul 2>nul\r\n");
    if(!write_file_all(script,(const BYTE*)sc.p,sc.n)){ b_free(&sc); resp_err(out,id,"failed to write update script"); return; } b_free(&sc);
    buf_t cmd={0}; b_add(&cmd,"cmd.exe /c start \"\" /min "); cmd_quote(&cmd,script); WinExec(cmd.p,SW_HIDE); b_free(&cmd);
    resp_ok_prefix(out,id); b_add(out,"{\"sha256\":"); json_str(out,actual); b_add(out,",\"restart\":true}}"); g_exit_after_resp=1;
}


static void handle_req(SOCKET s,const char*js){
    char*id=json_get_string(js,"id");
    char*op=json_get_string(js,"op");
    char*path=json_get_string(js,"path");
    char*path2=json_get_string(js,"path2");
    char*data=json_get_string(js,"data_b64");
    char*sha=json_get_string(js,"sha256");
    char*command=json_get_string(js,"command"); /* shell op args.command */
    int maxb=json_get_int(js,"max_bytes",0);
    int rec=json_get_bool(js,"recursive");
    int mkdirs=json_get_bool(js,"mkdirs");
    I64 offset=json_get_i64(js,"offset");
    I64 length=json_get_i64(js,"length");
    buf_t out={0};
    if(!id)id="";
    if(!op)                                    resp_err(&out,id,"missing op");
    else if(m_eq(op,"drives"))                 op_drives(&out,id);
    else if(m_eq(op,"list"))                   op_list(&out,id,path);
    else if(m_eq(op,"read"))                   op_read_common(&out,id,path,0,0);
    else if(m_eq(op,"read_chunk"))             op_read_chunk(&out,id,path,offset,length);
    else if(m_eq(op,"preview"))                op_read_common(&out,id,path,1,maxb);
    else if(m_eq(op,"write"))                  op_write(&out,id,path,data,mkdirs);
    else if(m_eq(op,"mkdir"))                  op_mkdir(&out,id,path,mkdirs);
    else if(m_eq(op,"rm"))                     op_rm(&out,id,path,rec);
    else if(m_eq(op,"rename"))                 op_rename(&out,id,path,path2);
    else if(m_eq(op,"shell"))                  op_shell(&out,id,command);
    else if(m_eq(op,"agent_close"))            op_agent_close(&out,id);
    else if(m_eq(op,"agent_relaunch"))         op_agent_relaunch(&out,id);
    else if(m_eq(op,"agent_uninstall"))        op_agent_uninstall(&out,id);
    else if(m_eq(op,"agent_startup_install"))  op_agent_startup_install(&out,id);
    else if(m_eq(op,"agent_startup_uninstall"))op_agent_startup_uninstall(&out,id);
    else if(m_eq(op,"agent_startup_status"))   op_agent_startup_status(&out,id);
    else if(m_eq(op,"self_update"))            op_self_update(&out,id,data,sha);
    else                                       resp_err(&out,id,"unsupported feature in Lite agent");
    send_resp(s,&out); b_free(&out);
    if(id&&id[0])xfree(id);
    xfree(op); xfree(path); xfree(path2); xfree(data); xfree(sha); xfree(command);
    if(g_exit_after_resp){ Sleep(350); ExitProcess(0); }
}

static void add_roots_json(buf_t*b){ DWORD mask=GetLogicalDrives(); int first=1; for(int i=0;i<26;i++){ if(!(mask&(1u<<i)))continue; char root[4]; root[0]=(char)('A'+i); root[1]=':'; root[2]='\\'; root[3]=0; if(!first)b_ch(b,','); first=0; json_str(b,root); } if(first)json_str(b,g_root); }

/* Hello message: capabilities cover every op the agent really implements.
 * files_read covers read + read_chunk + preview + list + drives;
 * files_write covers write + mkdir + rm + rename;
 * agent_control covers close, relaunch, uninstall, and startup_*;
 * shell covers the cmd.exe op; remote_update covers self_update. */
static void send_hello(SOCKET s){
    char host[128]=""; DWORD hn=sizeof(host); GetComputerNameA(host,&hn);
    char user[128]=""; GetEnvironmentVariableA("USERNAME",user,sizeof(user));
    buf_t b={0};
    b_add(&b,"{\"type\":\"hello\",\"key\":"); json_str(&b,g_key);
    b_add(&b,",\"name\":"); json_str(&b,g_name);
    b_add(&b,",\"hostname\":"); json_str(&b,host[0]?host:g_name);
    b_add(&b,",\"os\":\"windows\",\"arch\":\"amd64\",\"user\":"); json_str(&b,user);
    b_add(&b,",\"roots\":["); add_roots_json(&b);
    b_add(&b,"],\"version\":\"2.5.0\",\"build\":\"lite-native-c\",");
    b_add(&b,"\"capabilities\":[\"files_read\",\"files_write\",\"remote_update\",\"agent_control\",\"shell\"]}");
    ws_send_text(s,b.p,b.n); b_free(&b);
}

void mainCRTStartup(void){
    g_heap=GetProcessHeap(); g_rng^=GetTickCount()^GetCurrentProcessId(); init_config();
    out("MultiFS Lite v2.5.0");
    for(;;){
        SOCKET s=tcp_connect();
        if(s==INVALID_SOCKET){ out("connect failed"); }
        else if(!ws_handshake(s)){ out("handshake failed"); closesocket(s); }
        else {
            send_hello(s);
            DWORD last_hb=GetTickCount();
            for(;;){
                DWORD now=GetTickCount();
                if((DWORD)(now-last_hb)>=60000u){ if(!send_hb(s))break; last_hb=now; }
                int ready=socket_readable(s,2000);
                if(ready<0)break;
                if(ready==0)continue;
                SIZE_T n=0; char*msg=ws_recv_text(s,&n); if(!msg)break;
                /* hb_srv envelopes from the server keep our connection alive but
                 * don't require a reply. Only react to genuine req payloads. */
                if(m_strstr(msg,"\"op\"")) handle_req(s,msg);
                xfree(msg);
            }
            shutdown(s,SD_BOTH); closesocket(s);
        }
        if(g_once)break; Sleep(g_retry_ms);
    }
    WSACleanup(); ExitProcess(0);
}
