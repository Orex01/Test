@echo off
echo This must be run as Administrator on the SERVER computer.
echo It allows the web server TCP ports and the LAN discovery UDP port.
echo.
netsh advfirewall firewall add rule name="MultiFS TCP 8080-8105" dir=in action=allow protocol=TCP localport=8080-8105
netsh advfirewall firewall add rule name="MultiFS UDP Discovery 45808" dir=in action=allow protocol=UDP localport=45808
pause
