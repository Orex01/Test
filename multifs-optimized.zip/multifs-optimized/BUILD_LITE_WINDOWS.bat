@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo Building MultiFS native Lite Windows agent...
echo.
call tools\build_native_lite_windows.bat
set ERR=%ERRORLEVEL%
echo.
if not "%ERR%"=="0" (
  echo Lite build FAILED with exit code %ERR%.
  echo.
  echo Requirements:
  echo   - LLVM/Clang for Windows must be installed.
  echo   - clang.exe and lld-link.exe must be available in PATH.
  echo.
  echo If you only need to run Lite, use the prebuilt file in build\ or dist\.
  pause
  exit /b %ERR%
)
echo Lite build completed successfully.
echo Output:
echo   build\multifs-agent-lite-native.exe
echo   build\multifs-agent-lite-native-stripped.exe
echo   dist\multifs-agent-lite-native.exe
echo   dist\multifs-agent-lite-native-stripped.exe
pause
exit /b 0
