//go:build !agent
// +build !agent

package main

import (
	"encoding/json"
	"fmt"
	"net"
	"net/http"
	"net/url"
	"os"
	"runtime"
	"sort"
	"strings"
	"time"

	"multifs-advanced/internal/config"
	"multifs-advanced/internal/wsmini"
)

type serverConfigFile struct {
	AgentServerURL string `json:"agent_server_url"`
	Password       string `json:"password"`
}

type agentConnectionInfo struct {
	AgentServerURL string
	Candidates     []string
	LANIPs         []string
	Port           string
	ConfigJSON     string
	LaunchCommand  string
}

func (s *server) loadServerConfig() {
	if strings.TrimSpace(s.configPath) == "" {
		return
	}
	b, err := os.ReadFile(s.configPath)
	if err != nil {
		return
	}
	var cfg serverConfigFile
	if err := json.Unmarshal(b, &cfg); err != nil {
		return
	}
	s.configMu.Lock()
	s.agentServerURLOverride = strings.TrimSpace(cfg.AgentServerURL)
	s.sharedPassword = strings.TrimSpace(cfg.Password)
	s.configMu.Unlock()
}

func (s *server) saveServerConfig() error {
	if strings.TrimSpace(s.configPath) == "" {
		return nil
	}
	s.configMu.RLock()
	cfg := serverConfigFile{
		AgentServerURL: strings.TrimSpace(s.agentServerURLOverride),
		Password:       strings.TrimSpace(s.sharedPassword),
	}
	s.configMu.RUnlock()
	b, err := json.MarshalIndent(cfg, "", "  ")
	if err != nil {
		return err
	}
	tmp := s.configPath + ".tmp"
	if err := os.WriteFile(tmp, b, 0o600); err != nil {
		return err
	}
	return os.Rename(tmp, s.configPath)
}

func (s *server) authPassword() string {
	for _, key := range []string{"MULTIFS_SERVER_PASSWORD", "MULTIFS_PASSWORD"} {
		if v := strings.TrimSpace(os.Getenv(key)); v != "" {
			return v
		}
	}
	s.configMu.RLock()
	p := strings.TrimSpace(s.sharedPassword)
	s.configMu.RUnlock()
	if p != "" {
		return p
	}
	return config.SharedPassword
}

func (s *server) setListenAddress(addr string) {
	s.configMu.Lock()
	s.listenAddr = strings.TrimSpace(addr)
	s.configMu.Unlock()
}

func (s *server) getListenAddress() string {
	s.configMu.RLock()
	defer s.configMu.RUnlock()
	return s.listenAddr
}

func (s *server) getAgentServerOverride() string {
	s.configMu.RLock()
	defer s.configMu.RUnlock()
	return strings.TrimSpace(s.agentServerURLOverride)
}

func (s *server) setAgentServerOverride(raw string, r *http.Request) (string, error) {
	port := s.serverPort(r)
	raw = strings.TrimSpace(raw)
	normalized := ""
	var err error
	if raw != "" {
		normalized, err = normalizeAgentServerURL(raw, port)
		if err != nil {
			return "", err
		}
	}
	s.configMu.Lock()
	s.agentServerURLOverride = normalized
	s.configMu.Unlock()
	if err := s.saveServerConfig(); err != nil {
		return "", err
	}
	return normalized, nil
}

func (s *server) serverPort(r *http.Request) string {
	addr := s.getListenAddress()
	if addr != "" {
		if _, port, err := net.SplitHostPort(addr); err == nil && port != "" {
			return port
		}
		if strings.Count(addr, ":") == 0 && addr != "" {
			return addr
		}
	}
	if r != nil && r.Host != "" {
		if _, port, err := net.SplitHostPort(r.Host); err == nil && port != "" {
			return port
		}
		if strings.Contains(r.Host, ":") {
			parts := strings.Split(r.Host, ":")
			if p := strings.TrimSpace(parts[len(parts)-1]); p != "" {
				return p
			}
		}
	}
	return "8080"
}

func (s *server) agentInfo(r *http.Request) agentConnectionInfo {
	port := s.serverPort(r)
	ips := lanIPv4s()
	candidates := make([]string, 0, len(ips)+3)
	seen := map[string]bool{}
	add := func(raw string) {
		u, err := normalizeAgentServerURL(raw, port)
		if err == nil && u != "" && !seen[u] {
			seen[u] = true
			candidates = append(candidates, u)
		}
	}

	override := s.getAgentServerOverride()
	if override != "" {
		add(override)
	}
	for _, ip := range ips {
		add(ip)
	}
	if r != nil && r.Host != "" {
		add(r.Host)
	}
	add("127.0.0.1")

	selected := override
	if selected == "" && len(candidates) > 0 {
		selected = candidates[0]
	}
	if selected == "" {
		selected = "ws://127.0.0.1:" + port
	}

	cfg := map[string]string{
		"server":   selected,
		"password": s.authPassword(),
	}
	b, _ := json.MarshalIndent(cfg, "", "  ")
	return agentConnectionInfo{
		AgentServerURL: selected,
		Candidates:     candidates,
		LANIPs:         ips,
		Port:           port,
		ConfigJSON:     string(b),
		LaunchCommand:  fmt.Sprintf("dist\\agent.exe -no-install -server %s", selected),
	}
}

func lanIPv4s() []string {
	ifaces, err := net.Interfaces()
	if err != nil {
		return nil
	}
	out := []string{}
	seen := map[string]bool{}
	for _, iface := range ifaces {
		if iface.Flags&net.FlagUp == 0 || iface.Flags&net.FlagLoopback != 0 {
			continue
		}
		addrs, err := iface.Addrs()
		if err != nil {
			continue
		}
		for _, a := range addrs {
			var ip net.IP
			switch v := a.(type) {
			case *net.IPNet:
				ip = v.IP
			case *net.IPAddr:
				ip = v.IP
			}
			ip4 := ip.To4()
			if ip4 == nil || ip4.IsLoopback() || ip4.IsUnspecified() {
				continue
			}
			s := ip4.String()
			if strings.HasPrefix(s, "169.254.") {
				continue
			}
			if !seen[s] {
				seen[s] = true
				out = append(out, s)
			}
		}
	}
	sort.Slice(out, func(i, j int) bool {
		return ipRank(out[i]) < ipRank(out[j]) || (ipRank(out[i]) == ipRank(out[j]) && out[i] < out[j])
	})
	return out
}

func ipRank(s string) int {
	switch {
	case strings.HasPrefix(s, "192.168."):
		return 0
	case strings.HasPrefix(s, "10."):
		return 1
	case strings.HasPrefix(s, "172."):
		parts := strings.Split(s, ".")
		if len(parts) > 1 {
			switch parts[1] {
			case "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31":
				return 2
			}
		}
		return 5
	default:
		return 5
	}
}

func normalizeAgentServerURL(raw string, defaultPort string) (string, error) {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return "", nil
	}
	raw = strings.TrimRight(raw, "/")
	if !strings.Contains(raw, "://") {
		host := raw
		if h, p, err := net.SplitHostPort(raw); err == nil {
			host = net.JoinHostPort(h, p)
		} else if strings.Count(raw, ":") == 0 {
			host = net.JoinHostPort(raw, defaultPort)
		}
		raw = "ws://" + host
	}
	u, err := url.Parse(raw)
	if err != nil {
		return "", err
	}
	switch strings.ToLower(u.Scheme) {
	case "http":
		u.Scheme = "ws"
	case "https":
		u.Scheme = "wss"
	case "ws", "wss":
	default:
		return "", fmt.Errorf("unsupported scheme %q", u.Scheme)
	}
	if u.Host == "" {
		return "", fmt.Errorf("missing host")
	}
	if !strings.Contains(u.Host, ":") && defaultPort != "" {
		u.Host = net.JoinHostPort(u.Host, defaultPort)
	}
	u.Path = ""
	u.RawQuery = ""
	u.Fragment = ""
	return u.String(), nil
}

func (s *server) serverURLPost(w http.ResponseWriter, r *http.Request) {
	if _, ok := s.requireSession(w, r); !ok {
		return
	}
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	if err := r.ParseForm(); err != nil {
		http.Error(w, "bad form", http.StatusBadRequest)
		return
	}
	raw := firstNonEmpty(r.FormValue("agent_server_url"), r.FormValue("server_ip"), r.FormValue("ip"))
	if _, err := s.setAgentServerOverride(raw, r); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	http.Redirect(w, r, "/settings?server_saved=1", http.StatusFound)
}

func (s *server) apiServerInfo(w http.ResponseWriter, r *http.Request) {
	if _, ok := s.requireSession(w, r); !ok {
		return
	}
	if r.Method == http.MethodPost {
		if err := r.ParseForm(); err != nil {
			http.Error(w, "bad form", http.StatusBadRequest)
			return
		}
		raw := firstNonEmpty(r.FormValue("agent_server_url"), r.FormValue("server_ip"), r.FormValue("ip"))
		if _, err := s.setAgentServerOverride(raw, r); err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
	}
	info := s.agentInfo(r)

	// Runtime snapshot for the Advanced System Information card + latency
	// pill. Cheap enough to compute on every poll.
	var ms runtime.MemStats
	runtime.ReadMemStats(&ms)

	s.knownMu.RLock()
	totalAgents := len(s.known)
	onlineAgents := 0
	for _, a := range s.known {
		if a.Online {
			onlineAgents++
		}
	}
	s.knownMu.RUnlock()

	s.agentsMu.RLock()
	liveSockets := len(s.agents)
	s.agentsMu.RUnlock()

	hostname, _ := os.Hostname()
	uptime := time.Since(s.startedAtUTC())

	writeJSON(w, map[string]any{
		// Existing fields (kept for back-compat).
		"agent_server_url":  info.AgentServerURL,
		"candidates":        info.Candidates,
		"lan_ips":           info.LANIPs,
		"port":              info.Port,
		"agent_config_json": info.ConfigJSON,
		"launch_command":    info.LaunchCommand,

		// New runtime fields used by the topbar latency pill + Advanced Info.
		"version":          config.ServerVersion,
		"hostname":         hostname,
		"os":               runtime.GOOS,
		"arch":             runtime.GOARCH,
		"go_version":       runtime.Version(),
		"pid":              os.Getpid(),
		"uptime_seconds":   int64(uptime.Seconds()),
		"uptime_human":     uptime.Round(time.Second).String(),
		"goroutines":       runtime.NumGoroutine(),
		"cpu_cores":        runtime.NumCPU(),
		"memory_alloc":     int64(ms.Alloc),
		"memory_sys":       int64(ms.Sys),
		"memory_heap":      int64(ms.HeapAlloc),
		"gc_count":         ms.NumGC,
		"agents_total":     totalAgents,
		"agents_online":    onlineAgents,
		"live_sockets":     liveSockets,
		"sessions":         s.sessionCount(),
		"frame_cap_bytes":  int64(wsmini.MaxFrameSize),
		"listen_addr":      s.getListenAddress(),
	})
}

func firstNonEmpty(vals ...string) string {
	for _, v := range vals {
		if strings.TrimSpace(v) != "" {
			return strings.TrimSpace(v)
		}
	}
	return ""
}
