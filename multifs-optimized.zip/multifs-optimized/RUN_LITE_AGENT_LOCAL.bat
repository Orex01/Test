@echo off
REM Edit SERVER and PASSWORD if your server is not on this machine or uses a custom password.
set SERVER=ws://127.0.0.1:8080/ws/agent
set PASSWORD=mlan-wtsKrrx9caxjVPLo
set NAME=lite-%COMPUTERNAME%
set ROOT=%USERPROFILE%

multifs-agent-lite-native.exe --server %SERVER% --password %PASSWORD% --name %NAME% --root "%ROOT%"
pause
