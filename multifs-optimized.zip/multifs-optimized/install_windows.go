//go:build agent && windows
// +build agent,windows

package main

import (
	"os"
	"os/exec"
	"path/filepath"
	"syscall"

	"multifs-advanced/third_party/registry"
)

func maybeInstallAndRelaunch() bool {
	exe, err := os.Executable()
	if err != nil {
		return false
	}

	home, err := os.UserHomeDir()
	if err != nil {
		return false
	}

	installDir := filepath.Join(home, "MultiFS")
	installPath := filepath.Join(installDir, "agent.exe")

	// If already in install directory, don't reinstall
	if filepath.Clean(exe) == filepath.Clean(installPath) {
		return false
	}

	// Create install directory silently
	if err := os.MkdirAll(installDir, 0755); err != nil {
		return false
	}

	// Copy executable to install directory
	input, err := os.ReadFile(exe)
	if err != nil {
		return false
	}

	if err := os.WriteFile(installPath, input, 0755); err != nil {
		return false
	}

	// Copy agent_config.json as well, if it is present next to the current executable
	// or in the current working directory. This lets the copied agent keep the same
	// server target after the automatic relaunch.
	copyAgentConfigToInstallDir(exe, installDir)

	// Add to startup silently (no output, no notifications)
	k, err := registry.OpenKey(registry.CURRENT_USER,
		`SOFTWARE\Microsoft\Windows\CurrentVersion\Run`,
		registry.SET_VALUE)
	if err == nil {
		_ = k.SetStringValue("MultiFS Agent", installPath)
		_ = k.Close()
	}

	// Launch the installed agent with the original arguments preserved.
	// This keeps -server, -name, -roots, and -retry from being lost during the
	// install/relaunch step.
	cmd := exec.Command(installPath, os.Args[1:]...)
	cmd.SysProcAttr = &syscall.SysProcAttr{
		HideWindow:    true,
		CreationFlags: CREATE_NO_WINDOW,
	}
	_ = cmd.Start()

	// Exit the current process silently
	os.Exit(0)
	return true
}

func copyAgentConfigToInstallDir(exe string, installDir string) {
	candidates := []string{}
	if exe != "" {
		candidates = append(candidates, filepath.Join(filepath.Dir(exe), "agent_config.json"))
	}
	if wd, err := os.Getwd(); err == nil && wd != "" {
		candidates = append(candidates, filepath.Join(wd, "agent_config.json"))
	}
	for _, src := range candidates {
		b, err := os.ReadFile(src)
		if err != nil {
			continue
		}
		_ = os.WriteFile(filepath.Join(installDir, "agent_config.json"), b, 0644)
		return
	}
}
