module multifs-advanced

go 1.21
