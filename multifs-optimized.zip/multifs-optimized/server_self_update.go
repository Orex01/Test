//go:build !agent
// +build !agent

package main

import (
	"encoding/base64"
	"fmt"
	"io"
	"net/http"
	"os"
	"strings"
	"time"

	"multifs-advanced/internal/config"
	"multifs-advanced/internal/protocol"
)

const maxSelfUpdateBytes = 256 << 20

func (s *server) apiAgentSelfUpdate(w http.ResponseWriter, r *http.Request) {
	se, ok := s.requireSession(w, r)
	if !ok || r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	if err := r.ParseMultipartForm(maxSelfUpdateBytes); err != nil {
		http.Error(w, "bad update upload", http.StatusBadRequest)
		return
	}
	key := strings.TrimSpace(r.FormValue("key"))
	if key == "" {
		key = se.selectedAgent
	}
	if key == "" {
		http.Error(w, "missing agent key", http.StatusBadRequest)
		return
	}
	ac := s.getOnlineConnByKey(key)
	if ac == nil {
		http.Error(w, "system offline", http.StatusBadRequest)
		return
	}
	if !s.agentSupportsFeature(ac, "remote_update") {
		http.Error(w, "selected agent does not advertise remote_update", http.StatusBadRequest)
		return
	}
	file, header, err := r.FormFile("file")
	if err != nil {
		http.Error(w, "missing update binary", http.StatusBadRequest)
		return
	}
	defer file.Close()
	data, err := io.ReadAll(io.LimitReader(file, maxSelfUpdateBytes+1))
	if err != nil {
		http.Error(w, "read upload failed", http.StatusInternalServerError)
		return
	}
	if len(data) == 0 {
		http.Error(w, "empty update binary", http.StatusBadRequest)
		return
	}
	if len(data) > maxSelfUpdateBytes {
		http.Error(w, "update binary is too large", http.StatusBadRequest)
		return
	}
	sha := sha256Hex(data)
	targetVersion := strings.TrimSpace(r.FormValue("version"))
	if targetVersion == "" {
		targetVersion = "unspecified"
	}
	resp, err := s.callAgent(key, protocol.Request{
		Op:      "self_update",
		DataB64: base64.StdEncoding.EncodeToString(data),
		Args: map[string]any{
			"sha256":         sha,
			"target_version": targetVersion,
			"server_version": config.ServerVersion,
			"protocol":       "multifs-update-v1",
			"restart":        true,
		},
	}, 120*time.Second)
	if err != nil || !resp.Ok {
		http.Error(w, agentError(err, resp.Err), http.StatusInternalServerError)
		return
	}
	writeJSON(w, map[string]any{
		"ok":             true,
		"agent":          key,
		"filename":       header.Filename,
		"bytes":          len(data),
		"sha256":         sha,
		"target_version": targetVersion,
		"result":         resp.Result,
	})
}

func (s *server) apiServerSelfUpdate(w http.ResponseWriter, r *http.Request) {
	if _, ok := s.requireSession(w, r); !ok || r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	if err := r.ParseMultipartForm(maxSelfUpdateBytes); err != nil {
		http.Error(w, "bad update upload", http.StatusBadRequest)
		return
	}
	file, header, err := r.FormFile("file")
	if err != nil {
		http.Error(w, "missing server update binary", http.StatusBadRequest)
		return
	}
	defer file.Close()
	data, err := io.ReadAll(io.LimitReader(file, maxSelfUpdateBytes+1))
	if err != nil {
		http.Error(w, "read upload failed", http.StatusInternalServerError)
		return
	}
	if len(data) == 0 {
		http.Error(w, "empty update binary", http.StatusBadRequest)
		return
	}
	if len(data) > maxSelfUpdateBytes {
		http.Error(w, "server update binary is too large", http.StatusBadRequest)
		return
	}
	providedSHA := strings.TrimSpace(r.FormValue("sha256"))
	exe, err := os.Executable()
	if err != nil {
		http.Error(w, "cannot locate current server executable", http.StatusInternalServerError)
		return
	}
	stage, sha, err := writeVerifiedUpdateFile(exe, data, providedSHA)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	if err := scheduleSelfReplaceAndRestart(exe, stage, os.Args[1:]); err != nil {
		_ = os.Remove(stage)
		http.Error(w, fmt.Sprintf("failed to schedule server replacement: %v", err), http.StatusInternalServerError)
		return
	}
	writeJSON(w, map[string]any{
		"ok":       true,
		"filename": header.Filename,
		"bytes":    len(data),
		"sha256":   sha,
		"version":  strings.TrimSpace(r.FormValue("version")),
		"message":  "server update staged; server will restart after this response",
	})
	go func() {
		time.Sleep(350 * time.Millisecond)
		if s.httpSrv != nil {
			_ = s.httpSrv.Close()
		}
		os.Exit(0)
	}()
}
