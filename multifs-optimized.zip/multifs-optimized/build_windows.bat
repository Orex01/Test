@echo off
setlocal EnableExtensions
cd /d "%~dp0"

if not exist build mkdir build
if not exist dist mkdir dist

where go >nul 2>nul
if errorlevel 1 (
  echo ERROR: Go was not found. Install Go 1.21 or newer and rerun this script.
  exit /b 1
)

echo Building Windows server.exe...
go build -trimpath -buildvcs=false -ldflags="-s -w -buildid=" -o build\multifs-server.exe .
if errorlevel 1 exit /b 1
copy /Y build\multifs-server.exe dist\server.exe >nul

echo Building Windows Full agent.exe...
go build -tags=agent -trimpath -buildvcs=false -ldflags="-s -w -buildid=" -o build\multifs-agent-full-go.exe .
if errorlevel 1 exit /b 1
copy /Y build\multifs-agent-full-go.exe dist\agent.exe >nul

echo Building Windows Full agent no-console EXE ^(-H=windowsgui^)...
go build -tags=agent -trimpath -buildvcs=false -ldflags="-s -w -buildid= -H=windowsgui" -o build\multifs-agent-full-go-windowsgui.exe .
if errorlevel 1 exit /b 1
copy /Y build\multifs-agent-full-go-windowsgui.exe dist\agent-windowsgui.exe >nul

echo Building Windows native Lite agent.exe...
call tools\build_native_lite_windows.bat
if errorlevel 1 (
  echo WARNING: Native Lite rebuild failed.
  if exist build\multifs-agent-lite-native.exe (
    if exist build\multifs-agent-lite-native-stripped.exe (
      echo Using existing prebuilt Lite EXEs from build\.
      copy /Y build\multifs-agent-lite-native.exe dist\multifs-agent-lite-native.exe >nul
      copy /Y build\multifs-agent-lite-native-stripped.exe dist\multifs-agent-lite-native-stripped.exe >nul
    ) else (
      echo ERROR: Native Lite stripped EXE is missing.
      echo Install LLVM/Clang for Windows, then rerun build_windows.bat.
      exit /b 1
    )
  ) else (
    echo ERROR: Native Lite build failed and no prebuilt Lite EXE exists.
    echo Install LLVM/Clang for Windows, then rerun build_windows.bat.
    exit /b 1
  )
)

if exist build\SHA256SUMS.txt del /Q build\SHA256SUMS.txt >nul 2>nul
where certutil >nul 2>nul
if not errorlevel 1 (
  for %%F in (build\multifs-server.exe build\multifs-agent-full-go.exe build\multifs-agent-full-go-windowsgui.exe build\multifs-agent-lite-native.exe build\multifs-agent-lite-native-stripped.exe build\multifs-agent-lite-native-windowsgui.exe build\multifs-agent-lite-native-windowsgui-stripped.exe) do (
    for /f "tokens=*" %%H in ('certutil -hashfile "%%F" SHA256 ^| findstr /R /V "hash CertUtil" ^| findstr /R /V "^$"') do echo %%H  %%F>> build\SHA256SUMS.txt
  )
  copy /Y build\SHA256SUMS.txt dist\SHA256SUMS.txt >nul
)

echo.
echo Done. Windows EXEs:
for %%F in (build\multifs-server.exe build\multifs-agent-full-go.exe build\multifs-agent-full-go-windowsgui.exe build\multifs-agent-lite-native.exe build\multifs-agent-lite-native-stripped.exe build\multifs-agent-lite-native-windowsgui.exe build\multifs-agent-lite-native-windowsgui-stripped.exe dist\server.exe dist\agent.exe dist\agent-windowsgui.exe dist\multifs-agent-lite-native.exe dist\multifs-agent-lite-native-stripped.exe dist\multifs-agent-lite-native-windowsgui.exe dist\multifs-agent-lite-native-windowsgui-stripped.exe) do if exist "%%F" echo   %%F %%~zF bytes
exit /b 0
