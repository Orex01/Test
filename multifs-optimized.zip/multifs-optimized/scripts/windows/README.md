# Windows Helper Scripts

These are copies of the root `.bat` launchers collected in one place for easier navigation.

The root copies remain available because they are the fastest way to run the server or agents during testing.
