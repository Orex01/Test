@echo off
setlocal EnableExtensions
cd /d "%~dp0\.."

if not exist build mkdir build
if not exist dist mkdir dist
if not exist .tmp_native_lite mkdir .tmp_native_lite

where clang >nul 2>nul
if errorlevel 1 (
  echo ERROR: clang was not found.
  echo Install LLVM for Windows from https://llvm.org or use the prebuilt build\multifs-agent-lite-native.exe included in this package.
  exit /b 2
)
where lld-link >nul 2>nul
if errorlevel 1 (
  echo ERROR: lld-link was not found.
  echo Install LLVM for Windows from https://llvm.org or use the prebuilt build\multifs-agent-lite-native.exe included in this package.
  exit /b 2
)

if not exist native_lite\imports\kernel32.def (
  echo ERROR: native_lite\imports\kernel32.def is missing.
  exit /b 1
)
if not exist native_lite\imports\ws2_32.def (
  echo ERROR: native_lite\imports\ws2_32.def is missing.
  exit /b 1
)
if not exist native_lite\imports\advapi32.def (
  echo ERROR: native_lite\imports\advapi32.def is missing.
  exit /b 1
)

echo Creating tiny Windows import libraries...
lld-link /lib /def:native_lite\imports\kernel32.def /machine:x64 /out:.tmp_native_lite\kernel32.lib
if errorlevel 1 exit /b 1
lld-link /lib /def:native_lite\imports\ws2_32.def /machine:x64 /out:.tmp_native_lite\ws2_32.lib
if errorlevel 1 exit /b 1
lld-link /lib /def:native_lite\imports\advapi32.def /machine:x64 /out:.tmp_native_lite\advapi32.lib
if errorlevel 1 exit /b 1

REM ── Compile with size-priority flags. -Oz already optimizes for size;
REM    -fno-builtin stops clang from emitting calls to memcpy/memset/etc.
REM    that we ship inline; -flto=thin lets the linker GC dead code across
REM    the whole binary; -mno-sse strips vectorized codegen which inflates
REM    short helpers like b64enc and json_str.
echo Compiling native Lite agent (Oz + LTO + no-builtin)...
clang --target=x86_64-windows-msvc ^
  -Oz -flto=thin ^
  -ffunction-sections -fdata-sections ^
  -fno-builtin -fno-builtin-memcpy -fno-builtin-memset ^
  -fno-stack-protector ^
  -fno-unwind-tables -fno-asynchronous-unwind-tables ^
  -fmerge-all-constants ^
  -mno-sse ^
  -c native_lite\multifs_lite_win.c -o build\multifs_lite_win.obj
if errorlevel 1 exit /b 1

REM ── Link with aggressive section folding + small file alignment.
REM
REM    /filealign:16 trims trailing zero-padding from short sections without
REM    changing in-memory layout — Windows Vista+ accepts file alignment
REM    down to 16. Default section alignment (4096) is preserved so loader
REM    compatibility is unaffected.
REM
REM    /opt:ref drops unreferenced symbols, /opt:icf folds identical
REM    function bodies (e.g. post-inlining variants of the JSON writers).
REM
REM    Only read-only sections merge into .text. .data and .bss hold the
REM    agent's writable globals (g_server, g_host, g_heap, ...) and must
REM    stay in writable sections — merging them into .text would crash on
REM    first write.
REM
REM    The <100 KB compatibility budget is enforced at the end of the
REM    script; if linker flags ever push past it the build aborts loudly.
set LITE_LINK_FLAGS=/entry:mainCRTStartup /nodefaultlib /opt:ref /opt:icf ^
  /filealign:16 ^
  /dynamicbase:no /fixed:no /largeaddressaware:no ^
  /merge:.rdata=.text /merge:.pdata=.text /merge:.xdata=.text

echo Linking console Lite EXE...
lld-link %LITE_LINK_FLAGS% /subsystem:console /out:build\multifs-agent-lite-native.exe build\multifs_lite_win.obj .tmp_native_lite\kernel32.lib .tmp_native_lite\ws2_32.lib .tmp_native_lite\advapi32.lib
if errorlevel 1 exit /b 1

echo Linking no-console Lite EXE...
lld-link %LITE_LINK_FLAGS% /subsystem:windows /out:build\multifs-agent-lite-native-windowsgui.exe build\multifs_lite_win.obj .tmp_native_lite\kernel32.lib .tmp_native_lite\ws2_32.lib .tmp_native_lite\advapi32.lib
if errorlevel 1 exit /b 1

where llvm-objcopy >nul 2>nul
if errorlevel 1 (
  copy /Y build\multifs-agent-lite-native.exe build\multifs-agent-lite-native-stripped.exe >nul
  copy /Y build\multifs-agent-lite-native-windowsgui.exe build\multifs-agent-lite-native-windowsgui-stripped.exe >nul
) else (
  llvm-objcopy --strip-all build\multifs-agent-lite-native.exe build\multifs-agent-lite-native-stripped.exe
  if errorlevel 1 copy /Y build\multifs-agent-lite-native.exe build\multifs-agent-lite-native-stripped.exe >nul
  llvm-objcopy --strip-all build\multifs-agent-lite-native-windowsgui.exe build\multifs-agent-lite-native-windowsgui-stripped.exe
  if errorlevel 1 copy /Y build\multifs-agent-lite-native-windowsgui.exe build\multifs-agent-lite-native-windowsgui-stripped.exe >nul
)

copy /Y build\multifs-agent-lite-native.exe dist\multifs-agent-lite-native.exe >nul
copy /Y build\multifs-agent-lite-native-stripped.exe dist\multifs-agent-lite-native-stripped.exe >nul
copy /Y build\multifs-agent-lite-native-windowsgui.exe dist\multifs-agent-lite-native-windowsgui.exe >nul
copy /Y build\multifs-agent-lite-native-windowsgui-stripped.exe dist\multifs-agent-lite-native-windowsgui-stripped.exe >nul

echo Done. Native Lite EXEs:
for %%F in (build\multifs-agent-lite-native.exe build\multifs-agent-lite-native-stripped.exe build\multifs-agent-lite-native-windowsgui.exe build\multifs-agent-lite-native-windowsgui-stripped.exe dist\multifs-agent-lite-native.exe dist\multifs-agent-lite-native-stripped.exe dist\multifs-agent-lite-native-windowsgui.exe dist\multifs-agent-lite-native-windowsgui-stripped.exe) do if exist "%%F" echo   %%F %%~zF bytes

REM Enforce the <100 KB compatibility budget on the stripped binary.
for %%F in (build\multifs-agent-lite-native-stripped.exe build\multifs-agent-lite-native-windowsgui-stripped.exe) do (
  if %%~zF GTR 102400 (
    echo.
    echo ERROR: %%F exceeds 100 KB compatibility budget ^(%%~zF bytes^). Tighten the source.
    exit /b 1
  ) else (
    echo   SIZE CHECK PASSED: %%F %%~zF bytes ^<= 102400
  )
)
exit /b 0
