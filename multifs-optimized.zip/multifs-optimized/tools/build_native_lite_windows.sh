#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build dist .tmp_native_lite

if ! command -v clang >/dev/null 2>&1; then
  echo "ERROR: clang was not found. Install LLVM/Clang or use the prebuilt build/multifs-agent-lite-native.exe." >&2
  exit 2
fi
if ! command -v lld-link >/dev/null 2>&1; then
  echo "ERROR: lld-link was not found. Install LLVM/LLD or use the prebuilt build/multifs-agent-lite-native.exe." >&2
  exit 2
fi

for f in kernel32 ws2_32 advapi32; do
  if [ ! -f "native_lite/imports/$f.def" ]; then
    echo "ERROR: native_lite/imports/$f.def is missing." >&2
    exit 1
  fi
  lld-link /lib /def:"native_lite/imports/$f.def" /machine:x64 /out:".tmp_native_lite/$f.lib"
done

# Size-priority flags: -Oz + thinLTO, no builtin memcpy/memset, no SSE
# vectorization, function/data sections so the linker can GC each individually.
clang --target=x86_64-windows-msvc \
  -Oz -flto=thin \
  -ffunction-sections -fdata-sections \
  -fno-builtin -fno-builtin-memcpy -fno-builtin-memset \
  -fno-stack-protector \
  -fno-unwind-tables -fno-asynchronous-unwind-tables \
  -fmerge-all-constants \
  -mno-sse \
  -c native_lite/multifs_lite_win.c -o build/multifs_lite_win.obj

# Aggressive section folding + 16-byte file alignment to trim trailing
# zero padding. Default in-memory section alignment (4096) is preserved
# for loader compatibility. Only read-only sections merge into .text;
# .data/.bss hold writable globals and must stay writable.
LITE_LINK_FLAGS=(
  /entry:mainCRTStartup /nodefaultlib
  /opt:ref /opt:icf
  /filealign:16
  /dynamicbase:no /fixed:no /largeaddressaware:no
  /merge:.rdata=.text /merge:.pdata=.text /merge:.xdata=.text
)

echo "Linking console Lite EXE..."
lld-link "${LITE_LINK_FLAGS[@]}" /subsystem:console /out:build/multifs-agent-lite-native.exe build/multifs_lite_win.obj .tmp_native_lite/kernel32.lib .tmp_native_lite/ws2_32.lib .tmp_native_lite/advapi32.lib

echo "Linking no-console Lite EXE (/subsystem:windows; equivalent to Go -H=windowsgui)..."
lld-link "${LITE_LINK_FLAGS[@]}" /subsystem:windows /out:build/multifs-agent-lite-native-windowsgui.exe build/multifs_lite_win.obj .tmp_native_lite/kernel32.lib .tmp_native_lite/ws2_32.lib .tmp_native_lite/advapi32.lib

if command -v llvm-objcopy >/dev/null 2>&1; then
  llvm-objcopy --strip-all build/multifs-agent-lite-native.exe build/multifs-agent-lite-native-stripped.exe || cp build/multifs-agent-lite-native.exe build/multifs-agent-lite-native-stripped.exe
  llvm-objcopy --strip-all build/multifs-agent-lite-native-windowsgui.exe build/multifs-agent-lite-native-windowsgui-stripped.exe || cp build/multifs-agent-lite-native-windowsgui.exe build/multifs-agent-lite-native-windowsgui-stripped.exe
else
  cp build/multifs-agent-lite-native.exe build/multifs-agent-lite-native-stripped.exe
  cp build/multifs-agent-lite-native-windowsgui.exe build/multifs-agent-lite-native-windowsgui-stripped.exe
fi
cp build/multifs-agent-lite-native.exe dist/multifs-agent-lite-native.exe
cp build/multifs-agent-lite-native-stripped.exe dist/multifs-agent-lite-native-stripped.exe
cp build/multifs-agent-lite-native-windowsgui.exe dist/multifs-agent-lite-native-windowsgui.exe
cp build/multifs-agent-lite-native-windowsgui-stripped.exe dist/multifs-agent-lite-native-windowsgui-stripped.exe
ls -lh build/multifs-agent-lite-native.exe build/multifs-agent-lite-native-stripped.exe build/multifs-agent-lite-native-windowsgui.exe build/multifs-agent-lite-native-windowsgui-stripped.exe dist/multifs-agent-lite-native.exe dist/multifs-agent-lite-native-stripped.exe dist/multifs-agent-lite-native-windowsgui.exe dist/multifs-agent-lite-native-windowsgui-stripped.exe

# Enforce <100 KB compatibility budget on the stripped binary.
LIMIT=102400
for STRIPPED in build/multifs-agent-lite-native-stripped.exe build/multifs-agent-lite-native-windowsgui-stripped.exe; do
  SIZE=$(stat -c%s "$STRIPPED" 2>/dev/null || wc -c < "$STRIPPED")
  if [ "$SIZE" -gt "$LIMIT" ]; then
    echo "ERROR: $STRIPPED ($SIZE bytes) exceeds the 100 KB compatibility budget. Tighten the source." >&2
    exit 1
  else
    echo "  SIZE CHECK PASSED: $STRIPPED $SIZE bytes <= $LIMIT"
  fi
done
