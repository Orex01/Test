//go:build agent
// +build agent

package main

import (
	"encoding/json"
	"net"
	"strings"
	"time"
)

const (
	discoveryUDPPort = 45808
	discoveryRequest = "MULTIFS_DISCOVER_V1"
)

type discoveryReply struct {
	Type       string   `json:"type"`
	AgentURL   string   `json:"agent_url"`
	HTTPURL    string   `json:"http_url"`
	Host       string   `json:"host"`
	Port       string   `json:"port"`
	Candidates []string `json:"candidates"`
	TimeUTC    string   `json:"time_utc"`
}

func discoverAgentServerURL(timeout time.Duration) string {
	conn, err := net.ListenPacket("udp4", "0.0.0.0:0")
	if err != nil {
		return ""
	}
	defer conn.Close()

	_ = conn.SetDeadline(time.Now().Add(timeout))
	for _, addr := range discoveryTargets() {
		_, _ = conn.WriteTo([]byte(discoveryRequest), addr)
	}

	buf := make([]byte, 4096)
	for {
		n, _, err := conn.ReadFrom(buf)
		if err != nil {
			return ""
		}
		var rep discoveryReply
		if json.Unmarshal(buf[:n], &rep) != nil {
			continue
		}
		if rep.Type != "multifs_server" {
			continue
		}
		if strings.TrimSpace(rep.AgentURL) != "" {
			return normalizeAgentURL(rep.AgentURL)
		}
		for _, c := range rep.Candidates {
			if strings.TrimSpace(c) != "" {
				return normalizeAgentURL(c)
			}
		}
	}
}

func discoveryTargets() []net.Addr {
	out := []net.Addr{&net.UDPAddr{IP: net.IPv4bcast, Port: discoveryUDPPort}}
	seen := map[string]bool{"255.255.255.255": true}
	ifaces, err := net.Interfaces()
	if err != nil {
		return out
	}
	for _, iface := range ifaces {
		if iface.Flags&net.FlagUp == 0 || iface.Flags&net.FlagLoopback != 0 {
			continue
		}
		addrs, err := iface.Addrs()
		if err != nil {
			continue
		}
		for _, a := range addrs {
			ipnet, ok := a.(*net.IPNet)
			if !ok {
				continue
			}
			ip := ipnet.IP.To4()
			if ip == nil || ip.IsLoopback() || ip.IsUnspecified() {
				continue
			}
			mask := ipnet.Mask
			if len(mask) != 4 {
				continue
			}
			bcast := net.IPv4(ip[0]|^mask[0], ip[1]|^mask[1], ip[2]|^mask[2], ip[3]|^mask[3])
			s := bcast.String()
			if !seen[s] {
				seen[s] = true
				out = append(out, &net.UDPAddr{IP: bcast, Port: discoveryUDPPort})
			}
		}
	}
	return out
}
