//go:build !agent && windows
// +build !agent,windows

package main

import (
	"os/exec"
	"syscall"
)

// launchUninstallScript runs the per-instance uninstall .bat under a hidden
// cmd.exe so it never spawns a visible "MultiFS Uninstall" window. The
// previous implementation used `cmd.exe /C start "" script.bat`, but `start`
// always creates a fresh console window that ignores the parent's HideWindow
// flag — that was the source of the visible CMD pop-up users saw on server
// self-uninstall.
func launchUninstallScript(scriptPath string) error {
	cmd := exec.Command("cmd.exe", "/C", scriptPath)
	cmd.SysProcAttr = &syscall.SysProcAttr{
		HideWindow:    true,
		CreationFlags: CREATE_NO_WINDOW,
	}
	cmd.Stdin = nil
	cmd.Stdout = nil
	cmd.Stderr = nil
	return cmd.Start()
}
