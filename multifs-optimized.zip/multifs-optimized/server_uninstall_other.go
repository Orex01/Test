//go:build !agent && !windows
// +build !agent,!windows

package main

import "errors"

// launchUninstallScript is a no-op on non-Windows builds; the in-tree
// uninstall flow targets Windows artifacts (.bat / cmd.exe) only.
func launchUninstallScript(scriptPath string) error {
	return errors.New("server self-uninstall is only supported on Windows")
}
