//go:build agent && !windows
// +build agent,!windows

package main

import "errors"

func uninstallSelf() error {
	return errors.New("uninstall not supported on this platform")
}
