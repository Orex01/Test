//go:build agent && windows
// +build agent,windows

package main

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"syscall"
	"time"

	"multifs-advanced/third_party/registry"
)

// uninstallSelf removes the agent's autostart persistence and schedules
// deletion of the running agent executable. Two bugs are explicitly fixed
// here vs. the historical implementation:
//
//  1. The script was previously launched as `cmd.exe /C start "" script.bat`.
//     The `start` builtin creates a fresh console window that IGNORES the
//     parent's HideWindow flag and IGNORES CREATE_NO_WINDOW. That spawned
//     a visible CMD window. We now run the script directly under a hidden
//     cmd.exe with CREATE_NO_WINDOW — no console, no flicker.
//
//  2. The script self-deleted with `del /F /Q "%~f0"` while cmd.exe still
//     held the script file open, which produced the "The batch file cannot
//     be found" message on some cmd.exe versions. We use the canonical
//     `(goto) 2>nul & del /F /Q "%~f0"` idiom, which closes cmd.exe's
//     script handle before issuing the delete.
//
// Safety: this function ONLY deletes the agent executable itself. It does
// NOT remove the directory the executable lives in — that is the caller's
// machine, and the executable's parent directory may contain unrelated
// files. (A previous draft of this code did `rmdir /S /Q installDir`,
// which is catastrophic when an agent is launched from a folder that
// happens to contain other files.)
func uninstallSelf() error {
	// Remove Run-key persistence silently.
	if k, err := registry.OpenKey(registry.CURRENT_USER,
		`SOFTWARE\Microsoft\Windows\CurrentVersion\Run`,
		registry.SET_VALUE); err == nil {
		_ = k.DeleteValue("MultiFS Agent")
		_ = k.Close()
	}

	// Remove agent ID file.
	if home, err := os.UserHomeDir(); err == nil && home != "" {
		_ = os.Remove(filepath.Join(home, ".multifs_agent_id"))
	}

	exe, _ := os.Executable()
	exe = filepath.Clean(exe)

	// Per-invocation temp script so concurrent uninstalls never collide and
	// stale scripts never interfere.
	scriptPath := filepath.Join(os.TempDir(), fmt.Sprintf("multifs_uninstall_%d.bat", time.Now().UnixNano()))

	// IMPORTANT: only `del` the EXE, NEVER `rmdir` its parent directory.
	script := "@echo off\r\n" +
		":wait\r\n" +
		"ping -n 2 127.0.0.1 >nul\r\n" +
		"del /F /Q \"" + exe + "\" >nul 2>&1\r\n" +
		"if exist \"" + exe + "\" goto wait\r\n" +
		"(goto) 2>nul & del /F /Q \"%~f0\"\r\n"

	if err := os.WriteFile(scriptPath, []byte(script), 0644); err != nil {
		return err
	}

	// Run the script directly under a hidden cmd.exe. No `start`, no extra
	// console window. CREATE_NO_WINDOW suppresses the console entirely.
	cmd := exec.Command("cmd.exe", "/C", scriptPath)
	cmd.SysProcAttr = &syscall.SysProcAttr{
		HideWindow:    true,
		CreationFlags: CREATE_NO_WINDOW,
	}
	cmd.Stdin = nil
	cmd.Stdout = nil
	cmd.Stderr = nil
	return cmd.Start()
}
