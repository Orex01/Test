# Windows GUI-subsystem agent builds

This package keeps normal console agents for troubleshooting and also produces explicit no-console Windows GUI-subsystem variants.

## Full Go agent

The Full agent no-console build is produced with:

```bat
go build -tags=agent -trimpath -buildvcs=false -ldflags="-s -w -buildid= -H=windowsgui" -o build\multifs-agent-full-go-windowsgui.exe .
```

Output copies:

- `build/multifs-agent-full-go-windowsgui.exe`
- `dist/agent-windowsgui.exe`

## Native Lite agent

The native C Lite agent does not use Go linker flags. The PE/COFF equivalent of `-H=windowsgui` is linking with the Windows subsystem:

```bat
lld-link /entry:mainCRTStartup /subsystem:windows ... /out:build\multifs-agent-lite-native-windowsgui.exe
```

Output copies:

- `build/multifs-agent-lite-native-windowsgui.exe`
- `build/multifs-agent-lite-native-windowsgui-stripped.exe`
- `dist/multifs-agent-lite-native-windowsgui.exe`
- `dist/multifs-agent-lite-native-windowsgui-stripped.exe`

## Recommended workflow

Use the console builds while testing configuration, server URL, password, and drive access. Use the `windowsgui` builds only after the connection has been verified because Windows will not create a console window for diagnostics.
