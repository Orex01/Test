@echo off
echo Stopping MultiFS server/agent processes started from this account...
taskkill /F /T /IM server.exe 2>nul
taskkill /F /T /IM agent.exe 2>nul
echo Done.
pause
