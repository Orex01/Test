//go:build agent && !windows
// +build agent,!windows

package main

func maybeInstallAndRelaunch() bool {
	return false
}
