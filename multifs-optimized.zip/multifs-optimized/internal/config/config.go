// Package config contains shared configuration between server and agent.
package config

// SharedPassword is the authentication password used by both server and agent.
// Change this before deploying!
const SharedPassword = "mlan-wtsKrrx9caxjVPLo"

// DefaultAdminUsername is the default admin username for the web interface.
const DefaultAdminUsername = "admin"

// AgentVersion is the current agent version.
const AgentVersion = "2.5.0"

// ServerVersion is the current server version.
const ServerVersion = "2.5.0"

// DefaultServerAddress is the default server listen address.
const DefaultServerAddress = "0.0.0.0:8080"

// DefaultAgentServer is the default server URL for agents.
const DefaultAgentServer = "ws://127.0.0.1:8080"
