// Package wsmini is a minimal WebSocket implementation with no external dependencies.
package wsmini

import (
	"bufio"
	"crypto/rand"
	"crypto/sha1"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"sync"
	"time"
)

// MaxFrameSize is the maximum allowed WebSocket frame payload size.
//
// The agent transport uses a single non-fragmented frame per request/response,
// and file-manager responses (file reads, ZIPs of selected files/folders) are
// returned as base64-encoded JSON inside that one frame. Base64 inflates the
// payload by ~1.33×, so an 8 MiB cap (the previous value) limited a single
// file or ZIP to roughly 6 MiB of actual content — small enough that any
// non-trivial ZIP-of-selected operation would disconnect the agent with
// "frame too large", at which point the agent reconnects and the user retries,
// producing the connect/disconnect loop reported in the field.
//
// 256 MiB gives ~192 MiB of effective payload after base64 overhead, which
// covers realistic file-manager workloads. The trade-off is per-frame
// allocation: a single frame may force a 256 MiB allocation on the receiver.
// That is acceptable here because:
//   - the agent socket is authenticated (only trusted agents can speak it);
//   - the server is intended to run on a trusted LAN, not exposed to the
//     internet without an auth proxy;
//   - the file manager genuinely needs to transfer multi-megabyte payloads.
//
// If this ever becomes a memory-pressure issue (e.g. dozens of concurrent
// in-flight large responses), the right fix is to chunk file/ZIP transfers
// over multiple smaller frames rather than to shrink this cap again — the
// previous 8 MiB value made the file manager unusable for any meaningful
// selection.
const MaxFrameSize = 256 << 20

// Conn is a minimal WebSocket connection.
type Conn struct {
	conn    net.Conn
	br      *bufio.Reader
	server  bool
	maskKey [4]byte
	mu      sync.Mutex // protects concurrent writes
}

// AuthError represents an authentication failure.
type AuthError struct {
	StatusCode int
	Message    string
}

func (e *AuthError) Error() string {
	return fmt.Sprintf("authentication failed: %s (status %d)", e.Message, e.StatusCode)
}

// Accept upgrades an HTTP connection to WebSocket.
func Accept(w http.ResponseWriter, r *http.Request) (*Conn, error) {
	hj, ok := w.(http.Hijacker)
	if !ok {
		return nil, errors.New("hijacking not supported")
	}
	conn, rw, err := hj.Hijack()
	if err != nil {
		return nil, err
	}

	key := r.Header.Get("Sec-WebSocket-Key")
	if key == "" {
		conn.Close()
		return nil, errors.New("missing Sec-WebSocket-Key")
	}
	accept := computeAccept(key)

	resp := "HTTP/1.1 101 Switching Protocols\r\n" +
		"Upgrade: websocket\r\n" +
		"Connection: Upgrade\r\n" +
		"Sec-WebSocket-Accept: " + accept + "\r\n" +
		"\r\n"

	if _, err := conn.Write([]byte(resp)); err != nil {
		conn.Close()
		return nil, err
	}

	return &Conn{conn: conn, br: rw.Reader, server: true}, nil
}

// Dial connects to a WebSocket server.
func Dial(urlStr string, hdr http.Header, timeout time.Duration) (*Conn, *http.Response, error) {
	u, err := url.Parse(urlStr)
	if err != nil {
		return nil, nil, err
	}

	addr := u.Host
	if _, _, splitErr := net.SplitHostPort(addr); splitErr != nil {
		port := "80"
		if u.Scheme == "wss" {
			port = "443"
		}
		addr = net.JoinHostPort(addr, port)
	}

	conn, err := net.DialTimeout("tcp", addr, timeout)
	if err != nil {
		return nil, nil, fmt.Errorf("connection failed: %w", err)
	}

	requestURI := u.RequestURI()
	if requestURI == "" {
		requestURI = "/"
	}

	key := generateKey()
	accept := computeAccept(key)

	req := "GET " + requestURI + " HTTP/1.1\r\n" +
		"Host: " + u.Host + "\r\n" +
		"Upgrade: websocket\r\n" +
		"Connection: Upgrade\r\n" +
		"Sec-WebSocket-Key: " + key + "\r\n" +
		"Sec-WebSocket-Version: 13\r\n"

	if hdr != nil {
		for k, v := range hdr {
			for _, vv := range v {
				req += k + ": " + vv + "\r\n"
			}
		}
	}
	req += "\r\n"

	if _, err := conn.Write([]byte(req)); err != nil {
		conn.Close()
		return nil, nil, fmt.Errorf("failed to send request: %w", err)
	}

	br := bufio.NewReader(conn)
	resp, err := http.ReadResponse(br, &http.Request{Method: "GET"})
	if err != nil {
		conn.Close()
		return nil, nil, fmt.Errorf("failed to read response: %w", err)
	}

	if resp.StatusCode == 401 {
		conn.Close()
		return nil, resp, &AuthError{StatusCode: 401, Message: "unauthorized - check password configuration"}
	}
	if resp.StatusCode == 403 {
		conn.Close()
		return nil, resp, &AuthError{StatusCode: 403, Message: "forbidden"}
	}
	if resp.StatusCode != 101 {
		conn.Close()
		return nil, resp, fmt.Errorf("unexpected status: %s", resp.Status)
	}

	if srvAccept := resp.Header.Get("Sec-WebSocket-Accept"); srvAccept != accept {
		conn.Close()
		return nil, resp, errors.New("accept mismatch")
	}

	c := &Conn{conn: conn, br: br, server: false}
	// Generate random mask key for client frames
	if _, err := rand.Read(c.maskKey[:]); err == nil {
		if c.maskKey == [4]byte{0, 0, 0, 0} {
			c.maskKey[0] = 0xAB
		}
	}
	return c, resp, nil
}

// ReadMessage reads a complete WebSocket text message (handles continuation frames).
func (c *Conn) ReadMessage() (int, []byte, error) {
	var payload []byte
	for {
		frame, err := c.readFrame()
		if err != nil {
			return 0, nil, err
		}
		switch frame.opcode {
		case 0x1: // Text frame
			if !frame.fin {
				payload = append(payload, frame.payload...)
				continue
			}
			if len(payload) > 0 {
				payload = append(payload, frame.payload...)
				return 1, payload, nil
			}
			return 1, frame.payload, nil
		case 0x0: // Continuation frame
			payload = append(payload, frame.payload...)
			if frame.fin {
				return 1, payload, nil
			}
		case 0x8: // Close frame
			c.writeClose(1000, "")
			return 8, nil, errors.New("connection closed")
		case 0x9: // Ping frame
			c.writePong(frame.payload)
		case 0xA: // Pong frame - ignore
		default:
			// Unknown opcode - ignore per RFC 6455
		}
	}
}

// WriteJSON writes a JSON message with proper synchronization.
func (c *Conn) WriteJSON(v any) error {
	c.mu.Lock()
	defer c.mu.Unlock()
	data, err := json.Marshal(v)
	if err != nil {
		return err
	}
	return c.writeText(data)
}

// SetReadDeadline sets read deadline.
func (c *Conn) SetReadDeadline(t time.Time) error {
	return c.conn.SetReadDeadline(t)
}

// SetWriteDeadline sets write deadline.
func (c *Conn) SetWriteDeadline(t time.Time) error {
	return c.conn.SetWriteDeadline(t)
}

// Close closes the connection with a proper close frame.
func (c *Conn) Close() error {
	_ = c.writeClose(1000, "")
	return c.conn.Close()
}

// frame represents a WebSocket frame.
type frame struct {
	fin     bool
	opcode  byte
	payload []byte
}

func (c *Conn) readFrame() (*frame, error) {
	header := make([]byte, 2)
	if _, err := io.ReadFull(c.br, header); err != nil {
		return nil, err
	}

	fin := (header[0] & 0x80) != 0
	opcode := header[0] & 0x0F
	masked := (header[1] & 0x80) != 0
	length := int64(header[1] & 0x7F)

	if length == 126 {
		ext := make([]byte, 2)
		if _, err := io.ReadFull(c.br, ext); err != nil {
			return nil, err
		}
		length = int64(ext[0])<<8 | int64(ext[1])
	} else if length == 127 {
		ext := make([]byte, 8)
		if _, err := io.ReadFull(c.br, ext); err != nil {
			return nil, err
		}
		length = 0
		for i := 0; i < 8; i++ {
			length = length<<8 | int64(ext[i])
		}
		if length < 0 {
			return nil, errors.New("invalid frame length (negative)")
		}
	}

	if length > MaxFrameSize {
		return nil, fmt.Errorf("frame too large: %d (max %d)", length, MaxFrameSize)
	}

	var maskKey []byte
	if masked {
		maskKey = make([]byte, 4)
		if _, err := io.ReadFull(c.br, maskKey); err != nil {
			return nil, err
		}
	}

	payload := make([]byte, length)
	if length > 0 {
		if _, err := io.ReadFull(c.br, payload); err != nil {
			return nil, err
		}
	}

	if masked {
		for i := range payload {
			payload[i] ^= maskKey[i%4]
		}
	}

	return &frame{fin: fin, opcode: opcode, payload: payload}, nil
}

func (c *Conn) writeText(data []byte) error {
	return c.writeFrame(0x1, true, data)
}

func (c *Conn) writePong(data []byte) error {
	return c.writeFrame(0xA, true, data)
}

func (c *Conn) writeClose(code int, reason string) error {
	payload := make([]byte, 2+len(reason))
	payload[0] = byte(code >> 8)
	payload[1] = byte(code)
	copy(payload[2:], reason)
	return c.writeFrame(0x8, true, payload)
}

func (c *Conn) writeFrame(opcode byte, fin bool, payload []byte) error {
	length := len(payload)
	if length > MaxFrameSize {
		return errors.New("payload exceeds maximum frame size")
	}

	var b0 byte = opcode
	if fin {
		b0 |= 0x80
	}

	var hdr []byte
	if length < 126 {
		hdr = []byte{b0, byte(length)}
	} else if length < 65536 {
		hdr = []byte{b0, 126, byte(length >> 8), byte(length)}
	} else {
		hdr = []byte{b0, 127,
			byte(length >> 56), byte(length >> 48), byte(length >> 40), byte(length >> 32),
			byte(length >> 24), byte(length >> 16), byte(length >> 8), byte(length),
		}
	}

	if !c.server {
		hdr[1] |= 0x80
		hdr = append(hdr, c.maskKey[:]...)
		masked := make([]byte, length)
		for i := range payload {
			masked[i] = payload[i] ^ c.maskKey[i%4]
		}
		payload = masked
	}

	if _, err := c.conn.Write(hdr); err != nil {
		return err
	}
	_, err := c.conn.Write(payload)
	return err
}

func computeAccept(key string) string {
	const magic = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
	h := sha1.Sum([]byte(key + magic))
	return base64.StdEncoding.EncodeToString(h[:])
}

func generateKey() string {
	b := make([]byte, 16)
	if _, err := rand.Read(b); err != nil {
		for i := range b {
			b[i] = byte(i*7+13) ^ byte(time.Now().UnixNano())
		}
	}
	return base64.StdEncoding.EncodeToString(b)
}
