// Package protocol defines the communication protocol between server and agent.
package protocol

import "encoding/json"

// Request is sent from server to agent.
type Request struct {
	Type      string         `json:"type"`
	ID        string         `json:"id"`
	Op        string         `json:"op"`
	Path      string         `json:"path,omitempty"`
	Path2     string         `json:"path2,omitempty"`
	Paths     []string       `json:"paths,omitempty"`
	DataB64   string         `json:"data_b64,omitempty"`
	MaxBytes  int            `json:"max_bytes,omitempty"`
	Offset    int64          `json:"offset,omitempty"`
	Length    int64          `json:"length,omitempty"`
	Recursive bool           `json:"recursive,omitempty"`
	Mkdirs    bool           `json:"mkdirs,omitempty"`
	Args      map[string]any `json:"args,omitempty"`
}

// Response is sent from agent to server.
type Response struct {
	Type   string          `json:"type"`
	ID     string          `json:"id"`
	Ok     bool            `json:"ok"`
	Result json.RawMessage `json:"result,omitempty"`
	Err    string          `json:"err,omitempty"`
}

// Hello is the first message from agent.
type Hello struct {
	Type         string   `json:"type"`
	Key          string   `json:"key"`
	Name         string   `json:"name"`
	Hostname     string   `json:"hostname"`
	OS           string   `json:"os"`
	Arch         string   `json:"arch"`
	User         string   `json:"user"`
	Roots        []string `json:"roots"`
	Version      string   `json:"version"`
	Build        string   `json:"build,omitempty"`
	Capabilities []string `json:"capabilities,omitempty"`
}

// DirEntry represents a file or directory.
type DirEntry struct {
	Name    string `json:"name"`
	IsDir   bool   `json:"is_dir"`
	Size    int64  `json:"size"`
	ModTime int64  `json:"mod_time"`
}

// ListResult from list operation.
type ListResult struct {
	Path    string     `json:"path"`
	Entries []DirEntry `json:"entries"`
}

// ReadResult from read operation.
type ReadResult struct {
	Path    string `json:"path"`
	DataB64 string `json:"data_b64"`
	Size    int64  `json:"size"`
	ModTime int64  `json:"mod_time"`
}

// ReadChunkResult from the streaming read_chunk operation. The agent reads
// up to Request.Length bytes from Request.Offset and returns them as base64.
// EOF is true when the chunk reached the end of the file.
type ReadChunkResult struct {
	Path    string `json:"path"`
	DataB64 string `json:"data_b64"`
	Offset  int64  `json:"offset"`
	Bytes   int    `json:"bytes"`
	Size    int64  `json:"size"`
	ModTime int64  `json:"mod_time"`
	EOF     bool   `json:"eof"`
}

// PreviewResult from preview operation.
type PreviewResult struct {
	Path      string `json:"path"`
	Content   string `json:"content"`
	Truncated bool   `json:"truncated"`
}

// Drive represents a drive/root.
type Drive struct {
	Label string `json:"label"`
	Path  string `json:"path"`
}

// DrivesResult from drives operation.
type DrivesResult struct {
	Drives []Drive `json:"drives"`
}

// ProcessInfo represents a running process.
type ProcessInfo struct {
	PID        int32   `json:"pid"`
	Name       string  `json:"name"`
	Executable string  `json:"executable"`
	Username   string  `json:"username"`
	MemoryMB   float64 `json:"memory_mb"`
	CPUPercent float64 `json:"cpu_percent"`
	Status     string  `json:"status"`
}

// RegistryKey represents a registry key.
type RegistryKey struct {
	Path    string          `json:"path"`
	SubKeys []string        `json:"sub_keys"`
	Values  []RegistryValue `json:"values"`
}

// RegistryValue represents a registry value.
type RegistryValue struct {
	Name  string `json:"name"`
	Type  string `json:"type"`
	Value string `json:"value"`
}

// StartupEntry represents a startup item.
type StartupEntry struct {
	Name     string `json:"name"`
	Path     string `json:"path"`
	Location string `json:"location"`
	Enabled  bool   `json:"enabled"`
}

// LogEntry represents a log entry.
type LogEntry struct {
	Timestamp int64  `json:"timestamp"`
	Level     string `json:"level"`
	Source    string `json:"source"`
	Message   string `json:"message"`
}

// ScreenFrame represents a screen capture frame.
type ScreenFrame struct {
	DataB64 string `json:"data_b64"`
	Width   int    `json:"width"`
	Height  int    `json:"height"`
	Format  string `json:"format"`
}

// MustMarshal helper marshals v to JSON; returns nil on error.
func MustMarshal(v any) json.RawMessage {
	b, err := json.Marshal(v)
	if err != nil {
		return nil
	}
	return b
}
