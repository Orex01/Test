# Lite build crash fix

This package fixes the Lite native Windows build path.

## What was wrong

Some copied build scripts under `scripts/build/` were not real wrappers: they changed into `scripts/build` and then tried to build from that directory. That made the Lite build fail because `tools/`, `native_lite/`, and the Go module were not at that relative path.

The Lite link flags also now use standard Windows PE file alignment (`/filealign:512`) and disable ASLR for the no-relocation tiny PE (`/dynamicbase:no`). This avoids loader rejection or crashes on stricter Windows systems while keeping the EXE below 100 KB.

## Correct commands

From the project root:

```bat
build_windows.bat
```

To build only the Lite native EXE:

```bat
BUILD_LITE_WINDOWS.bat
```

Linux/WSL cross-build:

```bash
bash build_windows.sh
bash tools/build_native_lite_windows.sh
```

## Requirements for rebuilding Lite

Install LLVM/Clang for Windows and make sure these commands are in PATH:

```text
clang.exe
lld-link.exe
```

If LLVM is not installed, the full build script will keep using the prebuilt Lite EXE already included in `build/`.
