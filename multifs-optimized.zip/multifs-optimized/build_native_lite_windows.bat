@echo off
setlocal EnableExtensions
cd /d "%~dp0"
call tools\build_native_lite_windows.bat
exit /b %ERRORLEVEL%
exit /b 0
