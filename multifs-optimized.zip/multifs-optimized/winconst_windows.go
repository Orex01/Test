//go:build windows
// +build windows

package main

// CREATE_NO_WINDOW is the Win32 process creation flag used to start child processes without a console window.
// The Go syscall package does not expose this constant.
const CREATE_NO_WINDOW = 0x08000000
