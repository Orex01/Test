# Project structure

```text
.
├── server*.go                  # Web server, UI routes, API routes, agent connection state
├── agent*.go                   # Full Go agent build, enabled with -tags=agent
├── native_lite/                # Native C Lite Windows agent and import definitions
├── internal/                   # Shared config, protocol, tiny WebSocket implementation
├── static/                     # Browser CSS/JS assets embedded into the server
├── templates/                  # HTML templates embedded into the server
├── docs/                       # System documentation, operations, troubleshooting
├── scripts/                    # Organized helper scripts copied from root scripts
│   ├── build/                  # Build helpers
│   ├── run/                    # Reserved for run helpers
│   └── windows/                # Windows run/install helpers
├── build/                      # Rebuilt binaries for development/testing
└── dist/                       # Release-style Windows EXE outputs
```

Root `.bat` scripts are kept for compatibility, while copies are placed under `scripts/windows/` and `scripts/build/` for cleaner navigation.
```
