//go:build !agent
// +build !agent

package main

import (
	"crypto/rand"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"html/template"
	"io"
	"log"
	"mime"
	"mime/multipart"
	"net/http"
	"net/url"
	"path"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"multifs-advanced/internal/protocol"
)

type drive struct {
	Label string
	Path  string
}

type browseEntry struct {
	Name       string
	RelPath    string
	IsDir      bool
	Size       int64
	ModTime    time.Time
	IsFavorite bool
}

type breadcrumb struct {
	Label   string
	RelPath string
}

func serveStatic(w http.ResponseWriter, r *http.Request) {
	filePath := strings.TrimPrefix(r.URL.Path, "/static/")
	b, err := staticFS.ReadFile("static/" + filePath)
	if err != nil {
		http.Error(w, "not found", http.StatusNotFound)
		return
	}
	ct := mime.TypeByExtension(filepath.Ext(filePath))
	if ct != "" {
		w.Header().Set("Content-Type", ct)
	}
	w.Header().Set("Cache-Control", "no-store, no-cache, must-revalidate")
	_, _ = w.Write(b)
}

func (s *server) browse(w http.ResponseWriter, r *http.Request) {
	se, ok := s.requireSession(w, r)
	if !ok {
		return
	}

	agentID, ac := s.selectedAgentFor(se)

	driveList := []drive{}
	if ac != nil {
		if drs, err := s.drivesFor(agentID); err == nil {
			driveList = drs
		}
	}

	p := requestPath(r, "path", "p")
	if p == "" {
		p = defaultBrowsePath(ac, driveList)
	}
	p = cleanRemotePath(p)
	if p == "" {
		p = "/"
	}

	entries := []browseEntry{}
	var listErr string
	currentPath := p

	if ac != nil {
		resp, err := s.callAgent(agentID, protocol.Request{Op: "list", Path: p}, 30*time.Second)
		if err != nil {
			listErr = err.Error()
		} else if !resp.Ok {
			listErr = resp.Err
		} else {
			var result protocol.ListResult
			if err := json.Unmarshal(resp.Result, &result); err != nil {
				listErr = "failed to parse file list"
			} else {
				currentPath = cleanRemotePath(result.Path)
				for _, e := range result.Entries {
					entryPath := remoteJoin(currentPath, e.Name)
					entries = append(entries, browseEntry{
						Name:       e.Name,
						RelPath:    entryPath,
						IsDir:      e.IsDir,
						Size:       e.Size,
						ModTime:    time.Unix(e.ModTime, 0),
						IsFavorite: se.favorites[entryPath],
					})
				}
			}
		}
	}

	sort.Slice(entries, func(i, j int) bool {
		if entries[i].IsDir != entries[j].IsDir {
			return entries[i].IsDir
		}
		return strings.ToLower(entries[i].Name) < strings.ToLower(entries[j].Name)
	})

	var dirCount, fileCount int
	var totalSize int64
	for _, e := range entries {
		if e.IsDir {
			dirCount++
		} else {
			fileCount++
			totalSize += e.Size
		}
	}

	favorites := make([]string, 0, len(se.favorites))
	for f := range se.favorites {
		favorites = append(favorites, f)
	}
	sort.Strings(favorites)

	parent := remoteDir(currentPath)
	parentURL := "/browse?path=" + url.QueryEscape(parent)
	if parent == currentPath || currentPath == "" {
		parentURL = "/browse?path=" + url.QueryEscape(currentPath)
	}

	connInfo := s.agentInfo(r)
	serverSaved := r.URL.Query().Get("server_saved") == "1"

	tpl := template.Must(template.New("files.html").Funcs(fileTemplateFuncs()).ParseFS(tplFS, "templates/files.html"))
	data := pageFeatureFlags(ac)
	for k, v := range map[string]any{
		"Title":                 "LAN File Manager",
		"Theme":                 "dark",
		"Density":               "comfortable",
		"Path":                  currentPath,
		"CurrentPath":           currentPath,
		"HomePath":              defaultBrowsePath(ac, driveList),
		"Breadcrumbs":           breadcrumbsFor(currentPath),
		"PathParts":             pathPartsForTpl(currentPath),
		"IsRoot":                isRemoteRoot(currentPath),
		"ParentPath":            parent,
		"ParentPathURL":         parentURL,
		"Entries":               entries,
		"Dirs":                  legacyDirs(entries),
		"Files":                 legacyFiles(entries),
		"Drives":                driveList,
		"DirCount":              dirCount,
		"FileCount":             fileCount,
		"TotalSizeHuman":        humanBytes(totalSize),
		"HasAgent":              ac != nil,
		"HasFavorites":          len(favorites) > 0,
		"Favorites":             favorites,
		"IsFavorite":            se.favorites[currentPath],
		"AutoRefreshDrives":     true,
		"ConfirmBulkDelete":     true,
		"ShowHidden":            true,
		"ReadOnlyGlobal":        false,
		"CanAdmin":              true,
		"Host":                  agentHost(ac),
		"OS":                    agentOS(ac),
		"Arch":                  agentArch(ac),
		"AgentConnected":        ac != nil,
		"ShowStatusBar":         true,
		"ShowPathBreadcrumb":    true,
		"StatusText":            statusText(ac, agentID),
		"SelectedSystem":        agentID,
		"AgentServerURL":        connInfo.AgentServerURL,
		"AgentServerCandidates": connInfo.Candidates,
		"ServerLANIPs":          connInfo.LANIPs,
		"AgentConfigJSON":       connInfo.ConfigJSON,
		"AgentLaunchCommand":    connInfo.LaunchCommand,
		"ServerURLSaved":        serverSaved,
		"Error":                 listErr,
	} {
		data[k] = v
	}
	_ = tpl.Execute(w, data)
}

func statusText(ac *agentConn, agentID string) string {
	if ac == nil {
		return "offline"
	}
	d := time.Since(ac.since).Round(time.Second)
	return fmt.Sprintf("connected (%s ago) · %s", d, agentID)
}

func agentHost(ac *agentConn) string {
	if ac == nil {
		return ""
	}
	return ac.summary.Hostname
}

func agentOS(ac *agentConn) string {
	if ac == nil {
		return ""
	}
	return ac.summary.OS
}

func agentArch(ac *agentConn) string {
	if ac == nil {
		return ""
	}
	return ac.summary.Arch
}

// download streams a file from the selected agent to the HTTP client in
// fixed-size chunks. The previous implementation issued one "read" op,
// buffered the whole file in memory on both the agent and the server, then
// emitted it as a single WebSocket frame — which capped downloads at the
// frame size (8 MiB → 256 MiB, and even at 256 MiB the double-buffering
// caused OOM pressure on large files).
//
// The new path uses read_chunk: it asks the agent for one 4 MiB chunk at a
// time, decodes it, writes it to the HTTP ResponseWriter, flushes, and
// repeats until EOF. Memory pressure is bounded to one chunk per request,
// regardless of file size, and there is no WebSocket frame-size ceiling
// because no single response ever holds more than 4 MiB of payload.
//
// If the agent doesn't advertise files_read (or hasn't been upgraded to a
// build that supports read_chunk), the handler falls back to a single
// "read" call so old agents keep working.
func (s *server) download(w http.ResponseWriter, r *http.Request) {
	se, ok := s.requireSession(w, r)
	if !ok {
		return
	}
	p := requestPath(r, "path", "p")
	if p == "" {
		http.Error(w, "missing path", http.StatusBadRequest)
		return
	}
	agentID, ac := s.selectedAgentFor(se)
	if ac == nil {
		http.Error(w, "no agent", http.StatusBadRequest)
		return
	}

	const chunkBytes = 4 << 20 // 4 MiB raw → ~5.5 MiB base64

	// First chunk doubles as a size probe.
	firstResp, firstErr := s.callAgent(agentID,
		protocol.Request{Op: "read_chunk", Path: p, Offset: 0, Length: chunkBytes},
		60*time.Second)

	// Old agents reject "read_chunk" with "unknown op" or
	// "unsupported feature". Fall back to the legacy single-shot read.
	if firstErr != nil || !firstResp.Ok {
		errMsg := ""
		if firstErr != nil {
			errMsg = firstErr.Error()
		} else {
			errMsg = firstResp.Err
		}
		if strings.Contains(errMsg, "unknown op") || strings.Contains(errMsg, "unsupported feature") {
			s.downloadLegacy(w, agentID, p)
			return
		}
		http.Error(w, errMsg, http.StatusInternalServerError)
		return
	}

	var first protocol.ReadChunkResult
	if err := json.Unmarshal(firstResp.Result, &first); err != nil {
		http.Error(w, "parse error", http.StatusInternalServerError)
		return
	}

	name := remoteBase(first.Path)
	w.Header().Set("Content-Type", "application/octet-stream")
	w.Header().Set("Content-Disposition", fmt.Sprintf("attachment; filename=\"%s\"", safeFilename(name)))
	if first.Size > 0 {
		w.Header().Set("Content-Length", fmt.Sprintf("%d", first.Size))
	}
	w.Header().Set("X-Accel-Buffering", "no")

	flusher, _ := w.(http.Flusher)

	writeChunk := func(b64 string) bool {
		decoded, err := base64.StdEncoding.DecodeString(b64)
		if err != nil {
			log.Printf("download: chunk decode failed: %v", err)
			return false
		}
		if _, err := w.Write(decoded); err != nil {
			// Client closed the connection — abandon the download.
			return false
		}
		if flusher != nil {
			flusher.Flush()
		}
		return true
	}

	if !writeChunk(first.DataB64) {
		return
	}
	if first.EOF {
		return
	}

	offset := first.Offset + int64(first.Bytes)
	for {
		resp, err := s.callAgent(agentID,
			protocol.Request{Op: "read_chunk", Path: p, Offset: offset, Length: chunkBytes},
			60*time.Second)
		if err != nil {
			log.Printf("download: chunk read failed at offset %d: %v", offset, err)
			return
		}
		if !resp.Ok {
			log.Printf("download: agent rejected chunk at offset %d: %s", offset, resp.Err)
			return
		}
		var chunk protocol.ReadChunkResult
		if err := json.Unmarshal(resp.Result, &chunk); err != nil {
			log.Printf("download: chunk parse failed: %v", err)
			return
		}
		if chunk.Bytes <= 0 && chunk.EOF {
			return
		}
		if !writeChunk(chunk.DataB64) {
			return
		}
		if chunk.EOF {
			return
		}
		offset = chunk.Offset + int64(chunk.Bytes)
	}
}

// downloadLegacy is the pre-chunked fallback used only when the selected
// agent advertises files_read but doesn't implement read_chunk (older
// build). Bounded by the frame-size cap on the WebSocket.
func (s *server) downloadLegacy(w http.ResponseWriter, agentID, p string) {
	resp, err := s.callAgent(agentID, protocol.Request{Op: "read", Path: p}, 90*time.Second)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	if !resp.Ok {
		http.Error(w, resp.Err, http.StatusInternalServerError)
		return
	}
	var result protocol.ReadResult
	if err := json.Unmarshal(resp.Result, &result); err != nil {
		http.Error(w, "parse error", http.StatusInternalServerError)
		return
	}
	b, err := base64.StdEncoding.DecodeString(result.DataB64)
	if err != nil {
		http.Error(w, "decode error", http.StatusInternalServerError)
		return
	}
	name := remoteBase(result.Path)
	w.Header().Set("Content-Type", "application/octet-stream")
	w.Header().Set("Content-Disposition", fmt.Sprintf("attachment; filename=\"%s\"", safeFilename(name)))
	w.Header().Set("Content-Length", fmt.Sprintf("%d", len(b)))
	_, _ = w.Write(b)
}

func (s *server) view(w http.ResponseWriter, r *http.Request) {
	se, ok := s.requireSession(w, r)
	if !ok {
		return
	}
	p := requestPath(r, "path", "p")
	if p == "" {
		http.Error(w, "missing path", http.StatusBadRequest)
		return
	}
	agentID, ac := s.selectedAgentFor(se)
	if ac == nil {
		http.Error(w, "no agent", http.StatusBadRequest)
		return
	}
	ext := strings.ToLower(filepath.Ext(p))
	imageExts := map[string]bool{".jpg": true, ".jpeg": true, ".png": true, ".gif": true, ".bmp": true, ".webp": true}
	docExts := map[string]bool{
		".txt": true, ".md": true, ".html": true, ".htm": true, ".json": true,
		".xml": true, ".csv": true, ".log": true, ".ini": true, ".conf": true,
		".yaml": true, ".yml": true, ".go": true, ".js": true, ".ts": true,
		".css": true, ".py": true, ".sh": true, ".bat": true, ".ps1": true,
		".rs": true, ".c": true, ".h": true, ".cpp": true, ".hpp": true,
		".java": true, ".sql": true, ".php": true, ".rb": true, ".swift": true,
		".kt": true, ".r": true, ".m": true, ".mm": true, ".cs": true,
		".vb": true, ".fs": true, ".scala": true, ".pl": true, ".lua": true,
	}

	if imageExts[ext] {
		resp, err := s.callAgent(agentID, protocol.Request{Op: "read", Path: p}, 45*time.Second)
		if err != nil || !resp.Ok {
			http.Error(w, agentError(err, resp.Err), http.StatusInternalServerError)
			return
		}
		var result protocol.ReadResult
		if err := json.Unmarshal(resp.Result, &result); err != nil {
			http.Error(w, "parse error", http.StatusInternalServerError)
			return
		}
		b, err := base64.StdEncoding.DecodeString(result.DataB64)
		if err != nil {
			http.Error(w, "decode error", http.StatusInternalServerError)
			return
		}
		w.Header().Set("Content-Type", mimeByExt(ext))
		_, _ = w.Write(b)
		return
	}

	if docExts[ext] {
		http.Redirect(w, r, "/preview?path="+url.QueryEscape(p), http.StatusFound)
		return
	}

	http.Redirect(w, r, "/download?path="+url.QueryEscape(p), http.StatusFound)
}

func (s *server) preview(w http.ResponseWriter, r *http.Request) {
	se, ok := s.requireSession(w, r)
	if !ok {
		return
	}
	p := requestPath(r, "path", "p")
	if p == "" {
		http.Error(w, "missing path", http.StatusBadRequest)
		return
	}
	agentID, ac := s.selectedAgentFor(se)
	if ac == nil {
		http.Error(w, "no agent", http.StatusBadRequest)
		return
	}
	resp, err := s.callAgent(agentID, protocol.Request{Op: "preview", Path: p, MaxBytes: 256 * 1024}, 20*time.Second)
	if err != nil || !resp.Ok {
		http.Error(w, agentError(err, resp.Err), http.StatusInternalServerError)
		return
	}
	var result protocol.PreviewResult
	if err := json.Unmarshal(resp.Result, &result); err != nil {
		http.Error(w, "parse error", http.StatusInternalServerError)
		return
	}
	tpl := template.Must(template.ParseFS(tplFS, "templates/preview.html"))
	_ = tpl.Execute(w, map[string]any{
		"Title":     remoteBase(result.Path),
		"Path":      result.Path,
		"Content":   result.Content,
		"Truncated": result.Truncated,
	})
}

func (s *server) upload(w http.ResponseWriter, r *http.Request) {
	se, ok := s.requireSession(w, r)
	if !ok {
		return
	}
	if err := r.ParseMultipartForm(256 << 20); err != nil {
		http.Error(w, "bad upload", http.StatusBadRequest)
		return
	}

	destDir := firstFormValue(r, "dest", "path", "p")
	if destDir == "" {
		http.Error(w, "missing destination", http.StatusBadRequest)
		return
	}

	agentID, ac := s.selectedAgentFor(se)
	if ac == nil {
		http.Error(w, "no agent", http.StatusBadRequest)
		return
	}

	files := []*multipart.FileHeader{}
	if r.MultipartForm != nil {
		files = append(files, r.MultipartForm.File["file"]...)
	}
	if len(files) == 0 {
		http.Error(w, "missing file", http.StatusBadRequest)
		return
	}
	if len(files) > 64 {
		http.Error(w, "too many files in one upload", http.StatusBadRequest)
		return
	}

	var lastDest string
	for _, header := range files {
		file, err := header.Open()
		if err != nil {
			http.Error(w, "open upload error", http.StatusBadRequest)
			return
		}
		data, err := io.ReadAll(file)
		_ = file.Close()
		if err != nil {
			http.Error(w, "read error", http.StatusInternalServerError)
			return
		}
		lastDest = remoteJoin(destDir, remoteBase(header.Filename))
		if lastDest == "" {
			http.Error(w, "missing destination", http.StatusBadRequest)
			return
		}
		resp, err := s.callAgent(agentID, protocol.Request{
			Op:      "write",
			Path:    lastDest,
			DataB64: base64.StdEncoding.EncodeToString(data),
			Mkdirs:  true,
		}, 60*time.Second)
		if err != nil || !resp.Ok {
			http.Error(w, agentError(err, resp.Err), http.StatusInternalServerError)
			return
		}
	}
	http.Redirect(w, r, "/browse?path="+url.QueryEscape(remoteDir(lastDest)), http.StatusFound)
}

func (s *server) rename(w http.ResponseWriter, r *http.Request) {
	se, ok := s.requireSession(w, r)
	if !ok {
		return
	}
	_ = r.ParseForm()
	from := firstFormValue(r, "from", "oldPath", "path", "p")
	to := firstFormValue(r, "to", "newPath")
	if from == "" || to == "" {
		http.Error(w, "missing path", http.StatusBadRequest)
		return
	}
	if !isRemoteAbs(to) && !strings.ContainsAny(to, `/\\`) {
		to = remoteJoin(remoteDir(from), to)
	}
	agentID, ac := s.selectedAgentFor(se)
	if ac == nil {
		http.Error(w, "no agent", http.StatusBadRequest)
		return
	}
	resp, err := s.callAgent(agentID, protocol.Request{Op: "rename", Path: from, Path2: to}, 30*time.Second)
	if err != nil || !resp.Ok {
		http.Error(w, agentError(err, resp.Err), http.StatusInternalServerError)
		return
	}
	http.Redirect(w, r, "/browse?path="+url.QueryEscape(remoteDir(to)), http.StatusFound)
}

func (s *server) mkdir(w http.ResponseWriter, r *http.Request) {
	se, ok := s.requireSession(w, r)
	if !ok {
		return
	}
	_ = r.ParseForm()
	parent := firstFormValue(r, "path", "p")
	dir := firstFormValue(r, "dir", "name")
	if dir == "" {
		http.Error(w, "missing dir", http.StatusBadRequest)
		return
	}
	if !isRemoteAbs(dir) {
		dir = remoteJoin(parent, dir)
	}
	agentID, ac := s.selectedAgentFor(se)
	if ac == nil {
		http.Error(w, "no agent", http.StatusBadRequest)
		return
	}
	resp, err := s.callAgent(agentID, protocol.Request{Op: "mkdir", Path: dir, Mkdirs: true}, 30*time.Second)
	if err != nil || !resp.Ok {
		http.Error(w, agentError(err, resp.Err), http.StatusInternalServerError)
		return
	}
	http.Redirect(w, r, "/browse?path="+url.QueryEscape(remoteDir(dir)), http.StatusFound)
}

func (s *server) deleteOne(w http.ResponseWriter, r *http.Request) {
	se, ok := s.requireSession(w, r)
	if !ok {
		return
	}
	_ = r.ParseForm()
	p := firstFormValue(r, "path", "p")
	if p == "" {
		http.Error(w, "missing path", http.StatusBadRequest)
		return
	}
	agentID, ac := s.selectedAgentFor(se)
	if ac == nil {
		http.Error(w, "no agent", http.StatusBadRequest)
		return
	}
	resp, err := s.callAgent(agentID, protocol.Request{Op: "rm", Path: p, Recursive: true}, 30*time.Second)
	if err != nil || !resp.Ok {
		http.Error(w, agentError(err, resp.Err), http.StatusInternalServerError)
		return
	}
	http.Redirect(w, r, "/browse?path="+url.QueryEscape(remoteDir(p)), http.StatusFound)
}

func (s *server) bulkDelete(w http.ResponseWriter, r *http.Request) {
	se, ok := s.requireSession(w, r)
	if !ok || r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var body struct {
		Paths []string `json:"paths"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		http.Error(w, "bad body", http.StatusBadRequest)
		return
	}
	if len(body.Paths) == 0 {
		http.Error(w, "no paths", http.StatusBadRequest)
		return
	}
	agentID, ac := s.selectedAgentFor(se)
	if ac == nil {
		http.Error(w, "no agent", http.StatusBadRequest)
		return
	}
	var success int
	for _, p := range body.Paths {
		resp, err := s.callAgent(agentID, protocol.Request{Op: "rm", Path: p, Recursive: true}, 30*time.Second)
		if err == nil && resp.Ok {
			success++
		}
	}
	writeJSON(w, map[string]any{"success": success, "total": len(body.Paths)})
}

func (s *server) zipDownload(w http.ResponseWriter, r *http.Request) {
	se, ok := s.requireSession(w, r)
	if !ok {
		return
	}
	p := requestPath(r, "path", "p")
	if p == "" {
		http.Error(w, "missing path", http.StatusBadRequest)
		return
	}
	agentID, ac := s.selectedAgentFor(se)
	if ac == nil {
		http.Error(w, "no agent", http.StatusBadRequest)
		return
	}

	if !s.agentSupportsFeature(ac, "files_read") && !s.agentSupportsFeature(ac, "archive") {
		http.Error(w, "selected agent does not support ZIP/download", http.StatusBadRequest)
		return
	}

	var b []byte
	if s.agentSupportsFeature(ac, "archive") {
		resp, err := s.callAgent(agentID, protocol.Request{Op: "zip", Paths: []string{p}}, 120*time.Second)
		if err != nil || !resp.Ok {
			http.Error(w, agentError(err, resp.Err), http.StatusInternalServerError)
			return
		}
		var result protocol.ReadResult
		if err := json.Unmarshal(resp.Result, &result); err != nil {
			http.Error(w, "parse error", http.StatusInternalServerError)
			return
		}
		decoded, decodeErr := base64.StdEncoding.DecodeString(result.DataB64)
		if decodeErr != nil {
			http.Error(w, "decode error", http.StatusInternalServerError)
			return
		}
		b = decoded
	} else {
		serverZip, _, zipErr := s.serverSideZip(agentID, []string{p})
		if zipErr != nil {
			http.Error(w, zipErr.Error(), http.StatusInternalServerError)
			return
		}
		b = serverZip
	}
	filename := safeFilename(remoteBase(p)) + ".zip"
	w.Header().Set("Content-Type", "application/zip")
	w.Header().Set("Content-Disposition", contentDispositionAttachment(filename))
	w.Header().Set("Content-Length", fmt.Sprint(len(b)))
	_, _ = w.Write(b)
}

func (s *server) bulkZip(w http.ResponseWriter, r *http.Request) {
	se, ok := s.requireSession(w, r)
	if !ok || r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var body struct {
		Paths []string `json:"paths"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		http.Error(w, "bad body", http.StatusBadRequest)
		return
	}
	cleaned := make([]string, 0, len(body.Paths))
	for _, p := range body.Paths {
		if cp := cleanRemotePath(p); cp != "" {
			cleaned = append(cleaned, cp)
		}
	}
	if len(cleaned) == 0 {
		http.Error(w, "no paths", http.StatusBadRequest)
		return
	}
	if len(cleaned) > 256 {
		http.Error(w, "too many selected paths", http.StatusBadRequest)
		return
	}
	agentID, ac := s.selectedAgentFor(se)
	if ac == nil {
		http.Error(w, "no agent", http.StatusBadRequest)
		return
	}

	if !s.agentSupportsFeature(ac, "files_read") && !s.agentSupportsFeature(ac, "archive") {
		http.Error(w, "selected agent does not support ZIP/download", http.StatusBadRequest)
		return
	}

	var b []byte
	if s.agentSupportsFeature(ac, "archive") {
		resp, err := s.callAgent(agentID, protocol.Request{Op: "zip", Paths: cleaned}, 300*time.Second)
		if err != nil || !resp.Ok {
			http.Error(w, agentError(err, resp.Err), http.StatusInternalServerError)
			return
		}
		var result protocol.ReadResult
		if err := json.Unmarshal(resp.Result, &result); err != nil {
			http.Error(w, "parse error", http.StatusInternalServerError)
			return
		}
		decoded, decodeErr := base64.StdEncoding.DecodeString(result.DataB64)
		if decodeErr != nil {
			http.Error(w, "decode error", http.StatusInternalServerError)
			return
		}
		b = decoded
	} else {
		serverZip, _, zipErr := s.serverSideZip(agentID, cleaned)
		if zipErr != nil {
			http.Error(w, zipErr.Error(), http.StatusInternalServerError)
			return
		}
		b = serverZip
	}
	tag := "selected"
	if len(cleaned) == 1 {
		tag = remoteBase(cleaned[0])
	}
	tag = tag + "_" + nowTag()
	filename := safeFilename(tag) + ".zip"
	w.Header().Set("Content-Type", "application/zip")
	w.Header().Set("Content-Disposition", contentDispositionAttachment(filename))
	w.Header().Set("Content-Length", fmt.Sprint(len(b)))
	_, _ = w.Write(b)
}

// Favorites
func (s *server) favAdd(w http.ResponseWriter, r *http.Request) {
	se, ok := s.requireSession(w, r)
	if !ok {
		return
	}
	p := favoritePathFromRequest(r)
	if p == "" {
		http.Error(w, "missing path", http.StatusBadRequest)
		return
	}
	se.favorites[p] = true
	if r.Method == http.MethodGet {
		http.Redirect(w, r, "/browse?path="+url.QueryEscape(p), http.StatusFound)
		return
	}
	writeJSON(w, map[string]any{"ok": true})
}

func (s *server) favRemove(w http.ResponseWriter, r *http.Request) {
	se, ok := s.requireSession(w, r)
	if !ok {
		return
	}
	p := favoritePathFromRequest(r)
	if p == "" {
		http.Error(w, "missing path", http.StatusBadRequest)
		return
	}
	delete(se.favorites, p)
	if r.Method == http.MethodGet {
		http.Redirect(w, r, "/browse?path="+url.QueryEscape(p), http.StatusFound)
		return
	}
	writeJSON(w, map[string]any{"ok": true})
}

func favoritePathFromRequest(r *http.Request) string {
	if r.Method == http.MethodPost && strings.Contains(r.Header.Get("Content-Type"), "application/json") {
		var body struct {
			Path string `json:"path"`
		}
		if err := json.NewDecoder(r.Body).Decode(&body); err == nil {
			return cleanRemotePath(body.Path)
		}
	}
	_ = r.ParseForm()
	return cleanRemotePath(firstFormValue(r, "path", "p"))
}

// template and path helpers
func fileTemplateFuncs() template.FuncMap {
	return template.FuncMap{
		"fileicon":   fileIcon,
		"humanbytes": humanBytes,
	}
}

func requestPath(r *http.Request, names ...string) string {
	return cleanRemotePath(firstFormValue(r, names...))
}

func firstFormValue(r *http.Request, names ...string) string {
	_ = r.ParseForm()
	for _, name := range names {
		if v := strings.TrimSpace(r.FormValue(name)); v != "" {
			return v
		}
	}
	return ""
}

func defaultBrowsePath(ac *agentConn, drives []drive) string {
	if ac != nil && len(ac.summary.Roots) > 0 && strings.TrimSpace(ac.summary.Roots[0]) != "" {
		return cleanRemotePath(ac.summary.Roots[0])
	}
	if len(drives) > 0 && strings.TrimSpace(drives[0].Path) != "" {
		return cleanRemotePath(drives[0].Path)
	}
	return "/"
}

func isWindowsAbs(p string) bool {
	return len(p) >= 3 && ((p[0] >= 'A' && p[0] <= 'Z') || (p[0] >= 'a' && p[0] <= 'z')) && p[1] == ':' && (p[2] == '\\' || p[2] == '/')
}

func isUNC(p string) bool {
	return strings.HasPrefix(p, `\\`) || strings.HasPrefix(p, `//`)
}

func looksWindowsPath(p string) bool {
	return isWindowsAbs(p) || isUNC(p) || strings.Contains(p, `\`)
}

func isRemoteAbs(p string) bool {
	p = strings.TrimSpace(p)
	return p == "/" || strings.HasPrefix(p, "/") || isWindowsAbs(p) || isUNC(p)
}

func cleanRemotePath(p string) string {
	p = strings.TrimSpace(p)
	if p == "" {
		return ""
	}
	if isWindowsAbs(p) {
		q := strings.ReplaceAll(p, "/", `\`)
		vol := q[:2]
		rest := strings.TrimLeft(q[2:], `\`)
		if rest == "" {
			return vol + `\`
		}
		clean := path.Clean("/" + strings.ReplaceAll(rest, `\`, "/"))
		clean = strings.Trim(clean, "/")
		if clean == "" || clean == "." {
			return vol + `\`
		}
		return vol + `\` + strings.ReplaceAll(clean, "/", `\`)
	}
	if isUNC(p) {
		q := strings.ReplaceAll(p, "/", `\`)
		prefix := `\\`
		q = strings.TrimLeft(q, `\`)
		parts := strings.Split(q, `\`)
		if len(parts) <= 2 {
			return prefix + strings.Join(parts, `\`)
		}
		rest := path.Clean("/" + strings.Join(parts[2:], "/"))
		rest = strings.Trim(rest, "/")
		if rest == "" || rest == "." {
			return prefix + strings.Join(parts[:2], `\`)
		}
		return prefix + strings.Join(parts[:2], `\`) + `\` + strings.ReplaceAll(rest, "/", `\`)
	}
	if strings.HasPrefix(p, "/") {
		return path.Clean(p)
	}
	return filepath.Clean(p)
}

func remoteJoin(dir, name string) string {
	dir = cleanRemotePath(dir)
	name = strings.TrimSpace(name)
	if name == "" {
		return dir
	}
	name = strings.TrimLeft(name, `/\\`)
	if dir == "" {
		return cleanRemotePath(name)
	}
	sep := "/"
	if looksWindowsPath(dir) {
		sep = `\`
	}
	d := strings.TrimRight(dir, `/\\`)
	if len(d) == 2 && d[1] == ':' {
		return cleanRemotePath(d + sep + name)
	}
	if d == "" && sep == "/" {
		return cleanRemotePath("/" + name)
	}
	return cleanRemotePath(d + sep + name)
}

func remoteDir(p string) string {
	p = cleanRemotePath(p)
	if p == "" || p == "/" {
		return p
	}
	if isWindowsAbs(p) {
		q := strings.TrimRight(p, `/\\`)
		if len(q) <= 2 {
			return q + `\`
		}
		idx := strings.LastIndexAny(q, `/\\`)
		if idx <= 2 {
			return q[:2] + `\`
		}
		return q[:idx]
	}
	if isUNC(p) {
		q := strings.TrimRight(p, `/\\`)
		idx := strings.LastIndexAny(q, `/\\`)
		if idx <= 1 {
			return q
		}
		return q[:idx]
	}
	if strings.HasPrefix(p, "/") {
		d := path.Dir(p)
		if d == "." {
			return "/"
		}
		return d
	}
	return filepath.Dir(p)
}

func remoteBase(p string) string {
	p = strings.TrimRight(cleanRemotePath(p), `/\\`)
	if p == "" || p == "/" {
		return p
	}
	idx := strings.LastIndexAny(p, `/\\`)
	if idx >= 0 && idx+1 < len(p) {
		return p[idx+1:]
	}
	return p
}

func isRemoteRoot(p string) bool {
	p = cleanRemotePath(p)
	if p == "/" || p == "" {
		return true
	}
	return isWindowsAbs(p) && len(strings.TrimRight(p, `/\\`)) == 2
}

func breadcrumbsFor(p string) []breadcrumb {
	p = cleanRemotePath(p)
	if p == "" {
		return nil
	}
	if isWindowsAbs(p) {
		q := strings.TrimRight(p, `/\\`)
		root := q[:2] + `\`
		out := []breadcrumb{{Label: q[:2], RelPath: root}}
		rest := strings.Trim(q[2:], `/\\`)
		cur := root
		for _, part := range strings.FieldsFunc(rest, func(r rune) bool { return r == '/' || r == '\\' }) {
			if part == "" {
				continue
			}
			cur = remoteJoin(cur, part)
			out = append(out, breadcrumb{Label: part, RelPath: cur})
		}
		return out
	}
	if strings.HasPrefix(p, "/") {
		out := []breadcrumb{{Label: "/", RelPath: "/"}}
		cur := "/"
		for _, part := range strings.Split(strings.Trim(p, "/"), "/") {
			if part == "" {
				continue
			}
			cur = path.Join(cur, part)
			out = append(out, breadcrumb{Label: part, RelPath: cur})
		}
		return out
	}
	return []breadcrumb{{Label: p, RelPath: p}}
}

func pathPartsForTpl(p string) []pathPart {
	bs := breadcrumbsFor(p)
	out := make([]pathPart, 0, len(bs))
	for i, b := range bs {
		out = append(out, pathPart{Label: b.Label, Segment: b.RelPath, IsLast: i == len(bs)-1, Disabled: false})
	}
	return out
}

func urlPath(p string) string {
	return cleanRemotePath(p)
}

func mimeByExt(ext string) string {
	m := mime.TypeByExtension(ext)
	if m != "" {
		return m
	}
	switch ext {
	case ".jpg", ".jpeg":
		return "image/jpeg"
	case ".png":
		return "image/png"
	case ".gif":
		return "image/gif"
	case ".bmp":
		return "image/bmp"
	case ".webp":
		return "image/webp"
	default:
		return "application/octet-stream"
	}
}

func humanBytes(n int64) string {
	if n < 0 {
		return "-"
	}
	const unit = 1024
	if n < unit {
		return fmt.Sprintf("%d B", n)
	}
	div, exp := int64(unit), 0
	for n >= div && exp < 4 {
		div *= unit
		exp++
	}
	return fmt.Sprintf("%.1f %cB", float64(n)/(float64(div)/unit), "KMGT"[exp-1])
}

func fileIcon(name string) string {
	switch strings.ToLower(filepath.Ext(name)) {
	case ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".ico", ".svg":
		return "fa-file-image"
	case ".mp4", ".mkv", ".avi", ".mov", ".wmv", ".webm":
		return "fa-file-video"
	case ".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a":
		return "fa-file-audio"
	case ".zip", ".rar", ".7z", ".tar", ".gz", ".bz2", ".xz":
		return "fa-file-zipper"
	case ".pdf":
		return "fa-file-pdf"
	case ".doc", ".docx", ".rtf", ".odt":
		return "fa-file-word"
	case ".xls", ".xlsx", ".csv", ".ods":
		return "fa-file-excel"
	case ".ppt", ".pptx", ".odp":
		return "fa-file-powerpoint"
	case ".go", ".js", ".ts", ".html", ".css", ".py", ".c", ".cpp", ".h", ".hpp", ".rs", ".java", ".cs", ".php", ".rb", ".sh", ".bat", ".ps1", ".json", ".xml", ".yaml", ".yml":
		return "fa-file-code"
	case ".txt", ".md", ".log", ".ini", ".conf":
		return "fa-file-lines"
	default:
		return "fa-file"
	}
}

func extClass(name string) string {
	ext := strings.ToLower(filepath.Ext(name))
	if ext == "" {
		return "file"
	}
	return "file-" + strings.TrimPrefix(ext, ".")
}

func legacyDirs(entries []browseEntry) []dirItem {
	out := []dirItem{}
	for _, e := range entries {
		if e.IsDir {
			out = append(out, dirItem{Name: e.Name, Href: "/browse?path=" + url.QueryEscape(e.RelPath), ModTime: e.ModTime.Format("2006-01-02 15:04"), IsDotDir: strings.HasPrefix(e.Name, "."), IsFavorite: e.IsFavorite})
		}
	}
	return out
}

func legacyFiles(entries []browseEntry) []fileItem {
	out := []fileItem{}
	for _, e := range entries {
		if !e.IsDir {
			out = append(out, fileItem{Name: e.Name, Href: "/download?path=" + url.QueryEscape(e.RelPath), ViewHref: "/view?path=" + url.QueryEscape(e.RelPath), SizeHuman: humanBytes(e.Size), ModTime: e.ModTime.Format("2006-01-02 15:04"), IsDotFile: strings.HasPrefix(e.Name, "."), Ext: extClass(e.Name), IsFavorite: e.IsFavorite})
		}
	}
	return out
}

func nowTag() string {
	t := time.Now()
	buf := make([]byte, 6)
	_, _ = rand.Read(buf)
	return fmt.Sprintf("%s-%s", t.Format("20060102-150405"), hex.EncodeToString(buf)[:6])
}

type dirItem struct {
	Name       string
	Href       string
	ModTime    string
	IsDotDir   bool
	IsFavorite bool
}

type fileItem struct {
	Name       string
	Href       string
	ViewHref   string
	SizeHuman  string
	ModTime    string
	IsDotFile  bool
	Ext        string
	IsFavorite bool
}

type pathPart struct {
	Label    string
	Segment  string
	IsLast   bool
	Disabled bool
}
