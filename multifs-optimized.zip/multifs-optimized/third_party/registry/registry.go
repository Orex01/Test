//go:build windows
// +build windows

// Package registry provides a minimal subset of Windows registry APIs.
// This replaces golang.org/x/sys/windows/registry to reduce external dependencies.
package registry

import (
	"encoding/binary"
	"syscall"
	"unsafe"
)

type Key syscall.Handle

const (
	CLASSES_ROOT   = Key(syscall.HKEY_CLASSES_ROOT)
	CURRENT_USER   = Key(syscall.HKEY_CURRENT_USER)
	LOCAL_MACHINE  = Key(syscall.HKEY_LOCAL_MACHINE)
	USERS          = Key(syscall.HKEY_USERS)
	CURRENT_CONFIG = Key(syscall.HKEY_CURRENT_CONFIG)

	QUERY_VALUE        = syscall.KEY_QUERY_VALUE
	SET_VALUE          = syscall.KEY_SET_VALUE
	ENUMERATE_SUB_KEYS = syscall.KEY_ENUMERATE_SUB_KEYS
	READ               = syscall.KEY_READ
	WRITE              = syscall.KEY_WRITE

	NONE      = syscall.REG_NONE
	SZ        = syscall.REG_SZ
	EXPAND_SZ = syscall.REG_EXPAND_SZ
	BINARY    = syscall.REG_BINARY
	DWORD     = syscall.REG_DWORD
	QWORD     = syscall.REG_QWORD
	MULTI_SZ  = syscall.REG_MULTI_SZ
)

const errorNoMoreItems syscall.Errno = 259

var (
	modadvapi32         = syscall.NewLazyDLL("advapi32.dll")
	procRegDeleteKeyW   = modadvapi32.NewProc("RegDeleteKeyW")
	procRegDeleteValueW = modadvapi32.NewProc("RegDeleteValueW")
	procRegEnumValueW   = modadvapi32.NewProc("RegEnumValueW")
	procRegSetValueExW  = modadvapi32.NewProc("RegSetValueExW")
)

func OpenKey(k Key, path string, access uint32) (Key, error) {
	p, err := syscall.UTF16PtrFromString(path)
	if err != nil {
		return 0, err
	}
	var h syscall.Handle
	if err := syscall.RegOpenKeyEx(syscall.Handle(k), p, 0, access, &h); err != nil {
		return 0, err
	}
	return Key(h), nil
}

func (k Key) Close() error {
	return syscall.RegCloseKey(syscall.Handle(k))
}

func (k Key) ReadSubKeyNames(n int) ([]string, error) {
	var subkeysLen, maxSubKeyLen uint32
	if err := syscall.RegQueryInfoKey(syscall.Handle(k), nil, nil, nil, &subkeysLen, &maxSubKeyLen, nil, nil, nil, nil, nil, nil); err != nil {
		return nil, err
	}
	limit := int(subkeysLen)
	if n >= 0 && n < limit {
		limit = n
	}
	out := make([]string, 0, limit)
	nameCap := maxSubKeyLen + 1
	if nameCap < 256 {
		nameCap = 256
	}
	for i := uint32(0); i < subkeysLen && len(out) < limit; i++ {
		buf := make([]uint16, nameCap)
		l := uint32(len(buf))
		if err := syscall.RegEnumKeyEx(syscall.Handle(k), i, &buf[0], &l, nil, nil, nil, nil); err != nil {
			if err == errorNoMoreItems {
				break
			}
			continue
		}
		out = append(out, syscall.UTF16ToString(buf[:l]))
	}
	return out, nil
}

func (k Key) ReadValueNames(n int) ([]string, error) {
	var valuesLen, maxValueNameLen uint32
	if err := syscall.RegQueryInfoKey(syscall.Handle(k), nil, nil, nil, nil, nil, nil, &valuesLen, &maxValueNameLen, nil, nil, nil); err != nil {
		return nil, err
	}
	limit := int(valuesLen)
	if n >= 0 && n < limit {
		limit = n
	}
	out := make([]string, 0, limit)
	nameCap := maxValueNameLen + 1
	if nameCap < 256 {
		nameCap = 256
	}
	for i := uint32(0); i < valuesLen && len(out) < limit; i++ {
		buf := make([]uint16, nameCap)
		l := uint32(len(buf))
		if err := regEnumValue(syscall.Handle(k), i, &buf[0], &l, nil, nil, nil, nil); err != nil {
			if err == errorNoMoreItems {
				break
			}
			continue
		}
		out = append(out, syscall.UTF16ToString(buf[:l]))
	}
	return out, nil
}

func (k Key) GetStringValue(name string) (string, uint32, error) {
	data, typ, err := k.getValue(name)
	if err != nil {
		return "", typ, err
	}
	if typ != SZ && typ != EXPAND_SZ && typ != MULTI_SZ {
		return "", typ, syscall.EINVAL
	}
	return utf16BytesToString(data), typ, nil
}

func (k Key) GetBinaryValue(name string) ([]byte, uint32, error) {
	return k.getValue(name)
}

func (k Key) GetIntegerValue(name string) (uint64, uint32, error) {
	data, typ, err := k.getValue(name)
	if err != nil {
		return 0, typ, err
	}
	switch typ {
	case DWORD:
		if len(data) < 4 {
			return 0, typ, syscall.EINVAL
		}
		return uint64(binary.LittleEndian.Uint32(data[:4])), typ, nil
	case QWORD:
		if len(data) < 8 {
			return 0, typ, syscall.EINVAL
		}
		return binary.LittleEndian.Uint64(data[:8]), typ, nil
	default:
		return 0, typ, syscall.EINVAL
	}
}

func (k Key) SetStringValue(name, value string) error {
	namep, err := syscall.UTF16PtrFromString(name)
	if err != nil {
		return err
	}
	val, err := syscall.UTF16FromString(value)
	if err != nil {
		return err
	}
	var bp *byte
	if len(val) > 0 {
		bp = (*byte)(unsafe.Pointer(&val[0]))
	}
	return regSetValueEx(syscall.Handle(k), namep, 0, SZ, bp, uint32(len(val)*2))
}

func (k Key) DeleteValue(name string) error {
	namep, err := syscall.UTF16PtrFromString(name)
	if err != nil {
		return err
	}
	return regDeleteValue(syscall.Handle(k), namep)
}

func DeleteKey(k Key, subkey string) error {
	p, err := syscall.UTF16PtrFromString(subkey)
	if err != nil {
		return err
	}
	return regDeleteKey(syscall.Handle(k), p)
}

func (k Key) getValue(name string) ([]byte, uint32, error) {
	namep, err := syscall.UTF16PtrFromString(name)
	if err != nil {
		return nil, 0, err
	}
	var typ uint32
	var size uint32
	err = syscall.RegQueryValueEx(syscall.Handle(k), namep, nil, &typ, nil, &size)
	if err != nil && err != syscall.ERROR_MORE_DATA {
		return nil, typ, err
	}
	if size == 0 {
		return []byte{}, typ, nil
	}
	buf := make([]byte, size)
	err = syscall.RegQueryValueEx(syscall.Handle(k), namep, nil, &typ, &buf[0], &size)
	if err != nil {
		return nil, typ, err
	}
	if int(size) < len(buf) {
		buf = buf[:size]
	}
	return buf, typ, nil
}

func utf16BytesToString(b []byte) string {
	if len(b)%2 == 1 {
		b = b[:len(b)-1]
	}
	u := make([]uint16, len(b)/2)
	for i := range u {
		u[i] = binary.LittleEndian.Uint16(b[i*2:])
	}
	return syscall.UTF16ToString(u)
}

func regDeleteKey(key syscall.Handle, subkey *uint16) error {
	r0, _, _ := procRegDeleteKeyW.Call(uintptr(key), uintptr(unsafe.Pointer(subkey)))
	if r0 != 0 {
		return syscall.Errno(r0)
	}
	return nil
}

func regDeleteValue(key syscall.Handle, name *uint16) error {
	r0, _, _ := procRegDeleteValueW.Call(uintptr(key), uintptr(unsafe.Pointer(name)))
	if r0 != 0 {
		return syscall.Errno(r0)
	}
	return nil
}

func regEnumValue(key syscall.Handle, index uint32, name *uint16, nameLen *uint32, reserved *uint32, valtype *uint32, buf *byte, buflen *uint32) error {
	r0, _, _ := procRegEnumValueW.Call(
		uintptr(key),
		uintptr(index),
		uintptr(unsafe.Pointer(name)),
		uintptr(unsafe.Pointer(nameLen)),
		uintptr(unsafe.Pointer(reserved)),
		uintptr(unsafe.Pointer(valtype)),
		uintptr(unsafe.Pointer(buf)),
		uintptr(unsafe.Pointer(buflen)),
	)
	if r0 != 0 {
		return syscall.Errno(r0)
	}
	return nil
}

func regSetValueEx(key syscall.Handle, valueName *uint16, reserved uint32, vtype uint32, buf *byte, bufsize uint32) error {
	r0, _, _ := procRegSetValueExW.Call(
		uintptr(key),
		uintptr(unsafe.Pointer(valueName)),
		uintptr(reserved),
		uintptr(vtype),
		uintptr(unsafe.Pointer(buf)),
		uintptr(bufsize),
	)
	if r0 != 0 {
		return syscall.Errno(r0)
	}
	return nil
}
