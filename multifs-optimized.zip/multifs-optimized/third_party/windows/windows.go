//go:build windows
// +build windows

// Package windows provides a minimal subset of Windows APIs.
// This replaces golang.org/x/sys/windows to reduce binary size and external dependencies.
package windows

import (
	"syscall"
	"unsafe"
)

type Handle = syscall.Handle
type Token = syscall.Token
type SID = syscall.SID

type LUID struct {
	LowPart  uint32
	HighPart int32
}

type LUIDAndAttributes struct {
	Luid       LUID
	Attributes uint32
}

type Tokenprivileges struct {
	PrivilegeCount uint32
	Privileges     [1]LUIDAndAttributes
}

type SIDAndAttributes = syscall.SIDAndAttributes
type Tokenuser = syscall.Tokenuser

const (
	InvalidHandle = syscall.InvalidHandle

	TOKEN_ADJUST_PRIVILEGES = syscall.TOKEN_ADJUST_PRIVILEGES
	TOKEN_QUERY             = syscall.TOKEN_QUERY
	SE_PRIVILEGE_ENABLED    = 0x00000002

	TokenUser = syscall.TokenUser
)

var (
	modadvapi32               = syscall.NewLazyDLL("advapi32.dll")
	procLookupPrivilegeValueW = modadvapi32.NewProc("LookupPrivilegeValueW")
	procAdjustTokenPrivileges = modadvapi32.NewProc("AdjustTokenPrivileges")
)

func UTF16PtrFromString(s string) (*uint16, error) {
	return syscall.UTF16PtrFromString(s)
}

func CurrentProcess() Handle {
	h, _ := syscall.GetCurrentProcess()
	return h
}

func OpenProcessToken(h Handle, access uint32, token *Token) error {
	return syscall.OpenProcessToken(h, access, token)
}

func LookupPrivilegeValue(systemName, name *uint16, luid *LUID) error {
	r1, _, err := procLookupPrivilegeValueW.Call(
		uintptr(unsafe.Pointer(systemName)),
		uintptr(unsafe.Pointer(name)),
		uintptr(unsafe.Pointer(luid)),
	)
	if r1 == 0 {
		if err != syscall.Errno(0) {
			return err
		}
		return syscall.EINVAL
	}
	return nil
}

func AdjustTokenPrivileges(token Token, disableAllPrivileges bool, newState *Tokenprivileges, bufferLength uint32, previousState *Tokenprivileges, returnLength *uint32) error {
	var disable uintptr
	if disableAllPrivileges {
		disable = 1
	}
	r1, _, err := procAdjustTokenPrivileges.Call(
		uintptr(token),
		disable,
		uintptr(unsafe.Pointer(newState)),
		uintptr(bufferLength),
		uintptr(unsafe.Pointer(previousState)),
		uintptr(unsafe.Pointer(returnLength)),
	)
	if r1 == 0 {
		if err != syscall.Errno(0) {
			return err
		}
		return syscall.EINVAL
	}
	return nil
}

func GetTokenInformation(t Token, infoClass uint32, info *byte, infoLen uint32, returnedLen *uint32) error {
	return syscall.GetTokenInformation(t, infoClass, info, infoLen, returnedLen)
}

func LookupAccountSid(systemName *uint16, sid *SID, name *uint16, nameLen *uint32, refdDomainName *uint16, refdDomainNameLen *uint32, use *uint32) error {
	return syscall.LookupAccountSid(systemName, sid, name, nameLen, refdDomainName, refdDomainNameLen, use)
}
