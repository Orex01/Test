# Windows EXE compatibility fix

The previous ultra-small Lite build used `/filealign:16`. That can produce a PE file that some Windows versions reject before startup with a blue dialog such as "This app can't run on your PC".

This package rebuilds the Lite native EXE with standard PE file alignment:

```text
/filealign:512
```

The EXE remains far below the 100 KB Lite target, but is safer for normal Windows loaders and endpoint policy.

Use the compatibility Lite binary by default:

```text
build/multifs-agent-lite-native.exe
dist/multifs-agent-lite-native.exe
```

The build scripts now enforce a 100 KB budget instead of the earlier experimental 25 KB budget. Size matters, but Windows compatibility takes priority over non-standard PE packing.
