@echo off
setlocal
echo This removes remembered MultiFS agent server targets on this user account.
echo It does not delete the agent executable.
echo.
if defined APPDATA (
  del /F /Q "%APPDATA%\MultiFS\last_server.txt" 2>nul
  del /F /Q "%APPDATA%\MultiFS\agent_config.json" 2>nul
)
del /F /Q "%USERPROFILE%\.multifs_last_server" 2>nul
del /F /Q "%~dp0last_server.txt" 2>nul
del /F /Q "%~dp0agent_config.json" 2>nul
echo Done. Now run RUN_AGENT.bat again.
pause
