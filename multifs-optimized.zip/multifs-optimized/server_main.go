//go:build !agent
// +build !agent

package main

import (
	"crypto/rand"
	"embed"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"html/template"
	"log"
	"net"
	"net/http"
	"os"
	"sort"
	"strings"
	"sync"
	"time"

	"multifs-advanced/internal/config"
	"multifs-advanced/internal/protocol"
	"multifs-advanced/internal/wsmini"
)

const (
	adminUsername     = config.DefaultAdminUsername
	sessionCookieName = "lfm_session"
)

//go:embed templates/*
var tplFS embed.FS

//go:embed static/*
var staticFS embed.FS

type wsConn struct {
	c  *wsmini.Conn
	mu sync.Mutex
}

func (w *wsConn) sendJSON(v any) error {
	w.mu.Lock()
	defer w.mu.Unlock()
	if w.c == nil {
		return fmt.Errorf("websocket not connected")
	}
	_ = w.c.SetWriteDeadline(time.Now().Add(15 * time.Second))
	err := w.c.WriteJSON(v)
	_ = w.c.SetWriteDeadline(time.Time{})
	return err
}

type agentConn struct {
	id       string
	key      string
	ws       *wsConn
	summary  protocol.Hello
	since    time.Time
	remoteIP string

	pmu     sync.Mutex
	pending map[string]chan protocol.Response
}

type session struct {
	id            string
	username      string
	expires       time.Time
	selectedAgent string
	favorites     map[string]bool
}

type knownAgent struct {
	Key          string   `json:"key"`
	Name         string   `json:"name"`
	DisplayName  string   `json:"display_name"`
	Hostname     string   `json:"hostname"`
	OS           string   `json:"os"`
	Arch         string   `json:"arch"`
	Version      string   `json:"version"`
	Build        string   `json:"build,omitempty"`
	Capabilities []string `json:"capabilities,omitempty"`
	User         string   `json:"user"`
	Roots        []string `json:"roots"`
	LastSeenUTC  int64    `json:"last_seen_utc"`
	LastIP       string   `json:"last_ip"`
	Online       bool     `json:"online"`
}

type server struct {
	mu       sync.RWMutex
	sessions map[string]*session

	agentsMu sync.RWMutex
	agents   map[string]*agentConn

	knownMu sync.RWMutex
	known   map[string]*knownAgent
	dbPath  string

	configMu               sync.RWMutex
	configPath             string
	listenAddr             string
	agentServerURLOverride string
	sharedPassword         string

	httpSrv *http.Server
	ports   []string

	startedAt time.Time
}

func newServer() *server {
	s := &server{
		sessions:   make(map[string]*session),
		agents:     make(map[string]*agentConn),
		known:      make(map[string]*knownAgent),
		dbPath:     "agents_db.json",
		configPath: "server_config.json",
		ports:      []string{},
		startedAt:  time.Now().UTC(),
	}
	s.loadKnown()
	s.loadServerConfig()
	return s
}

func (s *server) loadKnown() {
	b, err := os.ReadFile(s.dbPath)
	if err != nil {
		return
	}
	var list []*knownAgent
	if err := json.Unmarshal(b, &list); err != nil {
		return
	}
	s.knownMu.Lock()
	defer s.knownMu.Unlock()
	for _, a := range list {
		if a == nil || a.Key == "" {
			continue
		}
		a.Online = false
		s.known[a.Key] = a
	}
}

func (s *server) saveKnown() {
	s.knownMu.RLock()
	list := make([]*knownAgent, 0, len(s.known))
	for _, a := range s.known {
		list = append(list, a)
	}
	s.knownMu.RUnlock()

	sort.Slice(list, func(i, j int) bool { return list[i].Key < list[j].Key })

	b, _ := json.MarshalIndent(list, "", "  ")
	tmp := s.dbPath + ".tmp"
	_ = os.WriteFile(tmp, b, 0o600)
	_ = os.Rename(tmp, s.dbPath)
}

func fallbackKey(h protocol.Hello) string {
	base := strings.ToLower(h.Hostname + "|" + h.User + "|" + h.OS + "|" + h.Arch)
	if base == "|||" {
		base = "unknown"
	}
	return "legacy:" + base
}

func (s *server) upsertKnownFromHello(key string, h protocol.Hello, online bool) *knownAgent {
	now := time.Now().UTC().Unix()
	s.knownMu.Lock()
	defer s.knownMu.Unlock()
	a := s.known[key]
	if a == nil {
		a = &knownAgent{Key: key}
		s.known[key] = a
	}
	a.Name = h.Name
	if a.DisplayName == "" {
		a.DisplayName = h.Name
	}
	a.Hostname = h.Hostname
	a.OS = h.OS
	a.Arch = h.Arch
	a.User = h.User
	a.Version = h.Version
	a.Build = h.Build
	a.Capabilities = append([]string(nil), h.Capabilities...)
	a.Roots = h.Roots
	a.LastSeenUTC = now
	a.Online = online
	return a
}

func (s *server) setKnownIP(key string, ip string) {
	ip = strings.TrimSpace(ip)
	if key == "" || ip == "" {
		return
	}
	s.knownMu.Lock()
	defer s.knownMu.Unlock()
	if ka, ok := s.known[key]; ok && ka != nil {
		ka.LastIP = ip
	}
}

func (s *server) touchKnownByKey(key string) {
	now := time.Now().UTC().Unix()
	s.knownMu.Lock()
	defer s.knownMu.Unlock()
	for _, a := range s.known {
		if a.Key == key {
			a.LastSeenUTC = now
			a.Online = true
			return
		}
	}
}

func (s *server) markKnownOfflineByKey(key string) {
	s.knownMu.Lock()
	defer s.knownMu.Unlock()
	if a := s.known[key]; a != nil {
		a.Online = false
		a.LastSeenUTC = time.Now().UTC().Unix()
	}
}

// removeAgentConn deletes one live socket and returns true when another socket
// with the same persistent agent key is still connected.  This prevents an old
// duplicate connection from marking the shared UI record offline after a newer
// connection has already replaced it.
func (s *server) removeAgentConn(id string, key string) bool {
	s.agentsMu.Lock()
	delete(s.agents, id)
	hasOther := false
	for otherID, c := range s.agents {
		if otherID != id && c != nil && c.key == key && c.ws != nil && c.ws.c != nil {
			hasOther = true
			break
		}
	}
	s.agentsMu.Unlock()
	return hasOther
}

func (s *server) markKnownOfflineIfNoLiveConn(key string, hasOther bool) {
	if hasOther {
		s.touchKnownByKey(key)
		return
	}
	s.markKnownOfflineByKey(key)
}

func (s *server) getOnlineConnByKey(key string) *agentConn {
	s.agentsMu.RLock()
	defer s.agentsMu.RUnlock()
	var best *agentConn
	for _, c := range s.agents {
		if c == nil || c.key != key || c.ws == nil || c.ws.c == nil {
			continue
		}
		if best == nil || c.since.After(best.since) {
			best = c
		}
	}
	return best
}

func ipFromRemoteAddr(addr string) string {
	h, _, err := net.SplitHostPort(strings.TrimSpace(addr))
	if err != nil {
		return strings.TrimSpace(addr)
	}
	return h
}

func randID(n int) string {
	b := make([]byte, n)
	_, _ = rand.Read(b)
	return hex.EncodeToString(b)
}

func (s *server) getSession(r *http.Request) (*session, bool) {
	c, err := r.Cookie(sessionCookieName)
	if err != nil || c == nil || c.Value == "" {
		return nil, false
	}
	s.mu.RLock()
	se := s.sessions[c.Value]
	s.mu.RUnlock()
	if se == nil || time.Now().After(se.expires) {
		return nil, false
	}
	return se, true
}

func (s *server) requireSession(w http.ResponseWriter, r *http.Request) (*session, bool) {
	se, ok := s.getSession(r)
	if ok {
		return se, true
	}
	http.Redirect(w, r, "/login", http.StatusFound)
	return nil, false
}

func (s *server) loginPage(w http.ResponseWriter, r *http.Request) {
	tpl := template.Must(template.ParseFS(tplFS, "templates/login.html"))
	_ = tpl.Execute(w, map[string]any{
		"Title":   "LAN File Manager",
		"Message": "",
		"Error":   "",
	})
}

func (s *server) loginPost(w http.ResponseWriter, r *http.Request) {
	if err := r.ParseForm(); err != nil {
		http.Error(w, "bad form", http.StatusBadRequest)
		return
	}
	u := strings.TrimSpace(r.FormValue("username"))
	p := r.FormValue("password")

	if u != adminUsername || p != s.authPassword() {
		tpl := template.Must(template.ParseFS(tplFS, "templates/login.html"))
		_ = tpl.Execute(w, map[string]any{
			"Title":   "LAN File Manager",
			"Message": "",
			"Error":   "Invalid credentials",
		})
		return
	}

	id := randID(16)
	se := &session{
		id:        id,
		username:  adminUsername,
		expires:   time.Now().Add(12 * time.Hour),
		favorites: make(map[string]bool),
	}
	s.mu.Lock()
	s.sessions[id] = se
	s.mu.Unlock()

	http.SetCookie(w, &http.Cookie{
		Name:     sessionCookieName,
		Value:    id,
		Path:     "/",
		HttpOnly: true,
		SameSite: http.SameSiteLaxMode,
		Expires:  se.expires,
	})
	http.Redirect(w, r, "/", http.StatusFound)
}

func (s *server) logout(w http.ResponseWriter, r *http.Request) {
	c, _ := r.Cookie(sessionCookieName)
	if c != nil && c.Value != "" {
		s.mu.Lock()
		delete(s.sessions, c.Value)
		s.mu.Unlock()
	}
	http.SetCookie(w, &http.Cookie{
		Name:     sessionCookieName,
		Value:    "",
		Path:     "/",
		HttpOnly: true,
		Expires:  time.Unix(0, 0),
		MaxAge:   -1,
		SameSite: http.SameSiteLaxMode,
	})
	http.Redirect(w, r, "/login", http.StatusFound)
}

func (s *server) root(w http.ResponseWriter, r *http.Request) {
	if _, ok := s.requireSession(w, r); !ok {
		return
	}
	http.Redirect(w, r, "/browse", http.StatusFound)
}

// clientIP extracts the real client IP from request headers.
func clientIP(r *http.Request) string {
	xff := strings.TrimSpace(r.Header.Get("X-Forwarded-For"))
	if xff != "" {
		parts := strings.Split(xff, ",")
		if len(parts) > 0 {
			if ip := strings.TrimSpace(parts[0]); ip != "" {
				return ip
			}
		}
	}
	xri := strings.TrimSpace(r.Header.Get("X-Real-IP"))
	if xri != "" {
		return xri
	}
	host, _, err := net.SplitHostPort(strings.TrimSpace(r.RemoteAddr))
	if err == nil && host != "" {
		return host
	}
	return strings.TrimSpace(r.RemoteAddr)
}

func (s *server) agentWS(w http.ResponseWriter, r *http.Request) {
	providedPassword := r.Header.Get("X-LFM-Password")
	if providedPassword != s.authPassword() {
		log.Printf("agent authentication failed from %s", r.RemoteAddr)
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	c, err := wsmini.Accept(w, r)
	if err != nil {
		log.Printf("websocket upgrade failed from %s: %v", r.RemoteAddr, err)
		return
	}
	ws := &wsConn{c: c}

	_ = c.SetReadDeadline(time.Now().Add(10 * time.Second))
	_, helloMsg, err := c.ReadMessage()
	if err != nil {
		log.Printf("failed to read hello from %s: %v", r.RemoteAddr, err)
		_ = c.Close()
		return
	}
	_ = c.SetReadDeadline(time.Time{})

	var hello protocol.Hello
	if err := json.Unmarshal(helloMsg, &hello); err != nil || hello.Type != "hello" {
		log.Printf("invalid hello message from %s", r.RemoteAddr)
		_ = c.Close()
		return
	}

	key := strings.TrimSpace(hello.Key)
	if key == "" {
		key = fallbackKey(hello)
	}

	id := randID(8)
	ac := &agentConn{
		id:       id,
		key:      key,
		ws:       ws,
		summary:  hello,
		since:    time.Now().UTC(),
		remoteIP: clientIP(r),
		pending:  make(map[string]chan protocol.Response),
	}

	type oldAgentSocket struct {
		id string
		ac *agentConn
	}
	var duplicates []oldAgentSocket
	s.agentsMu.Lock()
	for otherID, other := range s.agents {
		if other != nil && other.key == key {
			duplicates = append(duplicates, oldAgentSocket{id: otherID, ac: other})
			delete(s.agents, otherID)
		}
	}
	s.agents[id] = ac
	s.agentsMu.Unlock()

	// Keep the newest socket for a persistent agent key. Older duplicate sockets
	// must be captured before deletion from the live map; otherwise getAgent()
	// cannot find them and they keep running until their next timeout.
	for _, old := range duplicates {
		if old.ac != nil && old.ac.ws != nil && old.ac.ws.c != nil {
			log.Printf("closing older duplicate connection id=%s for key=%s after new id=%s", old.id, key, id)
			_ = old.ac.ws.c.Close()
		}
	}

	s.upsertKnownFromHello(key, hello, true)
	s.setKnownIP(key, ac.remoteIP)
	s.saveKnown()

	log.Printf("agent connected id=%s name=%s host=%s", id, hello.Name, hello.Hostname)

	// Server → agent keepalive. The agent's read loop carries a 5-minute
	// deadline; without traffic from the server it would tear the WebSocket
	// down during idle periods. We send a tiny "hb_srv" envelope every 45
	// seconds — well below the agent deadline — so an unused agent stays
	// connected indefinitely. The agent silently ignores unknown envelopes.
	stopKA := make(chan struct{})
	go func() {
		t := time.NewTicker(45 * time.Second)
		defer t.Stop()
		for {
			select {
			case <-stopKA:
				return
			case <-t.C:
				if ws == nil || ws.c == nil {
					return
				}
				if err := ws.sendJSON(map[string]any{"type": "hb_srv", "ts": time.Now().Unix()}); err != nil {
					// Write error means the socket is gone; let the read loop
					// observe and tear down.
					return
				}
			}
		}
	}()

	go func() {
		defer func() {
			close(stopKA)
			hasOther := s.removeAgentConn(id, ac.key)
			s.markKnownOfflineIfNoLiveConn(ac.key, hasOther)
			s.saveKnown()
			_ = c.Close()
			if hasOther {
				log.Printf("agent connection closed id=%s key=%s; another live connection remains", id, ac.key)
			} else {
				log.Printf("agent disconnected id=%s key=%s", id, ac.key)
			}
		}()

		for {
			// 5-minute idle ceiling. The agent sends "hb" every 60 s; we send
			// "hb_srv" every 45 s; either keeps this deadline rolling. Five
			// minutes provides headroom for transient network hiccups while
			// still surfacing genuinely dead connections.
			_ = c.SetReadDeadline(time.Now().Add(300 * time.Second))
			_, msg, err := c.ReadMessage()
			if err != nil {
				log.Printf("agent read loop ended id=%s key=%s remote=%s err=%v", id, ac.key, ac.remoteIP, err)
				return
			}
			_ = c.SetReadDeadline(time.Time{})

			var tmsg struct {
				Type string `json:"type"`
				ID   string `json:"id"`
			}
			if err := json.Unmarshal(msg, &tmsg); err != nil {
				continue
			}
			if tmsg.Type == "hb" {
				s.touchKnownByKey(ac.key)
				continue
			}

			switch tmsg.Type {
			case "resp":
				var resp protocol.Response
				if err := json.Unmarshal(msg, &resp); err != nil || resp.ID == "" {
					continue
				}
				s.touchKnownByKey(ac.key)
				ac.pmu.Lock()
				ch := ac.pending[resp.ID]
				delete(ac.pending, resp.ID)
				ac.pmu.Unlock()
				if ch != nil {
					select {
					case ch <- resp:
					default:
					}
				}
			default:
			}
		}
	}()
}

func (s *server) listAgents() []map[string]any {
	s.knownMu.RLock()
	defer s.knownMu.RUnlock()
	out := make([]map[string]any, 0, len(s.known))
	for _, a := range s.known {
		out = append(out, map[string]any{
			"key":           a.Key,
			"name":          a.Name,
			"display_name":  a.DisplayName,
			"hostname":      a.Hostname,
			"os":            a.OS,
			"arch":          a.Arch,
			"user":          a.User,
			"roots":         a.Roots,
			"last_seen_utc": a.LastSeenUTC,
			"version":       a.Version,
			"build":         a.Build,
			"capabilities":  a.Capabilities,
			"online":        a.Online,
		})
	}
	sort.Slice(out, func(i, j int) bool {
		oi, _ := out[i]["online"].(bool)
		oj, _ := out[j]["online"].(bool)
		if oi != oj {
			return oi && !oj
		}
		ti, _ := out[i]["last_seen_utc"].(int64)
		tj, _ := out[j]["last_seen_utc"].(int64)
		if ti != tj {
			return ti > tj
		}
		ni, _ := out[i]["display_name"].(string)
		nj, _ := out[j]["display_name"].(string)
		return strings.ToLower(ni) < strings.ToLower(nj)
	})
	return out
}

func (s *server) firstAgentID() string {
	s.knownMu.RLock()
	defer s.knownMu.RUnlock()
	var bestKey string
	var bestSeen int64
	for _, a := range s.known {
		if a == nil {
			continue
		}
		if a.Online {
			if a.LastSeenUTC >= bestSeen {
				bestSeen = a.LastSeenUTC
				bestKey = a.Key
			}
		}
	}
	if bestKey != "" {
		return bestKey
	}
	for _, a := range s.known {
		if a == nil {
			continue
		}
		if a.LastSeenUTC >= bestSeen {
			bestSeen = a.LastSeenUTC
			bestKey = a.Key
		}
	}
	return bestKey
}

func (s *server) getAgent(id string) *agentConn {
	s.agentsMu.RLock()
	defer s.agentsMu.RUnlock()
	return s.agents[id]
}

type deadlineErr struct{}

func (deadlineErr) Error() string { return "agent request timed out" }

func (s *server) callAgent(agentKey string, req protocol.Request, timeout time.Duration) (protocol.Response, error) {
	ac := s.getOnlineConnByKey(agentKey)
	if ac == nil {
		return protocol.Response{}, fmt.Errorf("system offline or not connected")
	}
	if ok, feature := s.agentSupportsOp(ac, req.Op); !ok {
		return protocol.Response{Type: "resp", ID: req.ID, Ok: false, Err: fmt.Sprintf("unsupported feature: %s", feature)}, nil
	}
	req.Type = "req"
	if req.ID == "" {
		req.ID = randID(12)
	}

	ch := make(chan protocol.Response, 1)
	ac.pmu.Lock()
	ac.pending[req.ID] = ch
	ac.pmu.Unlock()

	if err := ac.ws.sendJSON(req); err != nil {
		ac.pmu.Lock()
		delete(ac.pending, req.ID)
		ac.pmu.Unlock()
		return protocol.Response{}, err
	}

	select {
	case resp := <-ch:
		return resp, nil
	case <-time.After(timeout):
		ac.pmu.Lock()
		delete(ac.pending, req.ID)
		ac.pmu.Unlock()
		return protocol.Response{}, deadlineErr{}
	}
}

// API for system selection
func (s *server) apiAgents(w http.ResponseWriter, r *http.Request) {
	if _, ok := s.requireSession(w, r); !ok {
		return
	}
	writeJSON(w, map[string]any{"agents": s.listAgents()})
}

func (s *server) apiCurrentAgent(w http.ResponseWriter, r *http.Request) {
	se, ok := s.requireSession(w, r)
	if !ok {
		return
	}
	key := se.selectedAgent
	if key == "" {
		key = s.firstAgentID()
		if key != "" {
			se.selectedAgent = key
		}
	}
	s.knownMu.RLock()
	a := s.known[key]
	s.knownMu.RUnlock()
	if a == nil {
		writeJSON(w, map[string]any{"agent": nil})
		return
	}
	writeJSON(w, map[string]any{"agent": map[string]any{
		"key":           a.Key,
		"name":          a.Name,
		"display_name":  a.DisplayName,
		"hostname":      a.Hostname,
		"os":            a.OS,
		"arch":          a.Arch,
		"user":          a.User,
		"roots":         a.Roots,
		"last_seen_utc": a.LastSeenUTC,
		"last_ip":       a.LastIP,
		"version":       a.Version,
		"build":         a.Build,
		"capabilities":  a.Capabilities,
		"online":        a.Online,
	}})
}

func (s *server) apiSelectAgent(w http.ResponseWriter, r *http.Request) {
	se, ok := s.requireSession(w, r)
	if !ok {
		return
	}
	var body struct {
		Key string `json:"key"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}
	body.Key = strings.TrimSpace(body.Key)
	if body.Key == "" {
		http.Error(w, "missing key", http.StatusBadRequest)
		return
	}
	s.knownMu.RLock()
	ka := s.known[body.Key]
	s.knownMu.RUnlock()
	if ka == nil {
		http.Error(w, "unknown system", http.StatusBadRequest)
		return
	}
	se.selectedAgent = body.Key
	home := ""
	if len(ka.Roots) > 0 {
		home = ka.Roots[0]
	}
	writeJSON(w, map[string]any{"ok": true, "homePath": home})
}

func (s *server) apiClearSelection(w http.ResponseWriter, r *http.Request) {
	se, ok := s.requireSession(w, r)
	if !ok {
		return
	}
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	se.selectedAgent = ""
	writeJSON(w, map[string]any{"ok": true})
}

func (s *server) controlPage(w http.ResponseWriter, r *http.Request) {
	se, ok := s.requireSession(w, r)
	if !ok {
		return
	}
	connInfo := s.agentInfo(r)
	tpl := template.Must(template.ParseFS(tplFS, "templates/control.html"))
	_ = tpl.Execute(w, s.pageDataForSession(se, map[string]any{
		"Title":              "MultiFS Manager",
		"Theme":              "dark",
		"Density":            "compact",
		"AgentServerURL":     connInfo.AgentServerURL,
		"ServerLANIPs":       connInfo.LANIPs,
		"AgentConfigJSON":    connInfo.ConfigJSON,
		"AgentLaunchCommand": connInfo.LaunchCommand,
	}))
}

func (s *server) systemsPage(w http.ResponseWriter, r *http.Request) {
	se, ok := s.requireSession(w, r)
	if !ok {
		return
	}
	tpl := template.Must(template.ParseFS(tplFS, "templates/systems.html"))
	_ = tpl.Execute(w, s.pageDataForSession(se, map[string]any{
		"Title": "Systems",
	}))
}

func (s *server) apiRenameAgent(w http.ResponseWriter, r *http.Request) {
	if _, ok := s.requireSession(w, r); !ok {
		return
	}
	var body struct {
		Key  string `json:"key"`
		Name string `json:"name"`
	}
	_ = json.NewDecoder(r.Body).Decode(&body)
	body.Key = strings.TrimSpace(body.Key)
	body.Name = strings.TrimSpace(body.Name)
	if body.Key == "" || body.Name == "" {
		http.Error(w, "missing key/name", http.StatusBadRequest)
		return
	}
	s.knownMu.Lock()
	a := s.known[body.Key]
	if a == nil {
		s.knownMu.Unlock()
		http.Error(w, "unknown system", http.StatusBadRequest)
		return
	}
	a.DisplayName = body.Name
	s.knownMu.Unlock()
	s.saveKnown()
	writeJSON(w, map[string]any{"ok": true})
}

func (s *server) apiRemoveAgent(w http.ResponseWriter, r *http.Request) {
	se, ok := s.requireSession(w, r)
	if !ok {
		return
	}
	var body struct {
		Key       string `json:"key"`
		Uninstall bool   `json:"uninstall"`
	}
	_ = json.NewDecoder(r.Body).Decode(&body)
	body.Key = strings.TrimSpace(body.Key)
	if body.Key == "" {
		http.Error(w, "missing key", http.StatusBadRequest)
		return
	}

	// If the caller asked us to uninstall the agent from the target machine
	// (the Systems "Delete" button), dispatch the silent uninstall over the
	// existing socket BEFORE we tear the connection down. The agent runs
	// the uninstall asynchronously and replies quickly; we don't wait for
	// its socket to close.
	uninstallDispatched := false
	if body.Uninstall {
		if c := s.getOnlineConnByKey(body.Key); c != nil {
			req := protocol.Request{
				Type: "req",
				ID:   randID(10),
				Op:   "agent_uninstall",
			}
			if resp, err := s.callAgent(body.Key, req, 6*time.Second); err == nil && resp.Ok {
				uninstallDispatched = true
			}
		}
	}

	if se.selectedAgent == body.Key {
		se.selectedAgent = ""
	}

	if c := s.getOnlineConnByKey(body.Key); c != nil && c.ws != nil && c.ws.c != nil {
		_ = c.ws.c.Close()
	}

	s.knownMu.Lock()
	delete(s.known, body.Key)
	s.knownMu.Unlock()
	s.saveKnown()

	writeJSON(w, map[string]any{
		"ok":                   true,
		"uninstall_dispatched": uninstallDispatched,
		"uninstall_requested":  body.Uninstall,
	})
}

// helpers for JSON responses and selected system lookup
func writeJSON(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	_ = json.NewEncoder(w).Encode(v)
}

func (s *server) selectedAgentConn(se *session) *agentConn {
	if se == nil || strings.TrimSpace(se.selectedAgent) == "" {
		return nil
	}
	return s.getOnlineConnByKey(strings.TrimSpace(se.selectedAgent))
}

func (s *server) findAgentByKey(key string) *agentConn {
	if key == "" {
		return nil
	}
	s.agentsMu.RLock()
	defer s.agentsMu.RUnlock()
	for _, a := range s.agents {
		if a != nil && a.key == key {
			return a
		}
	}
	return nil
}

func (s *server) getKnownSelected(se *session) *knownAgent {
	if se == nil || se.selectedAgent == "" {
		return nil
	}
	s.knownMu.RLock()
	defer s.knownMu.RUnlock()
	return s.known[se.selectedAgent]
}
