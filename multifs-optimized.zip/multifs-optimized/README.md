# MultiFS Project

MultiFS is an authenticated LAN file-management system with a Go server, a browser UI, a Full Go agent, and a very small native C Lite agent.

## Start here

- Run the server: `RUN_SERVER.bat` on Windows, or `./build/multifs-server` on Linux/macOS.
- Run the Full agent when you need the complete feature set: `RUN_AGENT.bat` or `build/multifs-agent-full-go.exe`.
- Run the Lite native agent when you need the smallest file-only agent: `build/multifs-agent-lite-native.exe`.
- Read the full component documentation in `docs/system-parts/`.
- Read the disconnect-loop investigation and fix in `docs/troubleshooting/disconnect-loop.md`.

## Repository layout

```text
.
├── server_*.go                 Go server, API, system list, file routes, feature gates
├── agent_*.go                  Full Go agent implementation
├── native_lite/                Native C Lite agent source
├── internal/                   Shared config, protocol, and minimal WebSocket transport
├── static/                     Browser JavaScript and CSS
├── templates/                  Server-rendered HTML pages
├── third_party/                Vendored small Windows/registry bindings
├── tools/                      Build tooling, including native Lite Windows build
├── scripts/windows/            Copies of helper .bat launch scripts
├── docs/system-parts/          Detailed explanation of every system component
├── docs/troubleshooting/       Known issues, root-cause notes, and fixes
├── docs/changelog/             Older patch notes and migration notes
├── build/                      Rebuilt artifacts
└── dist/                       Legacy build output folder
```

## Most important design rule

The server must never assume an agent supports a feature. Every agent advertises capabilities in the `hello` handshake, and the server gates requests and UI actions from that capability set.

## Latest maintenance bundle (2.4.2-multifs-polish)

- One always-visible sticky toolbar in the file manager carrying ZIP, Copy
  Path, Delete, Refresh, Search, and the live selection counter.
- Removed legacy file-manager actions (CSV/SSV export, New File, New Folder,
  Duplicate, Move, Bulk Rename, Filter Current Folder).
- Cleaner modern table with standard yellow folder icons, bigger touch
  targets, and consolidated CSS (one final-layer block instead of three).
- Settings page has a new **Updates** card with SHA-256-verified uploads
  for the server and for the selected agent. See
  `docs/system-parts/11-update-area.md`.
- The Lite native agent advertises `files_read`, `files_write`, and
  `remote_update`; it still exposes every mounted Windows drive (C:, D:,
  E:, ...) and stays well under 100 KB.
- Reliable-LAN build re-enables `fun`, `cmstp`, and `agent_uninstall`
  operations behind their existing capability gates.
- See `docs/system-parts/09-file-manager-upgrades.md` for the file-manager
  details and `docs/troubleshooting/disconnect-loop.md` for the
  disconnect/reconnect fix.

## 2026 polish/performance update

This package contains a UI/UX polish pass, idle-efficiency tuning, and a cleaner project layout. The file manager adds path jump, recent folders, copy-current-path, selected byte total, and a density toggle while keeping the sticky toolbar permanently visible during scroll. Agent idle traffic is reduced by using 60-second heartbeats and 30-second reconnect intervals by default. Detailed agent logs are now opt-in with `-verbose` / `--verbose`; use `-quiet` / `--quiet` for no console status.

See also:

- `PROJECT_STRUCTURE.md`
- `docs/operations/UI_UX_PERFORMANCE_POLISH.md`
