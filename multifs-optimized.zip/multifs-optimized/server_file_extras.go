//go:build !agent
// +build !agent

package main

import (
	"archive/zip"
	"bytes"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"multifs-advanced/internal/protocol"
)

const (
	serverZipMaxFiles = 4096
	serverZipMaxBytes = 256 << 20
	searchMaxDirs     = 12000
	searchMaxResults  = 500
)

type serverZipBuilder struct {
	s       *server
	agentID string
	zw      *zip.Writer
	seen    map[string]bool
	files   int
	bytes   int64
	start   time.Time
	limit   time.Duration
}

func (s *server) serverSideZip(agentID string, paths []string) ([]byte, int, error) {
	var buf bytes.Buffer
	zb := &serverZipBuilder{
		s:       s,
		agentID: agentID,
		zw:      zip.NewWriter(&buf),
		seen:    make(map[string]bool),
		start:   time.Now(),
		limit:   4 * time.Minute,
	}
	for i, p := range paths {
		p = cleanRemotePath(p)
		if p == "" {
			continue
		}
		rootName := safeZipName(remoteBase(p))
		if rootName == "" || rootName == "." || rootName == string(filepathSeparatorForRemote(p)) {
			rootName = fmt.Sprintf("item_%d", i+1)
		}
		if len(paths) > 1 && zb.seen[rootName] {
			rootName = fmt.Sprintf("%02d_%s", i+1, rootName)
		}
		if err := zb.addPath(p, rootName); err != nil {
			_ = zb.zw.Close()
			return nil, zb.files, err
		}
	}
	if err := zb.zw.Close(); err != nil {
		return nil, zb.files, err
	}
	return buf.Bytes(), zb.files, nil
}

func (zb *serverZipBuilder) addPath(remotePath, zipName string) error {
	if time.Since(zb.start) > zb.limit {
		return errors.New("zip operation timed out")
	}
	if zb.files >= serverZipMaxFiles {
		return fmt.Errorf("zip file limit reached (%d files)", serverZipMaxFiles)
	}
	zipName = safeZipName(zipName)
	if zipName == "" {
		return nil
	}

	// Try directory listing first. Files return an error here and then use read.
	resp, err := zb.s.callAgent(zb.agentID, protocol.Request{Op: "list", Path: remotePath}, 20*time.Second)
	if err == nil && resp.Ok {
		var lr protocol.ListResult
		if err := json.Unmarshal(resp.Result, &lr); err != nil {
			return err
		}
		dirName := strings.TrimRight(zipName, "/") + "/"
		if !zb.seen[dirName] {
			_, _ = zb.zw.Create(dirName)
			zb.seen[dirName] = true
		}
		sort.Slice(lr.Entries, func(i, j int) bool {
			if lr.Entries[i].IsDir != lr.Entries[j].IsDir {
				return lr.Entries[i].IsDir
			}
			return strings.ToLower(lr.Entries[i].Name) < strings.ToLower(lr.Entries[j].Name)
		})
		for _, e := range lr.Entries {
			childRemote := remoteJoin(lr.Path, e.Name)
			childZip := strings.TrimRight(zipName, "/") + "/" + e.Name
			if err := zb.addPath(childRemote, childZip); err != nil {
				return err
			}
		}
		return nil
	}

	resp, err = zb.s.callAgent(zb.agentID, protocol.Request{Op: "read", Path: remotePath}, 45*time.Second)
	if err != nil {
		return err
	}
	if !resp.Ok {
		return errors.New(resp.Err)
	}
	var rr protocol.ReadResult
	if err := json.Unmarshal(resp.Result, &rr); err != nil {
		return err
	}
	data, err := base64.StdEncoding.DecodeString(rr.DataB64)
	if err != nil {
		return err
	}
	if zb.bytes+int64(len(data)) > serverZipMaxBytes {
		return fmt.Errorf("zip byte limit reached (%s)", humanBytes(serverZipMaxBytes))
	}
	zipName = uniqueZipName(zb.seen, zipName)
	fh := &zip.FileHeader{Name: zipName, Method: zip.Deflate}
	if rr.ModTime > 0 {
		fh.SetModTime(time.Unix(rr.ModTime, 0))
	}
	w, err := zb.zw.CreateHeader(fh)
	if err != nil {
		return err
	}
	if _, err := w.Write(data); err != nil {
		return err
	}
	zb.seen[zipName] = true
	zb.files++
	zb.bytes += int64(len(data))
	return nil
}

func uniqueZipName(seen map[string]bool, name string) string {
	name = safeZipName(name)
	if !seen[name] {
		return name
	}
	base, ext := name, ""
	if idx := strings.LastIndex(name, "."); idx > 0 {
		base, ext = name[:idx], name[idx:]
	}
	for i := 2; i < 10000; i++ {
		candidate := fmt.Sprintf("%s (%d)%s", base, i, ext)
		if !seen[candidate] {
			return candidate
		}
	}
	return fmt.Sprintf("%d_%s", time.Now().UnixNano(), name)
}

func safeZipName(name string) string {
	name = strings.ReplaceAll(name, "\\", "/")
	parts := strings.Split(name, "/")
	cleaned := make([]string, 0, len(parts))
	for _, part := range parts {
		part = strings.TrimSpace(part)
		if part == "" || part == "." || part == ".." {
			continue
		}
		part = strings.TrimRight(part, ":")
		if part == "" {
			part = "root"
		}
		cleaned = append(cleaned, part)
	}
	if len(cleaned) == 0 {
		return "item"
	}
	return strings.Join(cleaned, "/")
}

func filepathSeparatorForRemote(p string) byte {
	if looksWindowsPath(p) {
		return '\\'
	}
	return '/'
}

type fileSearchHit struct {
	Name    string `json:"name"`
	Path    string `json:"path"`
	IsDir   bool   `json:"is_dir"`
	Size    int64  `json:"size"`
	ModTime int64  `json:"mod_time"`
}

func (s *server) apiFileSearch(w http.ResponseWriter, r *http.Request) {
	se, ok := s.requireSession(w, r)
	if !ok {
		return
	}
	q := strings.TrimSpace(r.URL.Query().Get("q"))
	if q == "" {
		http.Error(w, "missing query", http.StatusBadRequest)
		return
	}
	root := cleanRemotePath(r.URL.Query().Get("root"))
	scope := strings.TrimSpace(r.URL.Query().Get("scope"))
	max := atoiDefault(r.URL.Query().Get("max"), searchMaxResults)
	if max <= 0 || max > searchMaxResults {
		max = searchMaxResults
	}

	agentID, ac := s.selectedAgentFor(se)
	if ac == nil {
		http.Error(w, "no agent", http.StatusBadRequest)
		return
	}
	if !s.agentSupportsFeature(ac, "files_read") {
		http.Error(w, "selected agent does not support file search", http.StatusBadRequest)
		return
	}

	roots := []string{}
	if scope == "all" {
		if drs, err := s.drivesFor(agentID); err == nil {
			for _, d := range drs {
				if d.Path != "" {
					roots = append(roots, d.Path)
				}
			}
		}
		if len(roots) == 0 && len(ac.summary.Roots) > 0 {
			roots = append(roots, ac.summary.Roots...)
		}
	} else if root != "" {
		roots = append(roots, root)
	}
	if len(roots) == 0 {
		roots = append(roots, defaultBrowsePath(ac, nil))
	}

	hits, scanned, truncated := s.searchRemote(agentID, roots, q, max, 90*time.Second)
	writeJSON(w, map[string]any{
		"ok":        true,
		"query":     q,
		"roots":     roots,
		"scanned":   scanned,
		"truncated": truncated,
		"results":   hits,
	})
}

func (s *server) searchRemote(agentID string, roots []string, query string, max int, limit time.Duration) ([]fileSearchHit, int, bool) {
	needle := strings.ToLower(strings.TrimSpace(query))
	deadline := time.Now().Add(limit)
	queue := make([]string, 0, len(roots))
	for _, root := range roots {
		if root = cleanRemotePath(root); root != "" {
			queue = append(queue, root)
		}
	}
	seenDirs := map[string]bool{}
	hits := []fileSearchHit{}
	scannedDirs := 0
	truncated := false

	for len(queue) > 0 {
		if time.Now().After(deadline) || scannedDirs >= searchMaxDirs || len(hits) >= max {
			truncated = len(queue) > 0 || scannedDirs >= searchMaxDirs || len(hits) >= max
			break
		}
		dir := cleanRemotePath(queue[0])
		queue = queue[1:]
		if dir == "" {
			continue
		}
		seenKey := strings.ToLower(strings.ReplaceAll(dir, `/`, `\`))
		if seenDirs[seenKey] {
			continue
		}
		seenDirs[seenKey] = true
		scannedDirs++

		resp, err := s.callAgent(agentID, protocol.Request{Op: "list", Path: dir}, 20*time.Second)
		if err != nil || !resp.Ok {
			continue
		}
		var lr protocol.ListResult
		if err := json.Unmarshal(resp.Result, &lr); err != nil {
			continue
		}
		sort.Slice(lr.Entries, func(i, j int) bool {
			if lr.Entries[i].IsDir != lr.Entries[j].IsDir {
				return lr.Entries[i].IsDir
			}
			return strings.ToLower(lr.Entries[i].Name) < strings.ToLower(lr.Entries[j].Name)
		})
		for _, e := range lr.Entries {
			p := remoteJoin(lr.Path, e.Name)
			if remoteSearchMatch(needle, e.Name, p) {
				hits = append(hits, fileSearchHit{Name: e.Name, Path: p, IsDir: e.IsDir, Size: e.Size, ModTime: e.ModTime})
				if len(hits) >= max {
					truncated = true
					break
				}
			}
			if e.IsDir {
				queue = append(queue, p)
			}
		}
	}
	if hits == nil {
		hits = []fileSearchHit{}
	}
	return hits, scannedDirs, truncated
}

func remoteSearchMatch(needle, name, fullPath string) bool {
	if needle == "" {
		return false
	}
	nameLower := strings.ToLower(name)
	pathLower := strings.ToLower(fullPath)
	if strings.Contains(nameLower, needle) || strings.Contains(pathLower, needle) {
		return true
	}
	// Allow simple shell-style patterns such as *.log or report?.pdf.
	if strings.ContainsAny(needle, "*?") {
		if ok, _ := filepath.Match(needle, nameLower); ok {
			return true
		}
		base := strings.ToLower(remoteBase(fullPath))
		if ok, _ := filepath.Match(needle, base); ok {
			return true
		}
	}
	return false
}

func redirectToBrowsePath(w http.ResponseWriter, r *http.Request, p string) {
	http.Redirect(w, r, "/browse?path="+url.QueryEscape(p), http.StatusFound)
}

func (s *server) apiAgentUpdateFile(w http.ResponseWriter, r *http.Request) {
	se, ok := s.requireSession(w, r)
	if !ok || r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	if err := r.ParseMultipartForm(256 << 20); err != nil {
		http.Error(w, "bad upload", http.StatusBadRequest)
		return
	}
	key := strings.TrimSpace(r.FormValue("key"))
	if key == "" {
		key = se.selectedAgent
	}
	target := cleanRemotePath(r.FormValue("target"))
	if key == "" || target == "" {
		http.Error(w, "missing agent key or target path", http.StatusBadRequest)
		return
	}
	ac := s.getOnlineConnByKey(key)
	if ac == nil {
		http.Error(w, "system offline", http.StatusBadRequest)
		return
	}
	if !s.agentSupportsFeature(ac, "files_write") {
		http.Error(w, "selected agent does not support file updates", http.StatusBadRequest)
		return
	}
	file, header, err := r.FormFile("file")
	if err != nil {
		http.Error(w, "missing update file", http.StatusBadRequest)
		return
	}
	defer file.Close()
	data, err := io.ReadAll(file)
	if err != nil {
		http.Error(w, "read upload failed", http.StatusInternalServerError)
		return
	}
	if len(data) == 0 {
		http.Error(w, "empty update file", http.StatusBadRequest)
		return
	}
	if len(data) > 256<<20 {
		http.Error(w, "update file is too large", http.StatusBadRequest)
		return
	}
	sum := sha256.Sum256(data)
	hexsum := fmt.Sprintf("%x", sum[:])
	resp, err := s.callAgent(key, protocol.Request{Op: "write", Path: target, DataB64: base64.StdEncoding.EncodeToString(data), Mkdirs: true}, 90*time.Second)
	if err != nil || !resp.Ok {
		http.Error(w, agentError(err, resp.Err), http.StatusInternalServerError)
		return
	}
	verified := false
	if readResp, readErr := s.callAgent(key, protocol.Request{Op: "read", Path: target}, 90*time.Second); readErr == nil && readResp.Ok {
		var rr protocol.ReadResult
		if json.Unmarshal(readResp.Result, &rr) == nil {
			if remoteData, decErr := base64.StdEncoding.DecodeString(rr.DataB64); decErr == nil {
				remoteSum := sha256.Sum256(remoteData)
				verified = fmt.Sprintf("%x", remoteSum[:]) == hexsum
			}
		}
	}
	if !verified {
		http.Error(w, "file was written but verification read-back failed", http.StatusInternalServerError)
		return
	}
	writeJSON(w, map[string]any{"ok": true, "agent": key, "target": target, "filename": header.Filename, "bytes": len(data), "sha256": hexsum, "verified": true})
}
