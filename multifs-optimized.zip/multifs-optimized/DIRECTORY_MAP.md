# Directory Map

## Root Go files

- `server_main.go` — session handling, agent WebSocket registration, online/offline state, selected-agent APIs.
- `server.go` — HTTP route registration and page/API entry points.
- `server_files.go` — browse, upload, download, rename, delete, favorites, and path helpers.
- `server_file_extras.go` — bulk ZIP, search, server-side Lite fallbacks, and file-manager helper APIs.
- `server_features.go` — maps operations to capabilities and prevents unsupported agent requests.
- `server_api.go` — control/remote/diagnostic APIs that call agents.
- `server_network.go` and `server_discovery.go` — LAN URL, server address, and discovery helpers.
- `agent_main.go` — Full Go agent connection loop, heartbeat, request dispatcher, and file operations.
- `agent_windows.go` — Windows-only Full-agent modules.
- `agent_config.go` and `agent_discovery.go` — agent target selection, config, discovery, fallback logic.

## Important folders

- `native_lite/` — native C Lite agent; no CRT, direct WinAPI/Winsock, file-only operations.
- `internal/protocol/` — message schemas shared by server and agents.
- `internal/wsmini/` — dependency-free WebSocket transport used by the Go server and Full Go agent.
- `static/js/` — browser-side interaction logic.
- `templates/` — rendered HTML screens.
- `tools/` — reproducible build scripts.
- `docs/system-parts/` — component explanations, including the new `11-update-area.md`.
- `docs/troubleshooting/` — operational debugging and fixes.
