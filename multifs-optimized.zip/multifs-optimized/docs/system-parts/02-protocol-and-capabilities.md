# 02 — Protocol and Capabilities

## Transport

The Go server and Full Go agent use `internal/wsmini`, a small dependency-free WebSocket implementation. The Lite C agent implements only the client-side subset it needs.

The agent connects to:

```text
/ws/agent
```

It authenticates with the `X-LFM-Password` header.

## Hello handshake

Immediately after WebSocket upgrade, the agent sends a `hello` message. The important fields are:

- `key` — persistent identity used by the server UI.
- `name` — display name.
- `hostname`, `os`, `arch`, `user` — inventory metadata.
- `roots` — allowed browse roots.
- `version` — agent version string.
- `build` — build profile, for example `full-go` or `lite-native-c`.
- `capabilities` — exact features the agent supports.

## Request/response pattern

The server sends:

```json
{"type":"req","id":"...","op":"list","path":"C:\\Users"}
```

The agent replies:

```json
{"type":"resp","id":"...","ok":true,"result":{}}
```

The `id` correlates responses with pending server calls.

## Heartbeat

Agents send application-level heartbeat messages:

```json
{"type":"hb"}
```

The server uses these messages to refresh `last_seen_utc` and keep the system online. The Lite C agent now sends the same heartbeat every 25 seconds while idle.

## Capability examples

Lite native C currently advertises:

```text
files_read
files_write
```

Full Go advertises the complete feature set.

Legacy agents with no explicit capability list are treated conservatively by compatibility code so older builds can still connect, but new UI behavior is best with explicit capabilities.
