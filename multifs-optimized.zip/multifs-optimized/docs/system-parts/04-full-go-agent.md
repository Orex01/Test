# 04 — Full Go Agent

## Responsibility

The Full Go agent implements the complete MultiFS agent feature set and is intended for normal, trusted administration sessions.

It contains:

- File manager operations.
- Full capability handshake.
- Heartbeat and reconnect loop.
- Windows-specific modules compiled from `agent_windows.go`.
- Build tags that separate agent code from server code.

## Main files

- `agent_main.go` — connection loop, hello handshake, heartbeat, request dispatcher, and cross-platform file operations.
- `agent_windows.go` — Windows-only advanced modules.
- `agent_config.go` — server URL normalization, config files, and fallback URL selection.
- `agent_discovery.go` — LAN discovery of available server URLs.

## Reconnect behavior

The agent reconnects when the WebSocket closes. This revision adds a retry delay after a previously successful connection drops, preventing tight connect/disconnect loops from spamming the server.

## Duplicate-connection behavior

If an old copy and a new copy of the same agent key connect at the same time, the server now keeps the newest socket and closes the older duplicate cleanly.
