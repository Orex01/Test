# 10 - Robust self-update

MultiFS 2.4.0 adds explicit self-update support for the server and for agents that advertise the `remote_update` capability.

## Compatibility model

Every modern agent announces:

- `version` - the build/version label shown in the Systems page.
- `build` - implementation family, for example `full-go` or `lite-native-c`.
- `capabilities` - explicit feature list. Self-update is available only when `remote_update` is present.

Legacy agents with no capability list remain compatible with existing file/control features, but they are not treated as self-updatable because they cannot safely stage and replace themselves.

## Agent self-update flow

1. The browser uploads a replacement agent executable to `/api/agent/self-update`.
2. The server computes SHA-256 and sends the payload plus expected hash to the selected agent using the `self_update` operation.
3. The agent decodes the payload, verifies SHA-256 locally, writes a staged file beside its current executable, and verifies the staged bytes.
4. The agent writes a small replacement script, replies to the server, exits, and the script swaps the staged binary over the old one and restarts the agent with the same connection settings.

The Full Go agent and native Lite C agent both support this flow. The Lite implementation uses Windows CryptoAPI for SHA-256 and remains below 100 KB.

## Server self-update flow

1. The browser uploads a replacement server binary to `/api/server/self-update`.
2. The server verifies an optional supplied SHA-256, stages the new binary beside the running executable, and re-reads it to verify the staged bytes.
3. The server writes a replacement script, replies to the browser, closes the HTTP server, exits, and the script swaps/restarts it.

## Operational notes

- Use the server binary that matches the deployment operating system.
- Use a Lite agent binary for Lite agents and a Full Go agent binary for Full agents.
- During agent self-update, that agent may appear offline briefly and reconnect after restart.
- During server self-update, the browser may need a refresh after the replacement process completes.
