# 01 — Server

## Responsibility

The server is the control point for the browser UI and all connected agents. It owns:

- HTTP routing and HTML rendering.
- Login/session handling.
- The known-agent database in `agents_db.json`.
- Live WebSocket connections from agents.
- Selected-system state per browser session.
- File-manager APIs.
- Feature/capability enforcement.

## Main files

- `server.go` registers routes and shared middleware.
- `server_main.go` contains sessions, known-agent state, agent WebSocket registration, and selected-agent APIs.
- `server_files.go` contains file-manager page routes and core file operations.
- `server_file_extras.go` contains bulk ZIP and search extensions.
- `server_features.go` maps request operations to required capabilities.
- `server_api.go` contains non-file APIs such as control and diagnostics.

## Agent state model

The server tracks agents in two layers:

1. **Live connection map**: temporary connection IDs point to active sockets.
2. **Known-agent map**: persistent agent keys point to UI-visible machine records.

The persistent key is what the UI uses. Temporary connection IDs are intentionally not shown to the user.

## Capability enforcement

Before the server sends any operation to an agent, it calls `agentSupportsOp`. This prevents Lite agents from receiving unsupported commands and lets the UI darken or hide unavailable modules.

## Disconnect-loop fix

The server now handles duplicate connections with the same persistent key safely:

- A newer connection closes older duplicate sockets.
- When an old duplicate socket exits, it does **not** mark the shared system offline if a newer live socket still exists.
- `getOnlineConnByKey` chooses the newest live connection.

This fixes the classic UI flicker where one stale socket repeatedly made the same system appear offline even while another socket was online.
