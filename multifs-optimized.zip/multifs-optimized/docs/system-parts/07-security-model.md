# 07 — Security Model

## Trust boundary

MultiFS is intended for authenticated administration of systems you control. The server must authenticate every browser session and every agent WebSocket connection.

## Agent authentication

Agents connect to `/ws/agent` and present `X-LFM-Password`. The server rejects mismatches before WebSocket upgrade completes.

## Capability minimization

Lite agents advertise only file capabilities. Server-side operation gating prevents accidental access to non-file functionality.

## Path controls

The Lite native agent enforces its configured root. A requested path must resolve under the allowed root before the operation runs.

## Update mechanism guidance

A safe remote-update design should require:

- explicit capability advertisement such as `remote_update`,
- server-side operator confirmation,
- SHA-256 or stronger digest verification,
- atomic staging and replace,
- visible logs.

The tiny default Lite build keeps update support out of the binary to preserve size and reduce risk.
