# 06 — Browser UI

## Main files

- `templates/*.html` — server-rendered pages.
- `static/css/style.css` — shared styling and disabled-feature presentation.
- `static/js/capabilities.js` — feature gating helpers.
- `static/js/files.js` — file-manager behavior.
- `static/js/control.js` — control-room behavior.
- `static/js/remote.js` — remote-screen behavior.
- `static/js/systems.js` — systems list and selection.

## Capability-driven UI

The UI receives the selected agent's build and capability list from server APIs. Unsupported controls are darkened and made non-clickable. This is only a convenience layer; the real enforcement remains server-side in `server_features.go`.

## Practical rule

No UI button should rely on “try and show error” for unsupported Lite features. It should be hidden, darkened, or disabled before the user clicks it.
