# 05 — Lite Native C Agent

## Goal

The Lite agent is a tiny file-only Windows agent. It is designed to stay far below 100 KB by avoiding:

- Go runtime.
- C runtime.
- external WebSocket libraries.
- screen control.
- shell.
- process manager.
- registry manager.
- startup/persistence modules.

## Source

```text
native_lite/multifs_lite_win.c
```

## Supported operations

- `drives`
- `list`
- `read`
- `preview`
- `write`
- `mkdir`
- `rm`
- `rename`
- `self_update` (Windows CryptoAPI SHA-256 verification of the staged binary)

## Advertised capabilities

The Lite hello message announces exactly:

```json
["files_read", "files_write", "remote_update"]
```

It deliberately does **not** advertise `archive`. The server uses its
own `serverSideZip` fallback (driven by `files_read`) to produce ZIPs for
Lite agents.

## Drives

`op_drives` returns every mounted Windows drive (A:..Z:) by walking
`GetLogicalDrives()`. `allowed_path` accepts any absolute path whose drive
letter exists, so browsing `C:\`, `D:\`, `E:\`, ... all work.

Paths outside the configured `--root` are only allowed when they sit on a
mounted drive root, which is the path that the drive strip in the file
manager produces.

## Explicitly unsupported

- Shell execution.
- Remote screen/control.
- Registry management.
- Process management.
- Startup management.
- Fun/power/message-box modules.

The server and UI must use the capability handshake to disable unsupported modules rather than letting the user press them and fail later.

## Heartbeat reliability improvement

The Lite C agent now uses Winsock `select` with a one-second receive wait and sends `{"type":"hb"}` every 25 seconds while idle. This prevents the server's read deadline from disconnecting an otherwise healthy idle Lite session.

## Environment variables

The environment overrides now work correctly:

- `MULTIFS_SERVER`
- `MULTIFS_PASSWORD`
- `MULTIFS_KEY`

Command-line options still override defaults after environment values are loaded.
