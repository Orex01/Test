# 03 — File Manager

## Responsibilities

The file manager provides authenticated remote browsing and file operations through the selected agent.

Core operations exposed in the UI:

- List directories.
- Preview/read files.
- Download individual files.
- Upload files.
- Rename individual files/folders.
- Delete single items or bulk selection.
- System search.
- Download single items or selected items as a ZIP.
- Copy remote path(s) to the clipboard.

Removed legacy actions (no longer in the UI): CSV/SSV export, New File,
New Folder, Duplicate, Move, Bulk Rename, Filter Current Folder.

## Sticky toolbar

`templates/files.html` renders one sticky toolbar at the top of the file
area. The toolbar stays anchored while the file table scrolls and holds:

- **Top row:** Parent, Home, breadcrumbs, Upload, Favorite.
- **Quickbar:** selection counter, **ZIP**, **Copy Path**, **Delete**,
  divider, **Refresh**, **Search**.

The selection counter updates whenever a checkbox or select-all changes.
ZIP/Delete are capability-gated; they remain visible but disabled when the
selected agent does not advertise the matching capability.

## Important files

- `server_files.go` — browse page and main file operations.
- `server_file_extras.go` — system search, current-tree search, and ZIP download helpers.
- `templates/files.html` — rendered file-manager page.
- `static/js/files.js` — browser-side sorting, filtering, selection, upload, ZIP, and search behavior.

## Lite ZIP behavior

Lite native C does not implement agent-side zipping. Instead, the server creates ZIP output by requesting file data through normal `list` and `read` operations.

The server-side ZIP fallback has guardrails:

- Maximum file count.
- Maximum uncompressed input size.
- Path traversal avoidance.
- Capability checks before reads/writes.

## Search behavior

Search supports two practical modes:

1. Current tree search — searches under the currently browsed path.
2. System search — searches all roots advertised by the selected agent.

For Lite, “whole system” means every path under the Lite agent's configured `--root`. To search all of `C:`, launch Lite with:

```bat
multifs-agent-lite-native.exe --server ws://SERVER_IP:8080/ws/agent --password PASSWORD --root C:\
```
