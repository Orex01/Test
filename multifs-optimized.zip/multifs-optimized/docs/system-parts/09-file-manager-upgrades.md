# File Manager Upgrade Notes

This build simplifies the file manager UI and keeps only the workflows requested for the current compact file-browser design.

## Layout repairs

- The sticky file toolbar remains visible at the top of the file area while the table scrolls.
- The sticky quickbar carries every always-needed action: **selection counter, ZIP, Copy Path, Delete, Refresh, and Search.** A vertical divider separates the selection actions from the page-wide actions.
- The file table uses a cleaner modern layout with fixed action columns, improved spacing, clearer folder/file names, ellipsis handling for long paths, and standard yellow folder icons.
- Row actions use data attributes instead of inline JavaScript path strings, which fixes Windows path handling for ZIP and Copy Path.
- Unsupported Lite-mode buttons are dimmed and made non-clickable without injecting explanatory text into table rows.
- Capability gating is consolidated in `static/js/capabilities.js`; legacy agents with no capability list remain treated as full-capable except for `remote_update`.

## Removed from the browser UI

The following UI features were removed to keep the file manager simpler:

- Export CSV/SSV
- New File
- New Folder
- Duplicate
- Move
- Bulk Rename
- Filter Current Folder

The server may still contain some older internal endpoints for compatibility, but they are no longer exposed in the file-manager interface.

## Current primary actions

Sticky toolbar (always visible while scrolling):

- Parent directory, Home, breadcrumbs, Upload, Favorite/unfavorite (top row).
- Selection counter, ZIP, Copy Path, Delete, Refresh, Search (quickbar).

Row actions for individual files/folders:

- Download (files only)
- ZIP single item
- Copy Path
- Rename
- Delete

## Selection state

The selected-file counter updates whenever a row is selected, deselected, or the select-all checkbox changes. The ZIP, Copy Paths, and Delete buttons are enabled only when their required selection and capability conditions are satisfied.

## Agent file update

The Systems page keeps **Update File** for online write-capable agents. It uploads a replacement file to an explicit path on the agent and verifies the result by reading the file back and comparing SHA-256.

This is intentionally a file-update mechanism, not a silent process replacement mechanism. It is appropriate for updating configuration files, support files, or staging a new executable path. On Windows, replacing the currently running EXE may fail because Windows locks the image file while it is executing.
