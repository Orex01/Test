# 11 - Update Area

The Settings page exposes an explicit, authenticated **Updates** card that
uploads replacement binaries for the server and the selected agent.

## What the user sees

A single card titled **Updates** appears on the Settings page after login.
It contains two stacked targets:

1. **Server** - upload a replacement `server.exe` (Windows) or `multifs-server`
   binary. An optional SHA-256 field is enforced if the user provides a value.
2. **Selected Agent** - upload a replacement Full Go agent binary or Lite
   native agent binary for the currently selected system. The badge next to
   the title shows the agent's reported `version` and `build` so it is hard
   to push a Full binary to a Lite agent by accident.

Each target prints a green/red status line beneath its row after upload.

## What happens on submit

### Server update

1. Browser POSTs the upload to `/api/server/self-update`.
2. The server reads the multipart body, enforces the configured size cap
   (`maxSelfUpdateBytes = 256 MiB`), computes SHA-256, and compares it to the
   optional `sha256` form value. Mismatch returns HTTP 400 with no side effect.
3. `writeVerifiedUpdateFile` stages the new bytes beside the running
   executable, re-reads the staged file, and re-hashes to guarantee the
   on-disk copy matches what was uploaded.
4. `scheduleSelfReplaceAndRestart` writes a small Windows `.cmd` (or POSIX
   `.sh`) replacement script next to the binary and starts it detached. The
   script waits for the server to exit, swaps the staged file over the live
   binary, deletes the staged copy, and re-launches the server with the
   original command-line arguments.
5. The server replies to the browser with `{ok:true, bytes, sha256, ...}`,
   then closes the HTTP listener and exits, allowing the script to swap.

### Agent update

1. Browser POSTs the upload to `/api/agent/self-update` with an optional
   target-version label.
2. The server confirms the selected agent is online and advertises the
   `remote_update` capability. Agents without that capability are rejected.
3. The server computes SHA-256 on the upload and sends the payload as a
   base64 `self_update` request along with `args.sha256`, `args.target_version`,
   `args.server_version`, `args.protocol` (`multifs-update-v1`), and
   `args.restart=true`.
4. The agent decodes the payload, re-verifies SHA-256 (`writeVerifiedUpdateFile`
   on the Go agent, Windows CryptoAPI on the Lite C agent), stages the file,
   writes a tiny replacement script with the agent's original launch arguments
   preserved, replies to the server with the staged path and the verified
   SHA, then exits so the script can swap and restart.
5. The known-systems table will briefly show the agent offline; once it
   reconnects, its new `version`/`build` is shown in the Systems page and in
   the Updates card badge.

## Authentication and authorization

- The browser must already be logged in. Both endpoints require a valid
  session cookie (`requireSession`).
- Uploads are size-capped and content-validated (SHA-256 round-trip).
- The agent transport itself is authenticated by the shared password in the
  `X-LFM-Password` WebSocket header.

## What this is NOT

- Not a remote process-replacement primitive for arbitrary files. Use
  `/api/agent/update-file` (the Systems page's **Update File** action) when
  the goal is to overwrite a support or configuration file at an explicit
  path on the agent. That endpoint is verified with a read-back SHA-256
  rather than a self-replace script.
- Not an over-the-air download from a public server. The browser-side
  operator always provides the bytes. There is no embedded endpoint that
  pulls binaries from the public internet.
