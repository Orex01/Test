# 08 — Build and Release

## Native Lite Windows EXE

```bash
bash tools/build_native_lite_windows.sh
```

Outputs:

```text
build/multifs-agent-lite-native.exe
build/multifs-agent-lite-native-stripped.exe
```

The build uses Clang targeting Windows MSVC ABI and `lld-link` with local import libraries generated from `.def` files.

## Server

```bash
go build -trimpath -buildvcs=false -ldflags='-s -w -buildid=' -o build/multifs-server .
```

## Full Go Windows agent

```bash
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -tags=agent -trimpath -buildvcs=false -ldflags='-s -w -buildid=' -o build/multifs-agent-full-go.exe .
```

## Verification checklist

Before releasing:

1. `go test ./...`
2. Build server.
3. Build Full Go agent.
4. Build Lite native agent.
5. Start server.
6. Connect Lite agent and verify browse/list/read/write.
7. Connect Full agent and verify the complete UI remains available.
8. Confirm Lite unsupported pages/buttons are disabled before click.
9. Watch server logs for stable online status with no repeated disconnect loop.
