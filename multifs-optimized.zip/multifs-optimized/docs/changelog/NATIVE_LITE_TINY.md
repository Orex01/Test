# Native Lite Windows Agent

This tree includes a true sub-100 KB Lite agent at:

- `native_lite/multifs_lite_win.c`
- prebuilt output: `build/multifs-agent-lite-native.exe`

The build intentionally avoids the Go runtime, the C runtime, registry/process/screen/shell modules, startup/persistence, and any packer. It links only against normal Windows DLL imports from `KERNEL32.dll` and `WS2_32.dll`.

## Size observed in this build environment

- `build/multifs-agent-lite-native.exe`: about 17 KB
- `build/multifs-agent-lite-native-stripped.exe`: about 17 KB

## Build command

Run from the project root on a host that has `clang` and `lld-link`:

```bash
./tools/build_native_lite_windows.sh
```

This script generates small import libraries locally from `.def` files, so MinGW is not required.

## Run

```bat
multifs-agent-lite-native.exe --server ws://SERVER_IP:8080/ws/agent --password YOUR_PASSWORD --name lite --root C:\Users\YourUser
```

Supported flags:

- `--server ws://host:port/ws/agent`
- `--password shared-server-password`
- `--key stable-agent-key`
- `--name display-name`
- `--root allowed-root-directory`
- `--once`

Supported capabilities advertised to the server:

- `files_read`
- `files_write`

Unsupported features are rejected server-side and darkened in the UI when using this patched server.


## 2026-05-23 fix

The first native Lite EXE defaulted to `/ws` and printed no diagnostics, so a double-click could look like a blank command prompt. The fixed build defaults to `/ws/agent`, uses the project default shared password unless overridden, and prints connection/handshake status. Passing `/ws` is normalized to `/ws/agent` for compatibility with the earlier sample command.
