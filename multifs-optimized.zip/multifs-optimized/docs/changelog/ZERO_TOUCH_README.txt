Reliable LAN quick start

Read RELIABLE_LAN_README.txt first.

Server/main computer:
  RUN_SERVER.bat

Agent computer on the same LAN:
  RUN_AGENT.bat

Login:
  username: admin
  password: mlan-wtsKrrx9caxjVPLo

If the agent does not appear, run ALLOW_FIREWALL_ADMIN.bat as Administrator on the server computer, then use the agent_config.json shown in the File Manager connection panel.
