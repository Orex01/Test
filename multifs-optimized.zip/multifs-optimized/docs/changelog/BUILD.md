# MultiFS Advanced - Build Guide

## Fixed build commands

Server:

```bat
go build -trimpath -ldflags="-s -w -buildid=" -o dist\server.exe .
```

Agent:

```bat
go build -tags=agent -trimpath -ldflags="-s -w -buildid=" -o dist\agent.exe .
```

Or run:

```bat
build_windows.bat
```

## What the size flags do

- `-s -w` removes symbol/debug tables.
- `-trimpath` removes local filesystem paths from the binary.
- `-buildid=` removes the Go build ID payload.

These are normal Go release-build options. They reduce size without removing runtime functionality or changing the browser UI.
