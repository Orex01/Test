MultiFS Reliable LAN Build 2.2.0

Purpose
- Simple visible local-network server/agent setup.
- No cloud, no port forwarding, no hidden auto-install by default.
- Designed to work automatically on normal same-LAN networks using UDP discovery.
- If discovery is blocked, copy the generated agent_config.json from the File Manager panel next to agent.exe.

Default login
- URL on the server computer: http://127.0.0.1:8080
- Username: admin
- Password: mlan-wtsKrrx9caxjVPLo

Normal workflow
1. On the server/main computer, run:
   RUN_SERVER.bat

2. Open the printed URL in the browser.

3. On another computer on the same Wi-Fi/LAN, run:
   RUN_AGENT.bat

4. If the agent does not appear:
   - Run ALLOW_FIREWALL_ADMIN.bat as Administrator on the server computer.
   - Confirm both machines are on the same non-guest Wi-Fi/LAN.
   - Open File Manager on the server and copy the shown agent_config.json next to agent.exe on the agent computer.
   - Run RUN_AGENT.bat again.

What was optimized for reliability
- Server automatically falls back from 8080 to 8081/8082/... if the port is busy.
- Agent does not silently install itself by default, avoiding old hidden copies and dropped arguments.
- Agent tries: command-line URL, environment URL, agent_config.json, last-good server, LAN discovery, local fallback.
- Agent logs connection failures visibly in the console.
- Agent remembers the last successful server.
- File Manager shows the correct server/agent URL and generates agent_config.json.
- Builds use Go release-size flags: -trimpath -ldflags="-s -w -buildid=".

Safety/reliability choices in this build
- The agent runs visibly by default.
- Auto-install is opt-in only: agent.exe -install
- Fun/bluescreen, CMSTP, and remote agent uninstall operations are implemented in the Full Go Windows agent; Lite agents continue to expose only their advertised supported features.
- This build is for same-LAN administration. It cannot bypass guest Wi-Fi isolation, corporate firewall policy, NAT, or blocked UDP/TCP.

Manual fallback command
  dist\agent.exe -server ws://SERVER_IP:PORT

Build commands
  build_windows.bat

Expected binary sizes
- agent.exe: about 4.1 MB
- server.exe: about 7.9 MB
