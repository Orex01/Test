# Start Here

This tree contains three runtime pieces:

1. **Server** — the web UI, session/auth layer, agent registry, and request router.
2. **Full Go agent** — the complete Windows agent with all supported modules compiled in.
3. **Lite native C agent** — a sub-100 KB-class file-only agent for basic browse/read/write/delete operations.

Recommended reading order:

1. `system-parts/01-server.md`
2. `system-parts/02-protocol-and-capabilities.md`
3. `system-parts/03-file-manager.md`
4. `system-parts/04-full-go-agent.md`
5. `system-parts/05-lite-native-agent.md`
6. `troubleshooting/disconnect-loop.md`
7. `system-parts/08-build-and-release.md`

The source files remain mostly in the root package because Go packages are directory-scoped. Moving the root Go files into arbitrary subfolders would require a larger package split. The documentation and directory map are therefore the navigation layer, while the build layout remains simple and stable.

- `system-parts/09-file-manager-upgrades.md` - compact UI repair and file-manager features.
- `system-parts/10-self-update.md` - version-aware server/agent self-update flow.
