# Disconnect / Reconnect Loop Investigation

## Symptom

The UI shows an agent repeatedly disconnecting and reconnecting every few seconds or at regular short intervals. This was not caused by the latest Lite UI work; the pattern existed in the older connection model.

## Primary root cause found

The server used two different identities:

- temporary connection ID for live WebSocket sockets,
- persistent agent key for the UI-visible known system.

When duplicate sockets existed for the same persistent agent key, an older socket could disconnect and call `markKnownOfflineByKey(key)`. That changed the shared UI record to offline even if a newer socket for the same key was still connected.

This produced online/offline flicker and looked like the agent itself was constantly reconnecting.

## Fix implemented

The server now:

1. Detects duplicate live sockets using the same persistent key.
2. Keeps the newest connection as the active connection.
3. Closes older duplicate sockets outside the connection-map lock.
4. Removes a socket through `removeAgentConn`.
5. Marks a known system offline only if no other live socket for the same key remains.
6. Selects the newest live socket when sending requests.
7. Logs the read-loop error that ended a socket.

## Secondary issue found in Lite C agent

The native Lite agent originally did not send application heartbeats. An idle Lite socket could be closed by the server read deadline after a quiet period.

The Lite C agent now sends:

```json
{"type":"hb"}
```

every 25 seconds while connected and idle.

## Secondary issue found in reconnect behavior

The Full Go agent immediately rebuilt its candidate list after a connected socket dropped. It now waits the configured retry interval after a disconnect, preventing tight reconnect loops from flooding logs.

## How to verify

1. Start the updated server.
2. Start one Lite agent.
3. Keep the browser Systems page open.
4. Watch the server log for at least two minutes.
5. Expected log pattern:

```text
agent connected id=... name=...
```

No repeating disconnect/reconnect messages should appear unless the agent process is stopped, the network is interrupted, or a duplicate older process is intentionally replaced.

## If it still happens

Check these in order:

1. Confirm only one server process is listening on the expected port.
2. Confirm only one agent copy is running for a given `MULTIFS_KEY` or `--key`.
3. Confirm the agent uses `/ws/agent`.
4. Confirm password matches server config.
5. Confirm firewall/NAT is not killing idle TCP sessions.
6. Run the Lite agent without `--quiet` and capture its visible diagnostics.
