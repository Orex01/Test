# UI/UX, idle-efficiency, and layout polish

This build keeps the file-management feature set focused while improving the day-to-day operator experience.

## UI/UX polish

The browser interface now uses a final override layer in `static/css/style.css` so older experimental rules no longer fight the current layout. The most visible changes are cleaner sidebar navigation, softer panels, consistent button states, improved table spacing, standard yellow folder icons, compact action buttons, and a more readable file list.

## Sticky toolbar behavior

The file manager toolbar is permanently sticky inside the file-manager scroll area. When browsing a long folder, the navigation controls, path tools, ZIP, Copy Path, Delete, Refresh, Search, selected count, and selected byte total stay visible. This avoids scrolling back to the top just to act on selected files.

## New file-manager conveniences

- Path Jump: type a remote path and jump directly to it.
- Recent Folders: remembers the last ten browsed folders locally in the browser.
- Copy Current Folder Path: one-click copy of the current remote folder.
- Selection Size: shows the total selected size for regular files without recursively scanning folders.
- Density Toggle: switches between comfortable and compact table spacing and remembers the choice locally.

## Idle CPU/network reduction

- Full Go agent heartbeat interval increased from 25 seconds to 60 seconds.
- Server read deadline increased to 150 seconds to match the lower heartbeat rate.
- Lite native heartbeat interval increased to 60 seconds.
- Lite native idle socket wait increased from 1 second to 2 seconds, reducing wakeups while idle.
- Default reconnect delay increased to 30 seconds for both Full and Lite agents.
- Detailed connection logging is opt-in with `-verbose` / `--verbose`.

## Lite size policy

The Lite agent is still a native no-CRT PE build. Build scripts use aggressive size flags and produce both normal and stripped outputs. The feature set was not reduced for this pass.
