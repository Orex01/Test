//go:build agent
// +build agent

package main

import (
	"encoding/json"
	"net"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"time"

	"multifs-advanced/internal/config"
)

type agentConfigFile struct {
	Server    string `json:"server"`
	ServerURL string `json:"server_url"`
	Password  string `json:"password"`
	Token     string `json:"token"`
}

type agentServerCandidate struct {
	URL    string
	Source string
}

func resolveAgentServerURL(flagValue string, flagWasSet bool) string {
	candidates := resolveAgentServerCandidates(flagValue, flagWasSet)
	if len(candidates) == 0 {
		return normalizeAgentURL(flagValue)
	}
	return candidates[0].URL
}

func resolveAgentServerCandidates(flagValue string, flagWasSet bool) []agentServerCandidate {
	out := make([]agentServerCandidate, 0, 6)
	seen := map[string]bool{}
	add := func(source, raw string) {
		raw = strings.TrimSpace(raw)
		if raw == "" {
			return
		}
		norm := normalizeAgentURL(raw)
		if norm == "" || seen[norm] {
			return
		}
		seen[norm] = true
		out = append(out, agentServerCandidate{URL: norm, Source: source})
	}

	// Explicit command-line always has top priority. It is assumed to be an
	// intentional override for testing or a routed/VPN deployment.
	if flagWasSet {
		add("-server", flagValue)
	}

	for _, key := range []string{"MULTIFS_AGENT_SERVER", "MULTIFS_SERVER"} {
		if v := strings.TrimSpace(os.Getenv(key)); v != "" {
			add("environment "+key, v)
		}
	}

	// Prefer live LAN discovery before remembered/file targets. This prevents an
	// old agent_config.json or last_server.txt such as 10.x.x.x:8080 from trapping
	// the agent forever after the server moved to another IP or fallback port.
	if v := strings.TrimSpace(discoverAgentServerURL(2 * time.Second)); v != "" {
		add("LAN discovery", v)
	}

	if v := strings.TrimSpace(readAgentConfigServer()); v != "" {
		add("agent_config.json", v)
	}
	if v := strings.TrimSpace(readLastGoodServer()); v != "" {
		add("last-good server", v)
	}

	// Local fallback is useful for single-machine testing only.
	add("local fallback", flagValue)
	return out
}

func resolveAgentPassword() string {
	for _, key := range []string{"MULTIFS_AGENT_PASSWORD", "MULTIFS_PASSWORD"} {
		if v := strings.TrimSpace(os.Getenv(key)); v != "" {
			return v
		}
	}
	if v := strings.TrimSpace(readAgentConfigPassword()); v != "" {
		return v
	}
	return config.SharedPassword
}

func readAgentConfigServer() string {
	cfg, ok := readAgentConfig()
	if !ok {
		return ""
	}
	if strings.TrimSpace(cfg.Server) != "" {
		return cfg.Server
	}
	if strings.TrimSpace(cfg.ServerURL) != "" {
		return cfg.ServerURL
	}
	return ""
}

func readAgentConfigPassword() string {
	cfg, ok := readAgentConfig()
	if !ok {
		return ""
	}
	if strings.TrimSpace(cfg.Password) != "" {
		return cfg.Password
	}
	return strings.TrimSpace(cfg.Token)
}

func readAgentConfig() (agentConfigFile, bool) {
	for _, p := range agentConfigPaths() {
		b, err := os.ReadFile(p)
		if err != nil {
			continue
		}
		var cfg agentConfigFile
		if err := json.Unmarshal(b, &cfg); err != nil {
			continue
		}
		return cfg, true
	}
	return agentConfigFile{}, false
}

func agentConfigPaths() []string {
	out := []string{}
	add := func(p string) {
		p = strings.TrimSpace(p)
		if p == "" {
			return
		}
		for _, existing := range out {
			if strings.EqualFold(existing, p) {
				return
			}
		}
		out = append(out, p)
	}
	if exe, err := os.Executable(); err == nil && exe != "" {
		add(filepath.Join(filepath.Dir(exe), "agent_config.json"))
	}
	if wd, err := os.Getwd(); err == nil && wd != "" {
		add(filepath.Join(wd, "agent_config.json"))
	}
	if appData := os.Getenv("APPDATA"); appData != "" {
		add(filepath.Join(appData, "MultiFS", "agent_config.json"))
	}
	if home, err := os.UserHomeDir(); err == nil && home != "" {
		add(filepath.Join(home, "MultiFS", "agent_config.json"))
	}
	return out
}

func lastGoodServerPaths() []string {
	out := []string{}
	if appData := os.Getenv("APPDATA"); appData != "" {
		out = append(out, filepath.Join(appData, "MultiFS", "last_server.txt"))
	}
	if home, err := os.UserHomeDir(); err == nil && home != "" {
		out = append(out, filepath.Join(home, ".multifs_last_server"))
	}
	if exe, err := os.Executable(); err == nil && exe != "" {
		out = append(out, filepath.Join(filepath.Dir(exe), "last_server.txt"))
	}
	return out
}

func readLastGoodServer() string {
	for _, p := range lastGoodServerPaths() {
		b, err := os.ReadFile(p)
		if err == nil && strings.TrimSpace(string(b)) != "" {
			return strings.TrimSpace(string(b))
		}
	}
	return ""
}

func rememberAgentServerURL(raw string) {
	raw = normalizeAgentURL(raw)
	if raw == "" {
		return
	}
	for _, p := range lastGoodServerPaths() {
		if dir := filepath.Dir(p); dir != "" {
			_ = os.MkdirAll(dir, 0o755)
		}
		if err := os.WriteFile(p, []byte(raw+"\n"), 0o600); err == nil {
			return
		}
	}
}

func normalizeAgentURL(raw string) string {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return "ws://127.0.0.1:8080"
	}
	raw = strings.TrimRight(raw, "/")
	if !strings.Contains(raw, "://") {
		host := raw
		if h, p, err := net.SplitHostPort(raw); err == nil {
			host = net.JoinHostPort(h, p)
		} else if strings.Count(raw, ":") == 0 {
			host = net.JoinHostPort(raw, "8080")
		}
		raw = "ws://" + host
	}
	u, err := url.Parse(raw)
	if err != nil || u.Host == "" {
		return "ws://127.0.0.1:8080"
	}
	switch strings.ToLower(u.Scheme) {
	case "http":
		u.Scheme = "ws"
	case "https":
		u.Scheme = "wss"
	case "ws", "wss":
	default:
		u.Scheme = "ws"
	}
	if !strings.Contains(u.Host, ":") {
		u.Host = net.JoinHostPort(u.Host, "8080")
	}
	u.Path = ""
	u.RawQuery = ""
	u.Fragment = ""
	return u.String()
}

func agentWebSocketURL(base string) (*url.URL, error) {
	u, err := url.Parse(normalizeAgentURL(base))
	if err != nil {
		return nil, err
	}
	if strings.HasPrefix(u.Scheme, "http") {
		u.Scheme = strings.Replace(u.Scheme, "http", "ws", 1)
	}
	u.Path = "/ws/agent"
	u.RawQuery = ""
	u.Fragment = ""
	return u, nil
}
