@echo off
setlocal EnableExtensions
cd /d "%~dp0"
call build_windows.bat
if errorlevel 1 exit /b %ERRORLEVEL%
echo.
echo No-console agent builds:
echo   dist\agent-windowsgui.exe
echo   dist\multifs-agent-lite-native-windowsgui.exe
echo   dist\multifs-agent-lite-native-windowsgui-stripped.exe
echo.
echo These use Go -H=windowsgui for the Full agent and /subsystem:windows for the native Lite agent.
pause
