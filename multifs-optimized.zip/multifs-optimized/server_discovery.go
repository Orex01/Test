//go:build !agent
// +build !agent

package main

import (
	"encoding/json"
	"net"
	"strings"
	"time"
)

const (
	discoveryUDPPort = 45808
	discoveryRequest = "MULTIFS_DISCOVER_V1"
)

type discoveryReply struct {
	Type       string   `json:"type"`
	AgentURL   string   `json:"agent_url"`
	HTTPURL    string   `json:"http_url"`
	Host       string   `json:"host"`
	Port       string   `json:"port"`
	Candidates []string `json:"candidates"`
	TimeUTC    string   `json:"time_utc"`
}

func startDiscoveryResponder(s *server) error {
	addr := &net.UDPAddr{IP: net.IPv4zero, Port: discoveryUDPPort}
	conn, err := net.ListenUDP("udp4", addr)
	if err != nil {
		return err
	}

	go func() {
		defer conn.Close()

		buf := make([]byte, 2048)
		for {
			n, remote, err := conn.ReadFromUDP(buf)
			if err != nil {
				return
			}
			msg := strings.TrimSpace(string(buf[:n]))
			if msg != discoveryRequest {
				continue
			}

			port := s.serverPort(nil)
			host := bestLocalIPv4ForRemote(remote.IP)
			if host == "" {
				ips := lanIPv4s()
				if len(ips) > 0 {
					host = ips[0]
				} else {
					host = "127.0.0.1"
				}
			}

			candidates := make([]string, 0, 4)
			add := func(ip string) {
				ip = strings.TrimSpace(ip)
				if ip == "" {
					return
				}
				url := "ws://" + net.JoinHostPort(ip, port)
				for _, existing := range candidates {
					if existing == url {
						return
					}
				}
				candidates = append(candidates, url)
			}
			add(host)
			for _, ip := range lanIPv4s() {
				add(ip)
			}

			reply := discoveryReply{
				Type:       "multifs_server",
				AgentURL:   "ws://" + net.JoinHostPort(host, port),
				HTTPURL:    "http://" + net.JoinHostPort(host, port),
				Host:       host,
				Port:       port,
				Candidates: candidates,
				TimeUTC:    time.Now().UTC().Format(time.RFC3339),
			}
			b, _ := json.Marshal(reply)
			_, _ = conn.WriteToUDP(b, remote)
		}
	}()
	return nil
}

func bestLocalIPv4ForRemote(remote net.IP) string {
	r := remote.To4()
	if r == nil {
		return ""
	}
	ips := lanIPv4s()
	if len(ips) == 0 {
		return ""
	}
	// Prefer same /24, which matches the normal home/office LAN case.
	for _, s := range ips {
		ip := net.ParseIP(s).To4()
		if ip == nil {
			continue
		}
		if ip[0] == r[0] && ip[1] == r[1] && ip[2] == r[2] {
			return s
		}
	}
	// Then same /16.
	for _, s := range ips {
		ip := net.ParseIP(s).To4()
		if ip == nil {
			continue
		}
		if ip[0] == r[0] && ip[1] == r[1] {
			return s
		}
	}
	return ips[0]
}
