# Windows EXE build fix

This exact package now has one reliable entry point for building every Windows executable.

## On Windows

Install Go first. Install LLVM/Clang only if you want to rebuild the tiny native Lite C agent from source.

```bat
build_windows.bat
```

Outputs:

- `dist\server.exe`
- `dist\agent.exe` - Full Go agent
- `dist\multifs-agent-lite-native.exe` - native Lite C agent
- `dist\multifs-agent-lite-native-stripped.exe`
- matching copies in `build\`

If LLVM/Clang is missing, `build_windows.bat` still builds the Go server and Full agent, then uses the prebuilt Lite EXE already included in `build\`. If no prebuilt Lite EXE exists, install LLVM/Clang and rerun the script.

## On Linux / WSL

```sh
./build_windows.sh
```

This cross-builds the Windows Go binaries and builds the native Lite Windows PE with `clang` + `lld-link`.

## What was broken before

- `build_windows.bat` built only the Go server and Full agent, not the native Lite EXE.
- The root `build_native_lite_windows.bat` used the wrong working directory for this package layout.
- The Windows native Lite build referenced `native_lite\imports\*.def`, but that folder was missing.
- The shell build did not copy the Lite EXEs into `dist\`, so the final EXE folder was incomplete.
