@echo off
setlocal
cd /d "%~dp0"
if exist "dist\agent.exe" (
  set "AGENT=dist\agent.exe"
) else (
  set "AGENT=agent.exe"
)
echo Starting MultiFS agent in visible same-LAN mode...
echo The agent tries config, last-good server, then LAN auto-discovery.
echo Keep this window open to see connection status.
echo.
"%AGENT%" -no-install
pause
